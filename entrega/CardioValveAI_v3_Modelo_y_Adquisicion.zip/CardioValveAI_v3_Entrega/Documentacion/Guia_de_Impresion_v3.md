# Guía de impresión v3

> CardioValveAI · revisión **v3** · prototipo académico de banco **sin fluido**. No es un dispositivo médico ni de diagnóstico; los resultados del banco no equivalen a diagnosticar una válvula implantada.
> **[CÁLCULO]** cálculo · **[GEOM]** inspección geométrica · **[SIM]** simulación · **[COMPILACIÓN]** compilación · **[SW]** prueba de software · **[FÍSICO]** pendiente de ensayo físico

**Supuestos sobre la impresora (VERIFICAR):** FDM con boquilla 0,4 mm, cama ≥ 220 × 220 mm, PETG a 230–245 °C, cama 70–80 °C, flujo calibrado. Unidades de los STL:
**milímetros**; ya están orientados para la cama. Las tolerancias del diseño suponen ±0,1–0,2 mm: **la probeta decide** los diámetros finales.

**Primero imprimir `CardioValveAI_v3_Tolerance_Coupon.stl`** (5 filas): 1 eje Ø2 libre · 2 eje Ø2 a presión · 3 pilotos M2/M3 · 4 insertos M2/M3 · 5 imanes Ø4 (4,05–4,30).
Actualizar `config.py` (`PIN_HOLE_LEAF`, `TAIL_PIN_HOLE`, `LINK_HOLE`, `M2_INSERT_D`, `M3_INSERT_D`, `MAG_POCKET_CLR`) y regenerar:
`python build_all.py && python verify.py && python make_docs_v3.py`.

Las piezas **NO DEFINITIVA** dependen de datos pendientes (doc 02). Ninguna pieza se imprimió ni se probó todavía: **no se declara «listo para imprimir»**; las mallas
pasaron las comprobaciones geométricas del informe de validación.

| Archivo | Cant. | Tamaño (mm) | Masa PETG (g) | Parámetros | Soporte | Superficie crítica | Nota |
|---|---|---|---|---|---|---|---|
| `CardioValveAI_v3_Valve_Ring.stl` | 1 | 70,0 × 70,0 × 24,0 | 30,8 | 0.2 mm · 50 % · 4 perím. | no | paredes del bolsillo Hall y agujeros de bisagra | Repasar los agujeros horizontales de Ø2,1 con broca de 2,0–2,1 mm si quedan ovalados. Superficie crítica: paredes del bolsillo Hall (0,55 mm hacia la ranura). |
| `CardioValveAI_v3_Hall_Carrier_000.stl` **NO DEFINITIVA** | 3 | 8,1 × 4,0 × 8,2 | 0,1 | 0.12 mm · 100 % · 3 perím. | no | lomo y pestaña | Pestaña en la cama. NO DEFINITIVA hasta confirmar el encapsulado del sensor. |
| `CardioValveAI_v3_Hall_Carrier_025.stl` **NO DEFINITIVA** | 3 | 7,9 × 4,0 × 8,2 | 0,1 | 0.12 mm · 100 % · 3 perím. | no | lomo y pestaña | Pestaña en la cama. NO DEFINITIVA hasta confirmar el encapsulado del sensor. |
| `CardioValveAI_v3_Hall_Carrier_050.stl` **NO DEFINITIVA** | 3 | 7,6 × 4,0 × 8,2 | 0,1 | 0.12 mm · 100 % · 3 perím. | no | lomo y pestaña | Pestaña en la cama. NO DEFINITIVA hasta confirmar el encapsulado del sensor. |
| `CardioValveAI_v3_Calib_Gauge_00.stl` | 1 | 27,6 × 15,0 × 11,6 | 1,3 | 0.12 mm · 100 % · 4 perím. | sí | cara de contacto | Acostada sobre su cara lateral. Superficie crítica: la cara de contacto (sin soportes). |
| `CardioValveAI_v3_Calib_Gauge_05.stl` | 1 | 27,6 × 14,3 × 11,6 | 1,3 | 0.12 mm · 100 % · 4 perím. | sí | cara de contacto | Acostada sobre su cara lateral. Superficie crítica: la cara de contacto (sin soportes). |
| `CardioValveAI_v3_Calib_Gauge_10.stl` | 1 | 27,6 × 13,7 × 11,6 | 1,2 | 0.12 mm · 100 % · 4 perím. | sí | cara de contacto | Acostada sobre su cara lateral. Superficie crítica: la cara de contacto (sin soportes). |
| `CardioValveAI_v3_Calib_Gauge_15.stl` | 1 | 27,4 × 13,0 × 11,6 | 1,2 | 0.12 mm · 100 % · 4 perím. | sí | cara de contacto | Acostada sobre su cara lateral. Superficie crítica: la cara de contacto (sin soportes). |
| `CardioValveAI_v3_Calib_Gauge_20.stl` | 1 | 27,2 × 12,4 × 11,6 | 1,2 | 0.12 mm · 100 % · 4 perím. | sí | cara de contacto | Acostada sobre su cara lateral. Superficie crítica: la cara de contacto (sin soportes). |
| `CardioValveAI_v3_Calib_Gauge_30.stl` | 1 | 26,4 × 11,1 × 11,6 | 1,1 | 0.12 mm · 100 % · 4 perím. | no | cara de contacto | Acostada sobre su cara lateral. Superficie crítica: la cara de contacto (sin soportes). |
| `CardioValveAI_v3_Calib_Gauge_40.stl` | 1 | 25,2 × 9,9 × 11,6 | 1,0 | 0.12 mm · 100 % · 4 perím. | no | cara de contacto | Acostada sobre su cara lateral. Superficie crítica: la cara de contacto (sin soportes). |
| `CardioValveAI_v3_Calib_Gauge_50.stl` | 1 | 23,7 × 9,2 × 11,6 | 0,9 | 0.12 mm · 100 % · 4 perím. | no | cara de contacto | Acostada sobre su cara lateral. Superficie crítica: la cara de contacto (sin soportes). |
| `CardioValveAI_v3_Calib_Gauge_60.stl` | 1 | 22,0 × 10,3 × 11,6 | 0,9 | 0.12 mm · 100 % · 4 perím. | no | cara de contacto | Acostada sobre su cara lateral. Superficie crítica: la cara de contacto (sin soportes). |
| `CardioValveAI_v3_Calib_Gauge_70.stl` | 1 | 20,0 × 10,9 × 11,6 | 0,8 | 0.12 mm · 100 % · 4 perím. | no | cara de contacto | Acostada sobre su cara lateral. Superficie crítica: la cara de contacto (sin soportes). |
| `CardioValveAI_v3_Calib_Gauge_80.stl` | 1 | 17,8 × 11,1 × 11,6 | 0,8 | 0.12 mm · 100 % · 4 perím. | no | cara de contacto | Acostada sobre su cara lateral. Superficie crítica: la cara de contacto (sin soportes). |
| `CardioValveAI_v3_Leaflet_1.stl` | 1 | 28,3 × 33,9 × 10,6 | 1,7 | 0.12 mm · 100 % · 3 perím. | sí | alojamiento del imán y barril | Imprimir con la cara inferior plana en la cama. Soporte mínimo (árbol) bajo la cola inclinada 40°. Imán Ø4×2 en la cara −y de la cola (polaridad marcada). |
| `CardioValveAI_v3_Leaflet_2.stl` | 1 | 28,3 × 33,9 × 10,6 | 1,7 | 0.12 mm · 100 % · 3 perím. | sí | alojamiento del imán y barril | Imprimir con la cara inferior plana en la cama. Soporte mínimo (árbol) bajo la cola inclinada 40°. Imán Ø4×2 en la cara −y de la cola (polaridad marcada). |
| `CardioValveAI_v3_Leaflet_3.stl` | 1 | 28,3 × 33,9 × 10,6 | 1,7 | 0.12 mm · 100 % · 3 perím. | sí | alojamiento del imán y barril | Imprimir con la cara inferior plana en la cama. Soporte mínimo (árbol) bajo la cola inclinada 40°. Imán Ø4×2 en la cara −y de la cola (polaridad marcada). |
| `CardioValveAI_v3_Link_Normal.stl` | 4 | 6,0 × 32,0 × 3,0 | 0,7 | 0.2 mm · 100 % · 3 perím. | no |  | Plana. Sin marcas. |
| `CardioValveAI_v3_Link_LostMotion.stl` | 2 | 6,0 × 37,5 × 3,0 | 0,7 | 0.2 mm · 100 % · 3 perím. | no |  | Plana. |
| `CardioValveAI_v3_Link_LostMotion_IC.stl` | 1 | 6,0 × 36,1 × 3,0 | 0,7 | 0.2 mm · 100 % · 3 perím. | no |  | Plana. |
| `CardioValveAI_v3_Opening_Stop_84.stl` | 3 | 11,0 × 12,0 × 4,4 | 0,4 | 0.2 mm · 100 % · 3 perím. | no |  | Brida en la cama. |
| `CardioValveAI_v3_Opening_Stop_60.stl` | 1 | 11,0 × 12,0 × 7,2 | 0,5 | 0.2 mm · 100 % · 3 perím. | no |  | Brida en la cama. |
| `CardioValveAI_v3_Opening_Stop_45.stl` | 1 | 11,0 × 12,0 × 8,3 | 0,5 | 0.2 mm · 100 % · 3 perím. | no |  | Brida en la cama. |
| `CardioValveAI_v3_Actuator_Plate.stl` | 1 | 66,6 × 69,5 × 13,0 | 13,8 | 0.2 mm · 40 % · 4 perím. | no | bujes | Repasar los bujes Ø8,6 con lija y lubricar con grasa de PTFE. |
| `CardioValveAI_v3_Pushrod.stl` | 1 | 5,6 × 35,6 × 3,0 | 0,7 | 0.2 mm · 100 % · 3 perím. | no |  | Plano. |
| `CardioValveAI_v3_Column.stl` | 3 | 8,0 × 8,0 × 58,1 | 3,4 | 0.2 mm · 40 % · 4 perím. | no | superficie de deslizamiento | Vertical. Lijar la superficie de deslizamiento (grano 400) y lubricar. |
| `CardioValveAI_v3_Cable_Clip.stl` | 3 | 16,8 × 11,8 × 6,0 | 0,7 | 0.2 mm · 100 % · 3 perím. | no |  |  |
| `CardioValveAI_v3_MEMS_Stand.stl` | 1 | 44,0 × 32,0 × 76,6 | 20,4 | 0.2 mm · 40 % · 4 perím. | no |  | Pie en la cama. |
| `CardioValveAI_v3_MEMS_Stand_Holder.stl` **NO DEFINITIVA** | 1 | 28,9 × 18,9 × 7,0 | 1,1 | 0.2 mm · 40 % · 3 perím. | sí |  | Cara del marco en la cama. |
| `CardioValveAI_v3_Servo_Mount.stl` **NO DEFINITIVA** | 1 | 40,2 × 31,0 × 20,2 | 7,1 | 0.2 mm · 50 % · 4 perím. | no |  | Fijar a la base sobre arandelas de goma (antivibración). |
| `CardioValveAI_v3_Electronics_Tray.stl` **NO DEFINITIVA** | 1 | 79,4 × 103,8 × 9,6 | 35,6 | 0.2 mm · 30 % · 3 perím. | no |  | Insertos M3 en los 4 postes. |
| `CardioValveAI_v3_Tray_Clamp.stl` **NO DEFINITIVA** | 2 | 8,0 × 103,8 × 3,0 | 2,9 | 0.2 mm · 100 % · 3 perím. | no |  | Cara superior en la cama. |
| `CardioValveAI_v3_Angle_Scale.stl` | 1 | 92,7 × 70,0 × 2,0 | 16,4 | 0.2 mm · 30 % · 3 perím. | no |  | Plano; marcas hacia arriba. |
| `CardioValveAI_v3_Base.stl` **NO DEFINITIVA** | 1 | 200,0 × 180,0 × 6,0 | 270,3 | 0.2 mm · 20 % · 4 perím. | no |  | Cabe en camas ≥ 220 × 220 mm. Usar borde (brim) de 5 mm para evitar alabeo. |
| `CardioValveAI_v3_Tolerance_Coupon.stl` | 1 | 66,0 × 46,0 × 6,5 | 23,9 | 0.2 mm · 100 % · 3 perím. | no |  | Imprimir primero: elegir los diámetros reales que ajustan con los ejes, insertos e imanes comprados. |

Insertos termofijados: soldador a ≈ 220–230 °C, presionar recto hasta quedar a ras, dejar enfriar sin mover.
