# 02 · Datos que bloquean decisiones (lista única)

> CardioValveAI · revisión **v3** · prototipo académico de banco **sin fluido**. No es un dispositivo médico ni de diagnóstico; los resultados del banco no equivalen a diagnosticar una válvula implantada.
> **[CÁLCULO]** cálculo · **[GEOM]** inspección geométrica · **[SIM]** simulación · **[COMPILACIÓN]** compilación · **[SW]** prueba de software · **[FÍSICO]** pendiente de ensayo físico

Mientras falten, las piezas afectadas quedan **paramétricas y NO definitivas** (marcadas en la guía de impresión y en la lista de materiales).

| # | Dato a enviar | Para qué se usa | Pieza / archivo afectado |
|---|---|---|---|
| 1 | **Sensores Hall:** modelo exacto impreso en el cuerpo y fabricante (foto nítida de la cara plana); si es **componente suelto (TO-92 de 3 patas) o módulo** (placa con LED, potenciómetro o comparador); en módulos, foto de ambas caras | Elegir alimentación (3,3 V directo o 5 V + divisor), sensibilidad, saturación y portasensor. Un módulo con comparador entrega salida digital | `Hall_Carrier_*`, `config.TO92_BODY`, Hoja 2 (opción A o B), `--sensor` al registrar |
| 2 | **Imanes:** diámetro, espesor, dirección de magnetización (axial o diametral) y grado si se conoce (N35/N42/N52) | Alojamiento en la cola, campo esperado, saturación, variante de portasensor | `config.MAG_LEAF`, `sensing.py`, `Leaflet_*` |
| 3 | **Servo:** marca y modelo; largo, ancho y alto del cuerpo; distancia entre agujeros de las orejas y altura de su cara inferior; posición del eje; **horn** que se usará y radio del agujero elegido (mm) | Soporte, altura del eje, barrido, par y velocidad | `config.SERVO`, `Servo_Mount`, `kinematics.py` |
| 4 | **ESP32 DevKit V1:** largo y ancho de la placa; cantidad de pines (30 o 38); separación entre hileras (centro a centro); posición del USB y de EN/BOOT; chip USB (CP2102 o CH340) | Zócalos, bandeja, acceso USB, velocidad del puerto | `Electronics_Tray`, `Tray_Clamp`, `config.ESP32_*`, firmware `CVAI_BAUD` |
| 5 | **INMP441:** forma y medidas de la placa; espesor; en qué cara está el **puerto acústico**; orden de los pines | Portaplaca con el puerto libre y orientación | `MEMS_Stand_Holder`, `config.MEMS_BOARD` |

### Sobre los sensores Hall (dato 1)
**«49E», AH49E, SS49E y DRV5055 no son equivalentes automáticos.** Hay que comprobar con la hoja de datos del modelo exacto: tensión de alimentación (49E/SS49E/AH49E:
típicamente 4,5–6 V o 3–6,5 V según fabricante; DRV5055: 3,3 V o 5 V), tipo de salida (lineal ratiométrica), sensibilidad (≈ 1,4–1,8 mV/G en la familia 49E a 5 V; DRV5055A1–A4:
100 / 50 / 25 / 12,5 mV/mT a 5 V), rango antes de saturar, encapsulado y **orden de las patas** (cambia entre fabricantes). Valores de distribuidores y de TI marcados VERIFICAR:
las hojas de datos de TI y Diodes no se pudieron descargar desde este entorno (bloqueo de red).

**Si son A3144 (u otro interruptor Hall digital):** su salida solo indica «campo por encima/debajo de un umbral» (encendido/apagado con histéresis). **No permiten seguir el
ángulo de forma continua**: a lo sumo marcan si la valva pasó por un punto. El cambio necesario es usar un **sensor lineal** (recomendado: DRV5055A1QLPG, TO-92, 3,3 V) en el
mismo portasensor.

### Partes que todavía NO conviene imprimir como definitivas
`Hall_Carrier_*` (encapsulado del sensor), `Servo_Mount` (servo), `Electronics_Tray`, `Tray_Clamp` y `Base` (ESP32 y servo), `MEMS_Stand_Holder` (INMP441). Se pueden imprimir
como prueba. La probeta, el anillo, las valvas, las bielas, los topes, las galgas y las columnas no dependen de estos datos (sí de la probeta: diámetros de agujeros e imanes).
