# 08 · Herramientas (Mac), visualización y micrófono

> CardioValveAI · revisión **v3** · prototipo académico de banco **sin fluido**. No es un dispositivo médico ni de diagnóstico; los resultados del banco no equivalen a diagnosticar una válvula implantada.
> **[CÁLCULO]** cálculo · **[GEOM]** inspección geométrica · **[SIM]** simulación · **[COMPILACIÓN]** compilación · **[SW]** prueba de software · **[FÍSICO]** pendiente de ensayo físico

Carpeta `Herramientas_Mac/`. Python ≥ 3.10: `python3 -m pip install -r requirements.txt`. Puerto en Mac: `ls /dev/cu.*`.

| Programa | Uso |
|---|---|
| `cvai_record.py` | Registra una sesión (`raw.bin` sin modificar, `session.json`, `session.npz`, `audio.wav`). `--live`: lectura **cruda** de cada Hall; ángulo **estimado** solo si hay calibración válida (si no, «SIN CALIBRACIÓN VÁLIDA»); comando del servo en un eje aparte; audio sincronizado; estado de calibración, saturación, pérdidas y paradas. `--sensor`, `--iman`, `--portasensor` quedan en `session.json`. |
| `cvai_calibrate.py` | `galgas`, `video`, `ajustar`, `subir`, `comparar` (doc 04). |
| `cvai_analyze.py` | Por ciclo: inicio y fin de apertura y cierre (criterios abajo), duración, amplitud, residual, retardos, diferencias entre valvas y entre ciclos, alertas. `--crear-umbrales` calcula umbrales con sesiones normales reales. |
| `cvai_emulator.py` | **Datos SINTÉTICOS** por un puerto virtual con el mismo protocolo, para probar el software. Todo lo que produce queda marcado «SINTÉTICO». |
| `tests/test_e2e.py` | Emulador → registro → calibración → análisis. **Aprobada** en este entorno [SW]. |

## Criterios de eventos (propuestos)
- Base = mediana 20–200 ms antes de la orden de apertura; meseta = mediana del 60 % final de la espera abierta; residual = mediana del 40 % final de la espera cerrada.
- Inicio de apertura = cruce de base + 10 % de la amplitud de referencia; fin = cruce de base + 90 % de la amplitud del ciclo; cierre simétrico. Sin calibración, sobre la lectura
  cruda y rotulado así.
- Apertura incompleta / cierre incompleto / asimetría / retraso / variación: comparación con umbrales de sesiones normales repetidas (mediana y MAD); sin ese archivo, solo
  comparación dentro de la sesión, rotulada «provisional». Atasco: amplitud < 60 % de la de referencia (propuesto); atasco del mecanismo si las 3 valvas quedan por debajo.

## Datos reales y de demostración
El campo `fuente` de `session.json` viene de la trama INFO del firmware; el emulador declara «EMULADOR — DATOS SINTÉTICOS». Nunca se mezclan para crear umbrales.
**Sin IA:** no hay datos suficientes. Si más adelante se entrena un clasificador, separar entrenamiento y evaluación por sesión.

## Micrófono M1 (señal complementaria)
- Soporte independiente `MEMS_Stand` a 52 mm del eje (ranura ±8 mm), pivote de inclinación (nominal 22,9°), puerto acústico libre.
  No toca el anillo: reduce la transmisión estructural directa.
- Fuentes de ruido: ambiente, servo (motor y engranajes, durante todo el movimiento) y vibración a través de la base. **No se supone que haya «clics»** de apertura o cierre: en
  modo normal no hay contacto valva–valva ni valva–tope.
- Se evalúa con el contraste de audio en ventanas alrededor de los eventos medidos por los Hall frente a la mitad del recorrido y al reposo (`cvai_analyze.py`).
