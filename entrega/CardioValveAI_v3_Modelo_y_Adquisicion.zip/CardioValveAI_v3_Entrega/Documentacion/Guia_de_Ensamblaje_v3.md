# Guía de ensamblaje v3

> CardioValveAI · revisión **v3** · prototipo académico de banco **sin fluido**. No es un dispositivo médico ni de diagnóstico; los resultados del banco no equivalen a diagnosticar una válvula implantada.
> **[CÁLCULO]** cálculo · **[GEOM]** inspección geométrica · **[SIM]** simulación · **[COMPILACIÓN]** compilación · **[SW]** prueba de software · **[FÍSICO]** pendiente de ensayo físico

Herramientas: soldador para insertos, allen 1,5 y 2,5 mm, llave de tubo 4 mm, alicate de punta, calibre, gancho fino, cianoacrilato, silicona neutra, grasa PTFE, bridas finas.

1. **Probeta** y ajuste de diámetros (guía de impresión).
2. **Insertos:** M3 en las columnas (ambos extremos), en la base (servo, bandeja, soporte M1) y en los postes de la bandeja.
3. **Imanes:** uno por valva en el alojamiento de la cara −y de la cola, con cianoacrilato y **la misma cara hacia afuera en las tres** (marcar la polaridad).
4. **Columnas → base:** M3×10 desde abajo.
5. **Servo:** centrarlo (90°) antes de colocar el horn; al `Servo_Mount` con sus tornillos; el soporte a la base con M3×12, arandelas de goma y casquillo.
6. **Plato:** grasa PTFE en los bujes; deslizar sobre las columnas. Empujador al horn y a la horquilla (M2×14 + tuerca).
7. **Valvas + bielas:** pasador de latón Ø2×9 a presión en la cola, biela en el pasador.
8. **Valvas en el anillo:** número de valva = número de sector; eje de latón Ø2×56 desde afuera; cianoacrilato solo en los extremos. Girar a mano 0–90° sin roce.
9. **Topes:** `Opening_Stop_84` desde abajo; tuerca M2 en la brida; tornillo M2×20 de latón desde arriba.
10. **Hall:** soldar 3 hilos finos a cada sensor (patas hacia arriba), pegar el sensor al lomo del portasensor `000` con una gota de silicona (cara plana hacia la valva);
    insertar el portasensor desde arriba hasta que la pestaña apoye; cable por el canal y la bajada exterior.
11. **Anillo sobre las columnas:** servo en posición abierta (plato abajo); unir cada biela a su orejeta (M2×10 + tuerca); fijar el anillo con M3×30.
12. **Comprobar a mano** (ensayo 5) con el empujador desconectado y luego conectado.
13. **Micrófono:** placa en `MEMS_Stand_Holder` (puerto libre), pivote M3×16 + autoblocante, soporte a la base por las ranuras.
14. **Cables:** pinzas en las columnas (bajo el recorrido del plato); señales por el sur, servo/5 V por el norte; mover el servo a mano y comprobar que nada roce.
15. **Electrónica:** placa perforada en la bandeja, ESP32 en zócalos hembra; comprobar 3V3_A y la salida de cada Hall con multímetro **antes** de conectar el ESP32.
16. **Cambio de sensor:** retirar el portasensor tirando de la pestaña; no hace falta desmontar nada más. **Cambio de módulo:** posición abierta → retirar tornillo biela–plato →
    sacar el eje → cambiar biela/tope/elástico → volver a montar. Recalibrar siempre que se toque un imán o un portasensor.
