# 07 · Firmware de adquisición y control (ESP-IDF)

> CardioValveAI · revisión **v3** · prototipo académico de banco **sin fluido**. No es un dispositivo médico ni de diagnóstico; los resultados del banco no equivalen a diagnosticar una válvula implantada.
> **[CÁLCULO]** cálculo · **[GEOM]** inspección geométrica · **[SIM]** simulación · **[COMPILACIÓN]** compilación · **[SW]** prueba de software · **[FÍSICO]** pendiente de ensayo físico

Carpeta `Firmware/CardioValveAI_v3_Adquisicion/`. **Estado:** compila con **ESP-IDF v5.4.1** para `esp32` sin advertencias en el código propio [COMPILACIÓN]. **No se probó en hardware** (no hay
placa en este entorno). El archivo de restricciones de Python de Espressif (dl.espressif.com) estaba bloqueado por la red: se instalaron versiones compatibles desde PyPI con la
opción oficial `--no-constraints`.

## Compilar y grabar (Mac)
```
. $HOME/esp/esp-idf/export.sh          # ESP-IDF v5.4.x según la guía de Espressif
cd Firmware/CardioValveAI_v3_Adquisicion
idf.py set-target esp32 && idf.py build
idf.py -p /dev/cu.usbserial-XXXX flash   # no usar 'monitor': el puerto lleva datos binarios
```

## Tareas (FreeRTOS)
| Núcleo | Tarea | Prio | Disparo | Función |
|---|---|---|---|---|
| 1 | adc | 10 | fin de búfer DMA (96 juegos = 12 ms) | demultiplexa H1–H3, suma de 8, saturación, huecos, marcas de tiempo |
| 1 | i2s | 9 | fin de búfer DMA (16 ms) | audio: FIR y diezmado a 8 kHz, saturación |
| 0 | servo | 8 | 5 ms | perfil coseno no bloqueante, límites, falta de movimiento, latido |
| 0 | tx | 5 | cola | tramas por UART0 (búfer 48 kB ≈ 0,5 s) |
| 0 | cmd | 4 | líneas de texto | comandos y calibración |
| 0 | main | 1 | 500 ms | trama de estado |

## Tasas, búferes y sincronización
- ADC1 a 24 kS/s, 12 bits, 12 dB; 3 canales → **1 kS/s por valva** (bloques de 32 muestras). Audio: I2S1 16 kHz → 8 kHz (FIR 47 coef.), bloques de 256.
- Un solo reloj (`esp_timer`, µs) para Hall, audio, comandos y eventos. Retardo del FIR de audio descontado. Desfase entre valvas informado.
- El comando PWM se aplica en el siguiente período de 20 ms: la posición REAL se toma de los Hall.
- Pérdidas: contadores de desborde del ADC/I2S, huecos de patrón y tramas descartadas en STATUS; secuencia por trama.

## Calibración en el ESP32
`CAL BEGIN n`, `CAL PT n lectura ángulo`, `CAL END n`, `CAL CLEAR n`: tabla por sensor (≤ 32 puntos) en NVS con CRC32. Validación: ≥ 5 puntos, estrictamente monótona, sin
lecturas repetidas, rango ≥ 30°. Sin calibración válida el firmware sigue enviando la lectura cruda, marca `cal_valid = 0` y **no aplica límites en grados**.

## Seguridad
- Arranca **sin pulsos** al servo. Límites de comando por software y límites de ángulo calibrado (`SET lim_min/lim_max`, −8…86° por defecto).
- **Falta de movimiento:** si durante un movimiento ordenado ninguna valva cambia su lectura ≥ `stall_min_delta` (200 cuentas de la suma de 8, ajustable con `SET stall`) → parada
  controlada y evento. Se desactiva con `SET stall 0` para el ensayo con el servo desacoplado.
- Parada de emergencia (GPIO23) y corte físico S1; latido `HB` de la computadora (2 s); falla de adquisición → parada.

## Protocolo
Trama `A5 5A | tipo | largo | secuencia | carga | CRC16`. Tipos: INFO=1 (JSON: versión, tasas, desfase, calibración), HALL=3, AUDIO=4, CMD=5, EVENT=6, STATUS=7 (75 bytes), TEXT=8.
Espejo en `Herramientas_Mac/cvai_proto.py`. Comandos: `PING, HB, INFO, STREAM ON|OFF, START n, STOP, DETACH, MOVE grados ms, SET clave valor, CAL …`.
