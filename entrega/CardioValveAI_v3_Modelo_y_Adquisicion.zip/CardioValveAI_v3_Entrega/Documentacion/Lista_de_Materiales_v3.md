# Lista de materiales v3 (mínima)

> CardioValveAI · revisión **v3** · prototipo académico de banco **sin fluido**. No es un dispositivo médico ni de diagnóstico; los resultados del banco no equivalen a diagnosticar una válvula implantada.
> **[CÁLCULO]** cálculo · **[GEOM]** inspección geométrica · **[SIM]** simulación · **[COMPILACIÓN]** compilación · **[SW]** prueba de software · **[FÍSICO]** pendiente de ensayo físico

| Elemento | Cant. | Tipo | Medidas | Función / nota |
|---|---|---|---|---|
| Valve_Ring | 1 | impresa (PETG) | 70,0 × 70,0 × 24,0 mm · 30,8 g | Anillo valvular con comisuras, bisagras, ranuras de mando y 3 bolsillos con ventana para los portasensores Hall  |
| Hall_Carrier_000 | 3 | impresa (PETG) | 8,1 × 4,0 × 8,2 mm · 0,1 g | Portasensor Hall extraíble, sensor alejado 0.00 mm del imán (NOMINAL: se monta en las 3 valvas) NO DEFINITIVA |
| Hall_Carrier_025 | 3 | impresa (PETG) | 7,9 × 4,0 × 8,2 mm · 0,1 g | Portasensor Hall extraíble, sensor alejado 0.25 mm del imán (ALTERNATIVA: solo si el sensor satura) NO DEFINITIVA |
| Hall_Carrier_050 | 3 | impresa (PETG) | 7,6 × 4,0 × 8,2 mm · 0,1 g | Portasensor Hall extraíble, sensor alejado 0.50 mm del imán (ALTERNATIVA: solo si el sensor satura) NO DEFINITIVA |
| Calib_Gauge_00 | 1 | impresa (PETG) | 27,6 × 15,0 × 11,6 mm · 1,3 g | Galga angular de calibración: la cara superior de la valva la toca a 0°  |
| Calib_Gauge_05 | 1 | impresa (PETG) | 27,6 × 14,3 × 11,6 mm · 1,3 g | Galga angular de calibración: la cara superior de la valva la toca a 5°  |
| Calib_Gauge_10 | 1 | impresa (PETG) | 27,6 × 13,7 × 11,6 mm · 1,2 g | Galga angular de calibración: la cara superior de la valva la toca a 10°  |
| Calib_Gauge_15 | 1 | impresa (PETG) | 27,4 × 13,0 × 11,6 mm · 1,2 g | Galga angular de calibración: la cara superior de la valva la toca a 15°  |
| Calib_Gauge_20 | 1 | impresa (PETG) | 27,2 × 12,4 × 11,6 mm · 1,2 g | Galga angular de calibración: la cara superior de la valva la toca a 20°  |
| Calib_Gauge_30 | 1 | impresa (PETG) | 26,4 × 11,1 × 11,6 mm · 1,1 g | Galga angular de calibración: la cara superior de la valva la toca a 30°  |
| Calib_Gauge_40 | 1 | impresa (PETG) | 25,2 × 9,9 × 11,6 mm · 1,0 g | Galga angular de calibración: la cara superior de la valva la toca a 40°  |
| Calib_Gauge_50 | 1 | impresa (PETG) | 23,7 × 9,2 × 11,6 mm · 0,9 g | Galga angular de calibración: la cara superior de la valva la toca a 50°  |
| Calib_Gauge_60 | 1 | impresa (PETG) | 22,0 × 10,3 × 11,6 mm · 0,9 g | Galga angular de calibración: la cara superior de la valva la toca a 60°  |
| Calib_Gauge_70 | 1 | impresa (PETG) | 20,0 × 10,9 × 11,6 mm · 0,8 g | Galga angular de calibración: la cara superior de la valva la toca a 70°  |
| Calib_Gauge_80 | 1 | impresa (PETG) | 17,8 × 11,1 × 11,6 mm · 0,8 g | Galga angular de calibración: la cara superior de la valva la toca a 80°  |
| Leaflet_1 | 1 | impresa (PETG) | 28,3 × 33,9 × 10,6 mm · 1,7 g | Valva 1 (semilunar simplificada, barril de bisagra y cola de mando)  |
| Leaflet_2 | 1 | impresa (PETG) | 28,3 × 33,9 × 10,6 mm · 1,7 g | Valva 2 (semilunar simplificada, barril de bisagra y cola de mando)  |
| Leaflet_3 | 1 | impresa (PETG) | 28,3 × 33,9 × 10,6 mm · 1,7 g | Valva 3 (semilunar simplificada, barril de bisagra y cola de mando)  |
| Link_Normal | 4 | impresa (PETG) | 6,0 × 32,0 × 3,0 mm · 0,7 g | Biela rígida (modo normal). 3 + 1 de repuesto  |
| Link_LostMotion | 2 | impresa (PETG) | 6,0 × 37,5 × 3,0 mm · 0,7 g | Biela con recorrido perdido (apertura restringida / asimétrica). 1 marca  |
| Link_LostMotion_IC | 1 | impresa (PETG) | 6,0 × 36,1 × 3,0 mm · 0,7 g | Biela corta con recorrido perdido (cierre incompleto 12°). 2 marcas  |
| Opening_Stop_84 | 3 | impresa (PETG) | 11,0 × 12,0 × 4,4 mm · 0,4 g | Tope de seguridad (84°) — se usa en modo normal y cierre incompleto  |
| Opening_Stop_60 | 1 | impresa (PETG) | 11,0 × 12,0 × 7,2 mm · 0,5 g | Tope intercambiable 60°  |
| Opening_Stop_45 | 1 | impresa (PETG) | 11,0 × 12,0 × 8,3 mm · 0,5 g | Tope intercambiable 45°  |
| Actuator_Plate | 1 | impresa (PETG) | 66,6 × 69,5 × 13,0 mm · 13,8 g | Plato actuador (corredera) con bujes, orejetas y horquilla  |
| Pushrod | 1 | impresa (PETG) | 5,6 × 35,6 × 3,0 mm · 0,7 g | Empujador servo → plato  |
| Column | 3 | impresa (PETG) | 8,0 × 8,0 × 58,1 mm · 3,4 g | Columna guía y soporte del anillo (insertos M3 en ambos extremos)  |
| Cable_Clip | 3 | impresa (PETG) | 16,8 × 11,8 × 6,0 mm · 0,7 g | Pinza de cables a presión en cada columna (bajo el recorrido del plato)  |
| MEMS_Stand | 1 | impresa (PETG) | 44,0 × 32,0 × 76,6 mm · 20,4 g | Soporte independiente del micrófono M1 (configuración inicial recomendada): ranura radial ±8 mm y pivote de inclinación  |
| MEMS_Stand_Holder | 1 | impresa (PETG) | 28,9 × 18,9 × 7,0 mm · 1,1 g | Portaplaca del INMP441 con lengüeta de pivote NO DEFINITIVA |
| Servo_Mount | 1 | impresa (PETG) | 40,2 × 31,0 × 20,2 mm · 7,1 g | Soporte del servo con escuadras (medidas del servo por confirmar) NO DEFINITIVA |
| Electronics_Tray | 1 | impresa (PETG) | 79,4 × 103,8 × 9,6 mm · 35,6 g | Bandeja de la placa perforada 70×90 (ESP32 en zócalos hembra, antena libre, USB accesible) NO DEFINITIVA |
| Tray_Clamp | 2 | impresa (PETG) | 8,0 × 103,8 × 3,0 mm · 2,9 g | Barra de sujeción de la placa perforada (sin perforar ni flexionar) NO DEFINITIVA |
| Angle_Scale | 1 | impresa (PETG) | 92,7 × 70,0 × 2,0 mm · 16,4 g | Transportador 0–90° para medir la valva 1 con cámara lateral  |
| Base | 1 | impresa (PETG) | 200,0 × 180,0 × 6,0 mm · 270,3 g | Base modular 200 × 180 mm con insertos M3 y ranuras para bridas NO DEFINITIVA |
| Tolerance_Coupon | 1 | impresa (PETG) | 66,0 × 46,0 × 6,5 mm · 23,9 g | Probeta: ejes libres y a presión, pilotos, insertos e imán Ø4  |
| ESP32 DevKit V1 (ESP32-WROOM-32) | 1 | comprada | | Medidas por confirmar (doc 02) |
| Servo (modelo por confirmar) + horns | 1 | comprada | | Medidas por confirmar |
| Fuente 5 V ≥ 2 A (3 A recom.) | 1 | comprada | | según el servo real |
| Imán neodimio Ø4×2 mm axial (N42) | 5 | comprada | | +2 de repuesto; medidas por confirmar |
| Sensor Hall lineal TI DRV5055A1QLPG (TO-92) | 4 | comprada | | recomendado; verificar modelo (doc 02) |
| INMP441 (placa de módulo) | 1 | comprada | | medidas por confirmar |
| Microchip MCP1700-3302 (TO-92) + 2 × 1 µF | 1 | comprada | | 3V3_A de los Hall |
| AO3401A + 10 kΩ | 1 | comprada | | polaridad invertida |
| PTC 2,5 A | 1 | comprada | |  |
| TVS SMBJ5.0A | 1 | comprada | |  |
| Capacitor 1000 µF 10 V bajo ESR | 1 | comprada | |  |
| Capacitores 100 nF cerámicos | 8 | comprada | | desacoplo y RC Hall |
| Resistencias 1 kΩ (×3), 220 Ω, 10 kΩ, 330 Ω, 33 Ω | 1 | comprada | | surtido |
| Resistencias 20 kΩ y 30 kΩ (×3 c/u) | 1 | comprada | | solo opción B (sensor de 5 V) |
| Placa perforada 7×9 cm | 1 | comprada | |  |
| Tiras de zócalo hembra 2,54 mm | 2 | comprada | | según pines del ESP32 |
| Conector con traba 2 vías (J1) / bornera | 2 | comprada | | 5 V servo |
| Parada de emergencia (NC + NA) | 1 | comprada | |  |
| LED + 330 Ω | 1 | comprada | | sincronización |
| Cable de 3 hilos fino | 3 | comprada | | Hall, ≈ 30 cm |
| Cable plano 6 hilos | 1 | comprada | | micrófono ≤ 20 cm |
| Varilla de LATÓN Ø2 mm | 1 | comprada | | 3 × 56 mm + 3 × 9 mm |
| Tornillo M2×20 de LATÓN + tuerca M2 | 3 | comprada | | topes |
| Tornillo M2×10 inox + tuerca | 3 | comprada | | biela–plato |
| Tornillo M2×14 + tuerca | 1 | comprada | | horquilla |
| Tornillo M3×10 | 5 | comprada | | columnas, soporte M1 |
| Tornillo M3×30 | 3 | comprada | | anillo |
| Tornillo M3×12 + casquillo + 2 arandelas de goma | 4 | comprada | | soporte del servo |
| Tornillo M3×6 | 4 | comprada | | bandeja |
| Tornillo M3×8 | 4 | comprada | | barras |
| Tornillo M3×16 + tuerca autoblocante | 1 | comprada | | pivote M1 |
| Inserto termofijado M3 | 20 | comprada | | columnas, base, bandeja |
| Grasa PTFE, cianoacrilato, silicona neutra, bridas | 1 | comprada | |  |
