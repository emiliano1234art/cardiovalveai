# 09 · Plan de validación física progresiva

> CardioValveAI · revisión **v3** · prototipo académico de banco **sin fluido**. No es un dispositivo médico ni de diagnóstico; los resultados del banco no equivalen a diagnosticar una válvula implantada.
> **[CÁLCULO]** cálculo · **[GEOM]** inspección geométrica · **[SIM]** simulación · **[COMPILACIÓN]** compilación · **[SW]** prueba de software · **[FÍSICO]** pendiente de ensayo físico

Los criterios son **objetivos propuestos, no resultados.** Ningún ensayo físico se realizó todavía. Cada ensayo se registra con `cvai_record.py` (fuente = ESP32) y video.

| Ensayo | Procedimiento | Criterio de aceptación propuesto |
|---|---|---|
| 1. Probeta | Imprimir `Tolerance_Coupon`: ejes de latón libres y a presión, pilotos, insertos, imanes Ø4. | Eje libre gira sin juego visible; a presión no sale con la mano; insertos a ras; imán entra con presión leve. Anotar diámetros y actualizar `config.py`. |
| 2. Una valva con Hall e imán, a mano | Anillo + valva 1 + portasensor; mover la valva a mano 0–80°; registrar con `--ciclos 0`. | Lectura monótona sin saturar (cuentas lejos de 0 y 4095); variación cerrada→abierta ≥ 10 veces el ruido estático. |
| 3. Calibración y video | Galgas 0–80°, apertura y cierre, 3 repeticiones; video con `Angle_Scale`. | Monótona; puntos distinguibles; resolución ≤ 1°, repetibilidad ≤ 1°, histéresis ≤ 2°; galga vs. video ≤ 1,5°. |
| 4. Repetir en las otras valvas | Ensayos 2–3 en las valvas 2 y 3; cada Hall con su valva quieta mientras se mueven las otras. | Mismos criterios; variación por las valvas vecinas < resolución. |
| 5. Mecanismo completo a mano | Empujador desconectado; mover el plato a mano en cada modo. | Sin trabas ni roces; recorridos según la tabla de modos ± 3°; fuerza para mover el plato anotada (objetivo < 1 N). |
| 6. Eléctrico con servo desacoplado | Servo sin horn conectado al empujador; `SET stall 0`; registrar Hall y audio. | Sin pérdidas ni errores CRC en 10 min; variación de los Hall por el servo < resolución; ruido de audio del servo registrado. |
| 7. Normal a baja velocidad | t_apertura ≥ 1500 ms, 30 ciclos, video sincronizado con el LED. | Meseta 80 ± 3°, residual ≤ 2°, diferencia entre valvas ≤ 3°, CV de duraciones < 5 %; ninguna parada. |
| 8. Una alteración conocida | Ej.: tope de 60° en la valva 1; 30 ciclos, con 10 normales antes y después. | Los ciclos alterados se marcan con el motivo correcto; los normales quedan dentro de los umbrales. |
| 9. Repetición | ≥ 3 sesiones en días distintos; desmontar y volver a montar portasensores entre sesiones. | Mediana y MAD por métrica → umbrales (`--crear-umbrales`); calibración tras remontaje dentro de la repetibilidad. |

**Video:** ≥ 60 cuadros/s; el LED de sincronización debe verse (eventos `SYNC_LED_ON`).
**No se avanza** al ensayo siguiente sin cumplir el anterior; si falla, se corrige la causa (geometría, montaje, cableado) y se repite.
