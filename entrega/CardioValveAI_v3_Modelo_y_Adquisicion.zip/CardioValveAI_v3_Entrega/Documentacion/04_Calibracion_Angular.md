# 04 · Calibración angular verificable

> CardioValveAI · revisión **v3** · prototipo académico de banco **sin fluido**. No es un dispositivo médico ni de diagnóstico; los resultados del banco no equivalen a diagnosticar una válvula implantada.
> **[CÁLCULO]** cálculo · **[GEOM]** inspección geométrica · **[SIM]** simulación · **[COMPILACIÓN]** compilación · **[SW]** prueba de software · **[FÍSICO]** pendiente de ensayo físico

## 1. Referencias
- **Cero mecánico:** cara superior de la valva paralela a la cara inferior del anillo (galga de 0°).
- **Galgas impresas** `Calib_Gauge_XX` (0, 5, 10, 15, 20, 30, 40, 50, 60, 70, 80°): se apoyan en la cara superior del anillo con una llave en la ranura de la valva 1; la cara de contacto toca la cara superior de
  la valva exactamente a ese ángulo (entre 7,5 y 13 mm del eje). Se usan en las 3 valvas (son iguales por simetría).
- **Verificación independiente:** video lateral frente al transportador `Angle_Scale` y video superior (hoyuelos de la línea central).

Comprobación digital de las galgas [SIM]: la valva 0,3° por debajo del ángulo no toca la galga; 0,7° por encima la penetra (la galga la detiene) y no toca ninguna otra pieza.

| galga | correcta | contacto 0,3° antes | contacto 0,7° después |
|---|---|---|---|
| 0° | ✔ | — | Leaflet_1 |
| 5° | ✔ | — | Leaflet_1 |
| 10° | ✔ | — | Leaflet_1 |
| 15° | ✔ | — | Leaflet_1 |
| 20° | ✔ | — | Leaflet_1 |
| 30° | ✔ | — | Leaflet_1 |
| 40° | ✔ | — | Leaflet_1 |
| 50° | ✔ | — | Leaflet_1 |
| 60° | ✔ | — | Leaflet_1 |
| 70° | ✔ | — | Leaflet_1 |
| 80° | ✔ | — | Leaflet_1 |

## 2. Procedimiento (`cvai_calibrate.py`)
1. `galgas --valva N`: el plato se mueve a mano o con el servo **desacoplado de esa valva**; la valva se apoya suavemente en cada galga, **primero abriendo** (0 → 80°) y **luego
   cerrando** (80 → 0°), al menos 3 repeticiones. En cada punto se promedia la lectura cruda (suma de 8 = 1 kS/s).
2. `video`: alternativa o verificación con ángulos leídos del video.
3. `ajustar`: curva monótona (PCHIP) por sensor; informa monotonía, si los puntos se distinguen (separación > 4σ del ruido), ruido, **resolución**, **repetibilidad**, **histéresis**
   y error de validación cruzada (dejando un punto afuera).
4. `subir`: guarda la calibración en la memoria NVS del ESP32 (con CRC). El firmware la valida (≥ 5 puntos, monótona, sin lecturas repetidas, rango ≥ 30°) y la informa en INFO y en
   STATUS. Sin calibración válida **no se muestran grados**: solo la lectura cruda.
5. `comparar`: después de desmontar y volver a montar un portasensor o un imán, se repite la calibración y se comparan las dos curvas.

**No se usa una conversión lineal mín/máx:** la relación es no lineal (doc 03). Si dos posiciones dan lecturas indistinguibles, o el sensor satura, la herramienta lo marca; la
corrección es geométrica (variante de portasensor, imán) y se repite el cálculo de doc 03.

## 3. Definiciones
- **Resolución:** cambio de ángulo más pequeño que se distingue del ruido (2σ / pendiente local), en grados.
- **Repetibilidad:** dispersión del ángulo estimado al volver al mismo punto varias veces (sin desmontar), por sentido de movimiento.
- **Histéresis / juego:** diferencia entre la curva de apertura y la de cierre en un mismo ángulo de galga.
- **Exactitud:** diferencia entre el ángulo estimado y la referencia independiente (video o galga no usada en el ajuste).

Ninguno de estos valores se midió todavía. Con datos **sintéticos** del emulador la herramienta calcula resolución 0,3–0,4° y error de validación cruzada ≈ 0,8° (prueba de
software, no del prototipo). **Objetivos propuestos:** resolución ≤ 1°, repetibilidad ≤ 1°, histéresis ≤ 2°, exactitud frente al video ≤ 3° máx. / 1,5° RMS.
