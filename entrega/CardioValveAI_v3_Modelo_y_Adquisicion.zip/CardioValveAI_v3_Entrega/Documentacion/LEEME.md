# CardioValveAI — paquete v3

> CardioValveAI · revisión **v3** · prototipo académico de banco **sin fluido**. No es un dispositivo médico ni de diagnóstico; los resultados del banco no equivalen a diagnosticar una válvula implantada.
> **[CÁLCULO]** cálculo · **[GEOM]** inspección geométrica · **[SIM]** simulación · **[COMPILACIÓN]** compilación · **[SW]** prueba de software · **[FÍSICO]** pendiente de ensayo físico

Banco universitario de válvula aórtica trivalva movida por un servo, **sin fluido**. Objetivo: comparar el movimiento REAL de las 3 valvas (un par Hall–imán por valva) y
detectar apertura o cierre incompletos, asimetrías, retrasos o variaciones y atascos. El micrófono INMP441 es una señal complementaria. El ángulo ordenado al servo no es la
posición de las valvas, y la animación no es una prueba.

Las entregas anteriores se conservan sin cambios: `entrega/CardioValAI_Modelo_Final_STL.zip` (v1) y `entrega/CardioValAI_v2_Modelo_y_Adquisicion.zip` (v2).
Todos los archivos de este paquete se generaron desde el mismo código (ver `REVISION.json`).

| Carpeta / archivo | Contenido |
|---|---|
| `Documentacion/01…10` | Auditoría, datos bloqueantes, Hall–imán, calibración, mecanismo, electrónica, firmware, herramientas, ensayos, pendientes |
| `Documentacion/Guia_de_Impresion_v3.md`, `Guia_de_Ensamblaje_v3.md`, `Lista_de_Materiales_v3.*`, `Informe_de_Validacion_v3.md` | Fabricación y verificación |
| `CardioValveAI_v3_STL/` | Piezas imprimibles individuales (mm, orientadas) |
| `CardioValveAI_v3_STEP/`, `CardioValveAI_v3_Assembly_Cerrada.step` | Sólidos editables y ensamblaje |
| `Referencia_NO_IMPRIMIR/` | Servo, ESP32 + placa, sensores, imanes, tornillería, cables |
| `CardioValveAI_v3_Final.blend` | Ensamblaje animado (Blender 4.5 LTS) |
| `CardioValveAI_v3_Animacion.mp4` | Animación cinemática (no es prueba de funcionamiento) |
| `Vistas/` | Par Hall–imán ampliado por valva, portasensor, galga, cables, micrófono, electrónica |
| `Electronica/` | Esquemas (SVG/PNG) |
| `CAD_parametrico/`, `Firmware/`, `Herramientas_Mac/`, `Electronica_fuente/` | Código fuente reproducible |
