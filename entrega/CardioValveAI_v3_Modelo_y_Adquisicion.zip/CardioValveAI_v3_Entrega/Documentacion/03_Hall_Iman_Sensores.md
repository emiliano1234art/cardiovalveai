# 03 · Par Hall–imán por valva: sensores, ubicación, montaje e interferencias

> CardioValveAI · revisión **v3** · prototipo académico de banco **sin fluido**. No es un dispositivo médico ni de diagnóstico; los resultados del banco no equivalen a diagnosticar una válvula implantada.
> **[CÁLCULO]** cálculo · **[GEOM]** inspección geométrica · **[SIM]** simulación · **[COMPILACIÓN]** compilación · **[SW]** prueba de software · **[FÍSICO]** pendiente de ensayo físico

## 1. Configuración
Un **imán** por valva, retenido en la cola cerca de la bisagra (4,0 mm del eje, a lo largo de la cola), y un **sensor Hall lineal** fijo en el anillo, en un
**portasensor extraíble** que entra desde arriba. El sensor mide la componente radial del campo; al abrir, el imán se aleja y la lectura cambia de forma **no lineal** y monótona.
El ángulo ordenado al servo **no** es la posición: la posición sale de este par, una vez calibrado (doc 04).

## 2. Coordenadas desde un origen común [GEOM]
Origen: esquina inferior de la base (x a lo largo de 200 mm, y a lo largo de 180 mm, z hacia arriba). Centro de la válvula (78,0; 92,0) mm; cara inferior del anillo
z = 64,07 mm; valvas hacia 90°, 210° y 330° (1, 2, 3). Archivo: `Coordenadas_Sensores_v3.csv`. Vistas ampliadas: `Vistas/Vista_Hall_Iman_Valva*_{cerrada,abierta}.png`.

| Punto | Descripción | (x; y; z) mm | Nota |
|---|---|---|---|
| H1 | elemento Hall, valva 1 | (86,0; 118,1; 77,1) | eje sensible radial (hacia afuera) |
| IMÁN1 0° | centro del imán, valva 1 cerrada | (81,5; 115,1; 75,6) | distancia al Hall 5,61 mm |
| IMÁN1 80° | centro del imán, valva 1 abierta | (81,5; 115,1; 70,5) | distancia al Hall 8,52 mm |
| H2 | elemento Hall, valva 2 | (51,4; 85,9; 77,1) | eje sensible radial (hacia afuera) |
| IMÁN2 0° | centro del imán, valva 2 cerrada | (56,3; 83,5; 75,6) | distancia al Hall 5,61 mm |
| IMÁN2 80° | centro del imán, valva 2 abierta | (56,3; 83,5; 70,5) | distancia al Hall 8,52 mm |
| H3 | elemento Hall, valva 3 | (96,6; 72,0; 77,1) | eje sensible radial (hacia afuera) |
| IMÁN3 0° | centro del imán, valva 3 cerrada | (96,2; 77,4; 75,6) | distancia al Hall 5,61 mm |
| IMÁN3 80° | centro del imán, valva 3 abierta | (96,2; 77,4; 70,5) | distancia al Hall 8,52 mm |
| M1 | centro de la placa INMP441 | (100,9; 52,3; 93,8) | soporte independiente; radial ±8 mm y pivote |

En el marco de cada valva (x radial hacia afuera, y a lo largo del eje de bisagra, z hacia arriba desde la cara inferior del anillo): elemento Hall en (26,1; -8,0; 13,0).

## 3. Sensores candidatos con esta geometría [CÁLCULO]
Modelo de dipolos (imán Ø4×2 N42 axial, Br 1,30 T supuesto). Criterio **propuesto**: incertidumbre angular 2σ/pendiente ≤ 1° en
0–80°, con ruido supuesto 1 mV tras promediar 8 muestras (se mide en el ensayo 3). Es un modelo aproximado: sirve para comparar sensores y comprobar monotonía,
no para predecir mV exactos.

| separación extra (mm) | sensor | V cerrada | V a 80° | satura | monótona | pendiente mín. (mV/°) | incertidumbre máx. (°) | cumple | nota |
|---|---|---|---|---|---|---|---|---|---|
| 0,00 | DRV5055A1 @3,3 V | 0,488 | 1,490 | no | sí | 2,96 | 0,68 | **sí** | 100 mV/mT a 5 V (TI); 66 a 3,3 V supone salida ratiométrica: VERIFICAR |
| 0,00 | DRV5055A2 @3,3 V | 1,069 | 1,570 | no | sí | 1,48 | 1,35 | no | 50 mV/mT a 5 V (TI); ratiométrica: VERIFICAR |
| 0,00 | DRV5055A3 @3,3 V | 1,360 | 1,610 | no | sí | 0,74 | 2,70 | no | 25 mV/mT a 5 V (TI): VERIFICAR |
| 0,00 | SS49E @3,3 V | 1,488 | 1,628 | no | sí | 0,41 | 4,84 | no | 1,4 mV/G a 5 V (distribuidores); escalado a 3,3 V NO confirmado |
| 0,00 | SS49E/49E @5 V + divisor 0,6 | 1,352 | 1,480 | no | sí | 0,38 | 5,31 | no | salida de 5 V reducida con divisor 20k/30k antes del ADC |
| 0,25 | DRV5055A1 @3,3 V | 0,520 | 1,486 | no | sí | 3,24 | 0,62 | **sí** | 100 mV/mT a 5 V (TI); 66 a 3,3 V supone salida ratiométrica: VERIFICAR |
| 0,25 | DRV5055A2 @3,3 V | 1,085 | 1,568 | no | sí | 1,62 | 1,24 | no | 50 mV/mT a 5 V (TI); ratiométrica: VERIFICAR |
| 0,25 | DRV5055A3 @3,3 V | 1,368 | 1,609 | no | sí | 0,81 | 2,47 | no | 25 mV/mT a 5 V (TI): VERIFICAR |
| 0,25 | SS49E @3,3 V | 1,493 | 1,627 | no | sí | 0,45 | 4,43 | no | 1,4 mV/G a 5 V (distribuidores); escalado a 3,3 V NO confirmado |
| 0,25 | SS49E/49E @5 V + divisor 0,6 | 1,356 | 1,479 | no | sí | 0,41 | 4,86 | no | salida de 5 V reducida con divisor 20k/30k antes del ADC |
| 0,50 | DRV5055A1 @3,3 V | 0,563 | 1,483 | no | sí | 2,27 | 0,88 | **sí** | 100 mV/mT a 5 V (TI); 66 a 3,3 V supone salida ratiométrica: VERIFICAR |
| 0,50 | DRV5055A2 @3,3 V | 1,106 | 1,566 | no | sí | 1,13 | 1,76 | no | 50 mV/mT a 5 V (TI); ratiométrica: VERIFICAR |
| 0,50 | DRV5055A3 @3,3 V | 1,378 | 1,608 | no | sí | 0,57 | 3,53 | no | 25 mV/mT a 5 V (TI): VERIFICAR |
| 0,50 | SS49E @3,3 V | 1,498 | 1,627 | no | sí | 0,32 | 6,32 | no | 1,4 mV/G a 5 V (distribuidores); escalado a 3,3 V NO confirmado |
| 0,50 | SS49E/49E @5 V + divisor 0,6 | 1,362 | 1,479 | no | sí | 0,29 | 6,93 | no | salida de 5 V reducida con divisor 20k/30k antes del ADC |

**Conclusión:** con esta geometría solo el **DRV5055A1** (≈ 66 mV/mT a 3,3 V, supuesto ratiométrico) cumple el objetivo de ≤ 1°. La familia **49E/SS49E/AH49E** tiene
una sensibilidad ≈ 7 veces menor: la incertidumbre estimada es de ≈ 4–7° cerca de 80°. Se puede usar para ver **que** la valva se mueve, pero no para medir el ángulo con la
resolución pedida. Alternativas si ya se tienen 49E: alimentarlos a 5 V con divisor (Hoja 2, opción B; no mejora la resolución) o acercar/agrandar el imán (cambia la geometría y
el riesgo de saturación: requiere rehacer el cálculo y la probeta). **A3144:** no sirve (salida digital; ver doc 02).

Campo calculado en el sensor (variante 0):

| θ (°) | |B| (mT) |
|---|---|
| -2 | 17,80 |
| 0 | 17,60 |
| 5 | 16,80 |
| 10 | 15,61 |
| 20 | 12,55 |
| 30 | 9,41 |
| 40 | 6,85 |
| 50 | 5,01 |
| 60 | 3,78 |
| 70 | 2,97 |
| 80 | 2,42 |
| 84 | 2,26 |

Tolerancia de posición del sensor (¿sigue siendo monótona?):

| desplazamiento | monótona | pendiente mín. (mT/°) | campo máx. (mT) |
|---|---|---|---|
| x+0,5 mm | sí | 0,0365 | 16,5 |
| x-0,5 mm | sí | 0,0297 | 18,6 |
| y-0,5 mm | sí | 0,0326 | 14,0 |
| z+0,5 mm | sí | 0,0293 | 16,2 |
| z-0,5 mm | sí | 0,0517 | 19,2 |

Con **+1 mm** en x (más lejos del imán) la curva deja de ser monótona: por eso el lomo del portasensor apoya contra la cara exterior del bolsillo (x = 29,4) y
las variantes solo agregan 0,25 o 0,5 mm. **No se declara una distancia «óptima»**: la elegida es una posición que, según el modelo, da una curva monótona con margen ±0,5 mm.

## 4. Portasensor extraíble (`Hall_Carrier_000/025/050`) [GEOM/SIM]
- Entra desde arriba en el bolsillo del anillo; la pestaña (1,2 mm) apoya en la cara superior y fija la altura; el lomo apoya en la pared exterior y fija la distancia radial.
- Sensor TO-92 con la cara plana hacia el centro de la válvula, pegado al lomo con una gota de **silicona neutra** (removible). Patas hacia arriba, cable por el canal del portasensor y
  la bajada exterior del anillo (fijo, protegido, accesible).
- **Cambio de sensor:** tirar de la pestaña (agujero Ø1,2 para un gancho) sin desmontar valvas, bielas ni anillo. Comprobado: la extracción vertical no choca con otras piezas
  (comprobaciones de montaje en el informe). **Cambio de imán:** retirar el eje de la valva (doc de ensamblaje); el imán sale empujando desde el lado opuesto con un pasador fino.
- Variantes: `000` nominal (se monta en las 3 valvas); `025` y `050` alejan el sensor **solo si satura** con los imanes comprados. Número grabado en la pestaña.

## 5. Holguras con piezas vecinas en todo el recorrido [SIM]
| Par | mínimo (mm) | modo |
|---|---|---|
| Leaflet_1 ↔ Hall_1 | 1,46 | CIERRE_INCOMPLETO |
| Leaflet_1 ↔ Hall_Carrier_1 | 1,50 | NORMAL |
| Magnet_1 ↔ Hall_1 | 1,50 | NORMAL |
| Tail_Pin_1 ↔ Hall_Carrier_1 | 1,53 | ASIMETRICO |

Sin contacto entre imán, sensor, portasensor, valvas vecinas, bielas, pasadores, plato, columnas y topes en las 125 poses.

## 6. Imán: masa, retención y atracción [CÁLCULO]
- Masa del imán ≈ 0,188 g (densidad 7,5 g/cm³). Momento extra sobre la bisagra ≈ 0,0074 N·mm: despreciable frente al
  peso de la valva.
- **Retención:** alojamiento Ø4,20 × 2,2 mm a ras de la cara −y de la cola, una gota de cianoacrilato. El diámetro final se elige
  con la fila 5 de la probeta (Ø4,05–4,30). **Polaridad marcada** igual en las 3 valvas.
- **Atracción a piezas metálicas:** ejes y pasadores de **latón**, tornillos de los topes de latón (no magnéticos). Mantener herramientas de acero alejadas durante la calibración.
- **Imanes vecinos:** variación por el movimiento de las otras dos valvas ≈ 4,9 µT → ≈ 0,32 mV
  con A1 (< 0,1°). Se verifica en el ensayo 4: cada Hall con su valva quieta mientras se mueven las otras.
- **Servo:** imán del motor a ≈ 57 mm; con momentos supuestos de 0,005–0,05 A·m² da 5–54 µT (orden de magnitud; constante con el servo quieto,
  variable si el rotor gira). Se mide en el ensayo 6 (servo moviéndose desacoplado).
- Campo terrestre (≈ 50 µT, constante) y temperatura (−0,12 %/°C del N42): los absorbe la calibración si se calibra a la temperatura de trabajo.
