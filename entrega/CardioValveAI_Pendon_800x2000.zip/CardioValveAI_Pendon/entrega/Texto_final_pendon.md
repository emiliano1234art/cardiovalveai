# CardioValveAI · Texto final del pendón (800 × 2000 mm)

Texto tal como aparece en el diseño, en orden de lectura. Corregir aquí y volver a generar con `python pendon.py`
(los textos se editan en `pendon.py`, función `build()`, en cada llamada `T(...)`).

Palabras del texto principal (sin etiquetas de componentes): 350

## Alternativas de frase principal

1. «Convertimos el movimiento de una válvula en datos medibles.» — ELEGIDA: dice qué hace el prototipo, en una sola idea, sin prometer resultados clínicos.
2. «Un modelo de válvula aórtica que se mueve, se mide y se estudia.» — Clara, pero más larga y menos directa a 3 m.
3. «Observar cómo se mueve una válvula para entender mejor la respuesta del cuerpo.» — Apunta al objetivo de investigación, pero puede leerse como un resultado ya demostrado.

## A · Encabezado

- Etiqueta: Prototipo de banco · válvula aórtica de tres valvas
- Nombre: CardioValveAI
- Frase principal: Convertimos el movimiento de una válvula en datos medibles.
- Pregunta: ¿Qué puede contarnos el movimiento de una válvula?

## B · Modelo

- Llamada: **3 valvas móviles** — Abren y cierran juntas
- Llamada: **Sensor Hall + imán** — Uno por valva
- Llamada: **Servomotor** — Mueve las tres valvas
- Llamada: **Estructura impresa en 3D** — Anillo de 90 mm
- Pie de imagen: Imagen generada a partir del modelo 3D del prototipo actual (valvas abiertas).

**Por dentro** — El servomotor sube y baja un pistón que abre y cierra las tres valvas. _(nota: Estructura oculta para ver el mecanismo)_

**Un sensor por valva** — El imán gira con la valva. El sensor Hall queda fijo. Rótulos: «imán», «sensor Hall». _(nota: Portasensor separado para mostrar el imán)_

Componentes: Estructura impresa en 3D · 3 valvas · Servomotor · 3 sensores Hall · 3 imanes de neodimio · ESP32

## C · ¿Por qué mirar una válvula?

En cada latido, las válvulas del corazón abren y cierran. Cuánto se abren, cuándo y con qué coordinación es parte de cómo funciona el corazón.

Queremos saber si ese movimiento puede medirse de forma simple y, más adelante, relacionarse con la respuesta funcional de una persona.

**Pregunta de investigación:** ¿Puede un sistema simple de sensores describir el movimiento valvular con datos comparables?

## D · Del movimiento a los datos

1. **La valva se mueve** — El imán gira con ella.
2. **El campo cambia** — El sensor Hall, fijo, lo detecta.
3. **El ESP32 registra** — Lee los 3 sensores y controla el servo.
4. **Vemos y analizamos** — Una señal por valva en el computador.

Nota: La señal del sensor no es un ángulo: para expresarla en grados, cada valva se calibra con posiciones conocidas.

## E · Qué observamos

_Esquemas ilustrativos, no son resultados_

- Apertura y cierre
- Coordinación de las 3 valvas
- Tiempos del movimiento
- Cambios frente a un patrón de referencia

## F · Hoy y a futuro

- **Hoy · prototipo:** Modelo de banco que mueve tres valvas y registra una señal por valva. Sin fluido ni pacientes.
- **Lo que estudiamos:** Qué variables del movimiento son medibles, repetibles y comparables.
- **A futuro:** Tras una validación adecuada: apoyo al seguimiento funcional y a la rehabilitación cardiorrespiratoria personalizada, con inteligencia artificial.

Nota: La inteligencia artificial es una línea de desarrollo futuro; hoy, el software compara cada ciclo con un patrón de referencia. Prototipo académico: no es un dispositivo médico ni entrega diagnósticos.

## G · Invitación

Acércate: mira el mecanismo en movimiento y conversemos.
