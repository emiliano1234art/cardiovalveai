# CardioValveAI · Pendón: fuentes, estado y datos por confirmar

## Archivos
| Archivo | Uso |
|---|---|
| `CardioValveAI_Pendon_800x2000_sin_sangrado.pdf` | Tamaño final exacto 800 × 2000 mm (proporción 2:5). |
| `CardioValveAI_Pendon_800x2000_sangrado10mm.pdf` | 820 × 2020 mm: 10 mm de sangrado por lado, con TrimBox = 800 × 2000 mm y BleedBox. |
| `../CardioValveAI_Pendon_800x2000.svg` | Editable (Illustrator, Inkscape, Affinity): 1 unidad = 1 mm, textos vivos, iconos y diagramas vectoriales, imágenes enlazadas en `imagenes/`, capas por sección (A_encabezado … G_invitacion). Instalar antes las fuentes de `fuentes/`. |
| `../pendon.py` | Genera el SVG y los PDF; los textos están en cada `T('clave', 'texto')`. |
| `Texto_final_pendon.md` | Texto del pendón separado del diseño. |
| `vista_previa.png`, `acercamiento_*.png` | Revisión en pantalla (baja resolución, no imprimir). |

## Fuentes del contenido
- **Modelo:** CardioValveAI **v4** (`hardware/v4/config4.py`, REVISION = v4), la versión más reciente del repositorio. Es la única sin micrófono ni piezoeléctricos (3 sensores Hall + 3 imanes). Las versiones v1–v3.1 no se usaron.
- **Imágenes:** todas son renders generados desde los sólidos del CAD v4 (`hardware/out_v4/_canon/*.stl`) con su cinemática (`assembly4.py`, `kin4.py`); la geometría no se modificó. Los **colores son de presentación** (el color real depende del filamento). En «Un sensor por valva» el portasensor se muestra separado 12 mm a lo largo de su eje para ver el imán (rotulado). En «Por dentro» la estructura está oculta (rotulado).
- **No hay fotografías** del prototipo en los archivos: no se usó ninguna.
- **Textos:** documentación del repositorio (`hardware/README.md`, `hardware/out_v4/Documentacion`, `README.md`). No se usaron cifras, estadísticas ni fuentes externas: no hay referencias bibliográficas que citar.
- **Inteligencia artificial:** el repositorio no documenta un algoritmo entrenado ni validado para el banco. El software de análisis (`hardware/host/cvai_analyze.py`) compara cada ciclo con un patrón de referencia mediante umbrales definidos por el equipo. Por eso la IA aparece solo como desarrollo futuro.
- **Curvas de «Qué observamos»:** esquemas dibujados, rotulados «Esquemas ilustrativos, no son resultados». No hay capturas de dashboard.
- **Tipografía:** una familia, Inter (Inter Display para el nombre). Licencia SIL Open Font License (`fuentes/Inter_LICENSE_OFL.txt`). Fuentes incrustadas como subconjunto en los PDF; el texto queda vectorial.
- **Sin** logos institucionales, nombres de integrantes, facultades, carreras, marcas de herramientas, marcas de agua ni QR (no se entregó un enlace).

## Calidad de las imágenes al tamaño final
| Imagen | Píxeles | Tamaño impreso | Resolución efectiva |
|---|---|---|---|
| protagonista | 3347 × 3509 px | 520 × 545 mm | **163 ppp** |
| mecanismo | 1467 × 1333 px | 130 × 118 mm | **287 ppp** |
| detalle_hall_iman | 2256 × 1588 px | 168 × 118 mm | **342 ppp** |
| superior_cerrada | 911 × 896 px | 52 × 51 mm | **445 ppp** |
| superior_abierta | 911 × 896 px | 52 × 51 mm | **445 ppp** |

Ninguna imagen fue ampliada. Texto, iconos, diagramas y curvas son vectoriales.

## Datos por confirmar antes de imprimir
1. **Estado del prototipo el día de la feria.** «Hoy · prototipo» dice: «Modelo de banco que mueve tres valvas y registra una señal por valva». Es correcto solo si el prototipo v4 está impreso, armado y registrando con el ESP32. Hasta esta revisión, el diseño solo está verificado en CAD (no se ha impreso ni probado). Si no está funcionando, cambiar a «Modelo de banco diseñado para mover tres valvas…».
2. **Fotografía real (recomendado).** Cuando el prototipo esté armado, una foto bien iluminada (≥ 3600 px de ancho para 520 mm) puede reemplazar o acompañar el render. Hasta entonces, el pie aclara que es una imagen generada desde el modelo 3D.
3. **Pregunta de investigación y enfoque** («respuesta funcional», «rehabilitación cardiorrespiratoria personalizada»): validar la redacción con el profesor guía.
4. **Logo:** no se adjuntó; se usó el nombre como composición tipográfica (sin emblema).
5. **Imprenta:**
   - **Sangrado:** se entrega con 10 mm; confirmar su valor.
   - **Zona oculta del soporte:** si es un roll-up, confirmar cuánto material queda dentro de la base o del travesaño. Esa reserva debe agregarse fuera de los 2000 mm visibles, sin deformar el diseño. El contenido esencial termina a 1840 mm desde arriba; la banda de invitación ocupa de 1885 a 1959 mm; deja 41 mm libres abajo.
   - **Color:** los PDF están en **RGB (sRGB)**. No se pudo convertir a CMYK ni aplicar un perfil ICC (p. ej. FOGRA39) desde este entorno: pedir a la imprenta su perfil o que haga la conversión, y una prueba de color del turquesa (#0E8F95) y del coral (#E2553B).
   - **Formato:** los PDF no están certificados como PDF/X. Si la imprenta lo exige, exportar desde el SVG con su configuración (PDF/X-4).
6. **Medida del anillo:** el rótulo dice «Anillo de 90 mm» (diámetro exterior del cuerpo v4). Cambiarlo si se modifica el diseño.

## Revisión realizada
Nombre CardioValveAI (sin espacios, con esas mayúsculas) · ortografía y acentos · tamaño 800 × 2000 mm y proporción 2:5 · márgenes laterales de 45 mm (comprobados automáticamente para cada texto) · sin texto cortado ni superpuesto · sin micrófono ni piezoeléctricos (búsqueda en el texto del PDF) · actual / objetivo / futuro diferenciados · sin resultados, validaciones ni cifras inventadas · 350 palabras de texto principal.
