# Lista de materiales v3.1 (mínima)

> CardioValveAI · revisión **v3.1** · prototipo académico de banco **sin fluido**. No es un dispositivo médico ni de diagnóstico; los resultados del banco no equivalen a diagnosticar una válvula implantada.
> **[CÁLCULO]** cálculo · **[GEOM]** inspección geométrica · **[SIM]** simulación · **[COMPILACIÓN]** compilación · **[SW]** prueba de software · **[FÍSICO]** pendiente de ensayo físico

| Elemento | Cant. | Tipo | Medidas | Función / nota |
|---|---|---|---|---|
| Valve_Ring | 1 | impresa (PETG) | 70,0 × 70,0 × 24,0 mm · 28,8 g | Anillo valvular con comisuras, bisagras, ranuras de mando y 3 bolsillos con ventana para los portasensores Hall  |
| Hall_Carrier_000 | 3 | impresa (PETG) | 8,1 × 4,0 × 8,2 mm · 0,1 g | Portasensor Hall extraíble, sensor alejado 0.00 mm del imán (NOMINAL: se monta en las 3 valvas) NO DEFINITIVA |
| Hall_Carrier_025 | 3 | impresa (PETG) | 7,9 × 4,0 × 8,2 mm · 0,1 g | Portasensor Hall extraíble, sensor alejado 0.25 mm del imán (ALTERNATIVA: solo si el sensor satura) NO DEFINITIVA |
| Hall_Carrier_050 | 3 | impresa (PETG) | 7,6 × 4,0 × 8,2 mm · 0,1 g | Portasensor Hall extraíble, sensor alejado 0.50 mm del imán (ALTERNATIVA: solo si el sensor satura) NO DEFINITIVA |
| Calib_Gauge_00 | 1 | impresa (PETG) | 27,6 × 15,0 × 11,6 mm · 1,3 g | Galga angular de calibración: la cara superior de la valva la toca a 0°  |
| Calib_Gauge_05 | 1 | impresa (PETG) | 27,6 × 14,3 × 11,6 mm · 1,3 g | Galga angular de calibración: la cara superior de la valva la toca a 5°  |
| Calib_Gauge_10 | 1 | impresa (PETG) | 27,6 × 13,7 × 11,6 mm · 1,2 g | Galga angular de calibración: la cara superior de la valva la toca a 10°  |
| Calib_Gauge_15 | 1 | impresa (PETG) | 27,4 × 13,0 × 11,6 mm · 1,2 g | Galga angular de calibración: la cara superior de la valva la toca a 15°  |
| Calib_Gauge_20 | 1 | impresa (PETG) | 27,2 × 12,4 × 11,6 mm · 1,2 g | Galga angular de calibración: la cara superior de la valva la toca a 20°  |
| Calib_Gauge_30 | 1 | impresa (PETG) | 26,4 × 11,1 × 11,6 mm · 1,1 g | Galga angular de calibración: la cara superior de la valva la toca a 30°  |
| Calib_Gauge_40 | 1 | impresa (PETG) | 25,2 × 9,9 × 11,6 mm · 1,0 g | Galga angular de calibración: la cara superior de la valva la toca a 40°  |
| Calib_Gauge_50 | 1 | impresa (PETG) | 23,7 × 9,2 × 11,6 mm · 0,9 g | Galga angular de calibración: la cara superior de la valva la toca a 50°  |
| Calib_Gauge_60 | 1 | impresa (PETG) | 22,0 × 10,3 × 11,6 mm · 0,9 g | Galga angular de calibración: la cara superior de la valva la toca a 60°  |
| Calib_Gauge_70 | 1 | impresa (PETG) | 20,0 × 10,9 × 11,6 mm · 0,8 g | Galga angular de calibración: la cara superior de la valva la toca a 70°  |
| Calib_Gauge_80 | 1 | impresa (PETG) | 17,8 × 11,1 × 11,6 mm · 0,8 g | Galga angular de calibración: la cara superior de la valva la toca a 80°  |
| Leaflet_1 | 1 | impresa (PETG) | 28,3 × 33,9 × 10,6 mm · 1,7 g | Valva 1 (semilunar simplificada, barril de bisagra y cola de mando)  |
| Leaflet_2 | 1 | impresa (PETG) | 28,3 × 33,9 × 10,6 mm · 1,7 g | Valva 2 (semilunar simplificada, barril de bisagra y cola de mando)  |
| Leaflet_3 | 1 | impresa (PETG) | 28,3 × 33,9 × 10,6 mm · 1,7 g | Valva 3 (semilunar simplificada, barril de bisagra y cola de mando)  |
| Link_Normal | 4 | impresa (PETG) | 6,0 × 32,0 × 3,0 mm · 0,7 g | Biela rígida (modo normal). 3 + 1 de repuesto  |
| Link_LostMotion | 2 | impresa (PETG) | 6,0 × 37,5 × 3,0 mm · 0,7 g | Biela con recorrido perdido (apertura restringida / asimétrica). 1 marca  |
| Link_LostMotion_IC | 1 | impresa (PETG) | 6,0 × 36,1 × 3,0 mm · 0,7 g | Biela corta con recorrido perdido (cierre incompleto 12°). 2 marcas  |
| Opening_Stop_84 | 3 | impresa (PETG) | 11,0 × 12,0 × 4,4 mm · 0,4 g | Tope de seguridad (84°) — se usa en modo normal y cierre incompleto  |
| Opening_Stop_60 | 1 | impresa (PETG) | 11,0 × 12,0 × 7,2 mm · 0,5 g | Tope intercambiable 60°  |
| Opening_Stop_45 | 1 | impresa (PETG) | 11,0 × 12,0 × 8,3 mm · 0,5 g | Tope intercambiable 45°  |
| Actuator_Plate | 1 | impresa (PETG) | 66,6 × 69,5 × 13,0 mm · 13,8 g | Plato actuador (corredera) con bujes, orejetas y horquilla  |
| Pushrod | 1 | impresa (PETG) | 5,6 × 35,6 × 3,0 mm · 0,7 g | Empujador servo → plato  |
| Column | 3 | impresa (PETG) | 8,0 × 8,0 × 93,6 mm · 4,7 g | Columna guía con espárragos M6 impresos: abajo se enrosca en la base, arriba recibe la tuerca moleteada del anillo  |
| Cable_Clip | 3 | impresa (PETG) | 16,8 × 11,8 × 6,0 mm · 0,7 g | Pinza de cables a presión en cada columna (bajo el recorrido del plato)  |
| MEMS_Stand | 1 | impresa (PETG) | 44,0 × 35,0 × 76,6 mm · 20,3 g | Soporte independiente del micrófono M1 (configuración inicial recomendada): ranura radial ±8 mm y pivote de inclinación  |
| MEMS_Stand_Holder | 1 | impresa (PETG) | 28,9 × 18,9 × 7,0 mm · 1,1 g | Portaplaca del INMP441 con lengüeta de pivote NO DEFINITIVA |
| Servo_Mount | 1 | impresa (PETG) | 45,4 × 43,0 × 20,2 mm · 7,6 g | Soporte del servo con escuadras (medidas del servo por confirmar) NO DEFINITIVA |
| Electronics_Tray | 1 | impresa (PETG) | 79,4 × 103,8 × 9,6 mm · 35,4 g | Bandeja de la placa perforada 70×90 (ESP32 en zócalos hembra, antena libre, USB accesible) NO DEFINITIVA |
| Turn_Button | 5 | impresa (PETG) | 6,4 × 14,4 × 7,4 mm · 0,3 g | Pestillo giratorio que sujeta la placa perforada (4 + 1 de repuesto): reemplaza barras y tornillos NO DEFINITIVA |
| Angle_Scale | 1 | impresa (PETG) | 92,7 × 70,0 × 2,0 mm · 16,4 g | Transportador 0–90° para medir la valva 1 con cámara lateral  |
| Base | 1 | impresa (PETG) | 200,0 × 180,0 × 6,0 mm · 269,1 g | Base modular 200 × 180 mm con roscas M6 impresas y ranuras para bridas NO DEFINITIVA |
| Tolerance_Coupon | 1 | impresa (PETG) | 66,0 × 46,0 × 6,5 mm · 23,2 g | Probeta: ejes de latón libres y a presión (también para cabezas y tuercas a presión), pilotos, paso M6, espiga del pestillo e imán Ø4  |
| Thread_Coupon | 1 | impresa (PETG) | 42,0 × 14,0 × 6,0 mm · 3,8 g | Probeta de roscas M6 impresas (compensación 0,10 / 0,20 / 0,30 mm): se prueba con un perno M6×8  |
| Bolt_M6x8 | 9 | impresa (PETG) | 10,0 × 10,0 × 12,0 mm · 0,6 g | Perno M6×8 impreso, cabeza moleteada: soporte del servo (4), bandeja (2), soporte del micrófono (2) + 1 de repuesto  |
| Knurled_Nut_M6 | 4 | impresa (PETG) | 9,0 × 9,0 × 6,0 mm · 0,3 g | Tuerca M6 moleteada impresa: fija el anillo sobre el espárrago de cada columna (3 + 1)  |
| Pin_Head | 10 | impresa (PETG) | 3,8 × 3,8 × 1,6 mm · 0,0 g | Cabeza impresa del pasador de latón Ø2 (8 + 2): topes, bielas, horquilla y pivote del micrófono  |
| Push_Nut | 10 | impresa (PETG) | 4,6 × 4,0 × 1,6 mm · 0,0 g | Tuerca hexagonal impresa A PRESIÓN sobre el latón Ø2 (8 + 2): reemplaza las tuercas M2  |
| ESP32 DevKit V1 (ESP32-WROOM-32) | 1 | comprada | | Medidas por confirmar (doc 02) |
| Servo (modelo por confirmar) + horns + sus tornillos | 1 | comprada | | Los tornillos del servo son los únicos metálicos |
| Fuente 5 V ≥ 2 A (3 A recom.) | 1 | comprada | | según el servo real |
| Imán neodimio Ø4×2 mm axial (N42) | 5 | comprada | | +2 de repuesto; medidas por confirmar |
| Sensor Hall lineal TI DRV5055A1QLPG (TO-92) | 4 | comprada | | recomendado; verificar modelo (doc 02) |
| INMP441 (placa de módulo) | 1 | comprada | | medidas por confirmar |
| Microchip MCP1700-3302 (TO-92) + 2 × 1 µF | 1 | comprada | | 3V3_A de los Hall |
| AO3401A + 10 kΩ | 1 | comprada | | polaridad invertida |
| PTC 2,5 A | 1 | comprada | |  |
| TVS SMBJ5.0A | 1 | comprada | |  |
| Capacitor 1000 µF 10 V bajo ESR | 1 | comprada | |  |
| Capacitores 100 nF cerámicos | 8 | comprada | | desacoplo y RC Hall |
| Resistencias 1 kΩ (×3), 220 Ω, 10 kΩ (×2), 330 Ω, 33 Ω | 1 | comprada | | surtido |
| Resistencias 20 kΩ y 30 kΩ (×3 c/u) | 1 | comprada | | solo opción B (sensor de 5 V) |
| Placa perforada 7×9 cm | 1 | comprada | |  |
| Tiras de zócalo hembra 2,54 mm | 2 | comprada | | según pines del ESP32 |
| Conector con traba 2 vías (J1) / bornera | 2 | comprada | | 5 V servo |
| Parada de emergencia (NC + NA) | 1 | comprada | |  |
| LED + 330 Ω | 1 | comprada | | sincronización |
| Cable de 3 hilos fino | 3 | comprada | | Hall, ≈ 30 cm |
| Cable plano 6 hilos | 1 | comprada | | micrófono ≤ 20 cm |
| Varilla de LATÓN Ø2 mm (≥ 350 mm en total; p. ej. 2 × 300 mm) | 1 | comprada | | ejes, pasadores y fijaciones: 301 mm + corte |
| Filamento PETG 1,75 mm | 1 | comprada | | 1 kg: piezas + todas las fijaciones impresas |
| Grasa PTFE, cianoacrilato, silicona neutra, bridas, patas de goma adhesivas | 1 | comprada | |  |
