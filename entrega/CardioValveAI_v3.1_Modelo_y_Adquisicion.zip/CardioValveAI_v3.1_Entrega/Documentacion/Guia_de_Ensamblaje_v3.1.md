# Guía de ensamblaje v3.1

> CardioValveAI · revisión **v3.1** · prototipo académico de banco **sin fluido**. No es un dispositivo médico ni de diagnóstico; los resultados del banco no equivalen a diagnosticar una válvula implantada.
> **[CÁLCULO]** cálculo · **[GEOM]** inspección geométrica · **[SIM]** simulación · **[COMPILACIÓN]** compilación · **[SW]** prueba de software · **[FÍSICO]** pendiente de ensayo físico

Herramientas: alicate de punta, calibre, gancho fino, sierra o alicate de corte para latón, lima, cianoacrilato, silicona neutra, grasa PTFE, bridas finas.
**No hace falta soldador de insertos ni llaves:** todas las uniones roscadas son M6 impresas y se aprietan **con los dedos** (una herramienta barre la rosca de plástico).

1. **Probetas:** `Tolerance_Coupon` (latón, imanes, paso M6, espiga del pestillo) y `Thread_Coupon` + un `Bolt_M6x8` (rosca). Ajustar `config.py` y regenerar si hace falta.
2. **Cortar la varilla de latón Ø2:** 3 × 56 mm (ejes), 3 × 9 mm (cola–biela), 3 × 18,1 mm (topes), 3 × 8,6 mm (bielas),
   1 × 11,6 mm (horquilla), 1 × 14,0 mm (pivote del micrófono). Limar las puntas.
3. **Cabezas de pasador:** a presión una `Pin_Head` en un extremo de cada pasador de topes, bielas, horquilla y pivote, con una gota de cianoacrilato. Dejar secar.
4. **Imanes:** uno por valva en la cola, con cianoacrilato y **la misma cara hacia afuera en las tres**.
5. **Columnas → base:** enroscar cada columna a mano en su rosca de la base hasta que el cono asiente. Sin herramientas.
6. **Servo:** centrarlo (90°) antes de colocar el horn; al `Servo_Mount` con sus tornillos; soporte a la base con 4 `Bolt_M6x8` apretados con los dedos.
7. **Plato:** grasa PTFE en los bujes; deslizar sobre las columnas. Empujador a la horquilla: pasador con cabeza desde −y y `Push_Nut` empujada con alicate.
8. **Valvas + bielas:** pasador Ø2×9 a presión en la cola, biela en el pasador.
9. **Valvas en el anillo:** eje de latón Ø2×56 desde afuera; cianoacrilato solo en los extremos. Girar a mano 0–90° sin roce.
10. **Topes:** `Opening_Stop_84` desde abajo; pasador con cabeza desde arriba por el agujero del anillo; `Push_Nut` en la trampa hexagonal de la brida, empujada hasta que el tope quede firme.
11. **Hall:** sensor pegado al lomo del portasensor `000` con una gota de silicona; insertar desde arriba hasta que apoye la pestaña.
12. **Anillo sobre las columnas:** servo en posición abierta (plato abajo); unir cada biela a su orejeta (pasador con cabeza + `Push_Nut`); bajar el anillo por los
    espárragos y colocar las 3 `Knurled_Nut_M6`, apretadas con los dedos.
13. **Comprobar a mano** (ensayo 5) con el empujador desconectado y luego conectado.
14. **Micrófono:** placa en `MEMS_Stand_Holder`; pivote con pasador + `Push_Nut` (más presión = más fricción); soporte a la base con 2 `Bolt_M6x8` por las ranuras.
15. **Electrónica:** bandeja a la base con 2 `Bolt_M6x8` (en diagonal) ANTES de la placa; placa perforada sobre los rieles; los 4 `Turn_Button` en sus postes, girados hacia
    la placa. Comprobar 3V3_A y la salida de cada Hall con multímetro **antes** de conectar el ESP32.
16. **Cables:** pinzas en las columnas; señales por el sur, servo/5 V por el norte; mover el servo a mano y comprobar que nada roce.
17. **Desarme:** las `Push_Nut` se sacan haciendo palanca con el alicate (si quedan flojas, usar una nueva: hay 2 de repuesto). Revisar las roscas M6 después de 24 h
    (el PETG se asienta): volver a apretar con los dedos si hace falta.
