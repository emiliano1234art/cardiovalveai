# 05 · Revisión del mecanismo

> CardioValveAI · revisión **v3.1** · prototipo académico de banco **sin fluido**. No es un dispositivo médico ni de diagnóstico; los resultados del banco no equivalen a diagnosticar una válvula implantada.
> **[CÁLCULO]** cálculo · **[GEOM]** inspección geométrica · **[SIM]** simulación · **[COMPILACIÓN]** compilación · **[SW]** prueba de software · **[FÍSICO]** pendiente de ensayo físico

## 1. Geometría [GEOM/SIM]
- Valvas de 1,6 mm sobre ejes de latón a 20 mm del centro; holgura con la pared ≥ 1,0 mm hasta 86°; separación entre bordes
  al cerrar 1,0 mm (sin contacto valva–valva).
- Carrera del plato 10,285 mm; radio del horn 8,0 mm → barrido ±40,0° (comando 50,0° = abierta, 130,0° = cerrada).
- Bujes del plato con 0,3 mm de holgura radial y 12 mm de largo; holgura de piezas móviles 0,40 mm.

## 2. Modos, piezas intercambiables y simultáneas [CÁLCULO]
| Modo | Módulos (valva 1, 2, 3) | Recorrido de cada valva |
|---|---|---|
| NORMAL | N, N, N | v1: 0→80° · v2: 0→80° · v3: 0→80° |
| RESTRINGIDA_60 | R60, N, N | v1: 0→60° · v2: 0→80° · v3: 0→80° |
| RESTRINGIDA_45 | R45, N, N | v1: 0→45° · v2: 0→80° · v3: 0→80° |
| CIERRE_INCOMPLETO | IC, N, N | v1: 12→84° · v2: 0→80° · v3: 0→80° |
| ASIMETRICO | R60, R45, N | v1: 0→60° · v2: 0→45° · v3: 0→80° |

- **Siempre montadas:** anillo, 3 valvas con imán, 3 portasensores Hall, plato, empujador, columnas, servo, micrófono en su soporte.
- **Intercambiables por valva:** `Link_Normal` + tope 84° (normal) **o** `Link_LostMotion` + tope 60°/45° + elástico (restringida/asimétrica) **o** `Link_LostMotion_IC` + tope 84° +
  elástico (cierre incompleto). Asimétrico = valva 1 con 60° y valva 2 con 45°.
- **Nunca se fuerza el servo contra un tope:** en modo normal la valva llega a 80° y el tope está en 84°; en los modos alterados la ranura de la biela absorbe el resto de la
  carrera. Además, el firmware limita el ángulo calibrado (−8…86° por defecto) y **se detiene si ninguna valva se mueve** durante un movimiento ordenado.

## 3. Transmisión, punto muerto y velocidad [CÁLCULO]
- Ángulo mínimo entre palanca y empujador respecto de 0°/180° en todo el recorrido: **48,2°** (lejos del punto muerto).
- Par: fuerza en el empujador 1,75 N → 0,143 kg·cm frente a 1,8 kg·cm del MG90S (dato de distribuidores, **no verificado**; servo real por
  confirmar) → margen ×12,6.
- Velocidad pico pedida (perfil coseno) frente a 600 °/s sin carga (dato no verificado):

| t_apertura (ms) | velocidad pico (°/s) | margen |
|---|---|---|
| 400 | 314 | ×1,9 |
| 800 | 157 | ×3,8 |
| 1500 | 84 | ×7,2 |

Velocidad del MG90S según distribuidores (0,1 s/60° a 4,8 V sin carga): NO verificada. Comenzar con t_apertura ≥ 1500 ms.

## 4. Radio del horn [CÁLCULO]
Medir el agujero elegido, escribirlo en `config.SERVO.horn_r` y regenerar (`build_all.py`, `verify.py`, `make_docs_v3.py`).

| r horn (mm) | barrido | comando | columna (mm) | par (kg·cm) |
|---|---|---|---|---|
| 6 | ±59,0° | 31,0–149,0° | 58,05 | 0,107 |
| 7 | ±47,3° | 42,7–137,3° | 58,06 | 0,125 |
| 8 | ±40,0° | 50,0–130,0° | 58,07 | 0,143 |
| 9 | ±34,8° | 55,2–124,8° | 58,07 | 0,161 |
| 10 | ±30,9° | 59,1–120,9° | 58,07 | 0,178 |
| 11 | ±27,9° | 62,1–117,9° | 58,08 | 0,196 |
| 12 | ±25,4° | 64,6–115,4° | 58,08 | 0,214 |
| 14 | ±21,5° | 68,5–111,5° | 58,08 | 0,250 |

## 5. Efecto cajón del plato [CÁLCULO]
Con cargas simétricas (3 valvas iguales) la resultante pasa por el centro: sin riesgo. Si UNA valva se traba, la resultante se desplaza hasta ≈ 27.1 mm: supera 17.1 mm en seco (puede trabarse el plato) y queda por debajo de 40.0 mm lubricado. Lubricar y dejar activa la detección de falta de movimiento (Hall de las valvas) del firmware.

## 6. Holguras mínimas en el barrido [SIM]
| Par | mínimo (mm) | modo | servo β |
|---|---|---|---|
| Leaflet_1 ↔ Stop_1 | 0,00 | RESTRINGIDA_60 | -30,0° |
| Link_1 ↔ Leaflet_1 | 0,30 | NORMAL | 40,0° |
| Actuator_Plate ↔ Column_1 | 0,30 | ASIMETRICO | -40,0° |
| Pushrod ↔ Servo_Horn_Reference | 0,30 | ASIMETRICO | -40,0° |
| Leaflet_1 ↔ Leaflet_2 | 0,49 | ASIMETRICO | 30,0° |
| Leaflet_2 ↔ Leaflet_3 | 0,49 | ASIMETRICO | 30,0° |
| Pushrod ↔ Actuator_Plate | 0,50 | NORMAL | 40,0° |
| Link_1 ↔ Valve_Ring | 0,60 | NORMAL | 0,0° |
| Leaflet_1 ↔ Valve_Ring | 0,67 | ASIMETRICO | 0,0° |
| Leaflet_1 ↔ Hall_1 | 1,46 | CIERRE_INCOMPLETO | 40,0° |
| Leaflet_1 ↔ Hall_Carrier_1 | 1,50 | NORMAL | 40,0° |
| Magnet_1 ↔ Hall_1 | 1,50 | NORMAL | 30,0° |
| Tail_Pin_1 ↔ Hall_Carrier_1 | 1,53 | ASIMETRICO | 40,0° |
| Cable_Routes_Reference ↔ Actuator_Plate | 2,60 | NORMAL | 40,0° |
| Pushrod ↔ Servo_MG90S_Reference | 2,82 | NORMAL | 30,0° |
| Link_1 ↔ Stop_1 | 3,89 | CIERRE_INCOMPLETO | -40,0° |
| Cable_Routes_Reference ↔ Column_1 | 4,50 | ASIMETRICO | -40,0° |

## 7. Uniones, rigidez, fricción y acceso
| Unión | Elemento | Retención | Nota |
|---|---|---|---|
| Eje de bisagra (×3) | Varilla de LATÓN Ø2 × 56 | Ajuste en el anillo (Ø2,1) + gota de cianoacrilato SOLO en los extremos; libre en la valva | No magnético |
| Cola–biela (×3) | Pasador de LATÓN Ø2 × 9 | A presión en la cola, libre en la biela | No magnético |
| Biela–orejeta del plato (×3) | Pasador de latón Ø2 × 8,6 + `Pin_Head` + `Push_Nut` | Cabeza impresa pegada; tuerca impresa a presión | Se saca con alicate para cambiar de módulo |
| Horquilla–empujador | Pasador de latón Ø2 × 11,6 + `Pin_Head` + `Push_Nut` | Igual |  |
| Empujador–horn | Tornillo chico que trae el servo | Rosca en el horn | Único tornillo metálico (viene con el servo) |
| Topes (×3) | Pasador de latón Ø2 × 18,1 + `Pin_Head` + `Push_Nut` | Cabeza en el rebaje superior; tuerca a presión en la trampa de la brida | No magnético (junto a los Hall) |
| Columnas → base (×3) | Espárrago M6 impreso en la columna | Rosca hembra M6 impresa en la base + asiento cónico 45° | Se enrosca a mano |
| Anillo → columnas (×3) | Espárrago M6 de la columna + `Knurled_Nut_M6` | Tuerca moleteada sobre la comisura | Con los dedos |
| Orejas del servo (×2) | Tornillos que trae el servo | Autorroscante en piloto Ø1,8 | Vienen con el servo |
| Soporte del servo → base (×4) | `Bolt_M6x8` impreso | Rosca hembra M6 impresa en la base | Fuera de la huella del servo |
| Bandeja → base (×2) | `Bolt_M6x8` impreso | Rosca M6 en la base (2 en diagonal; hay 4 agujeros) | Antes de colocar la placa |
| Placa perforada (×4) | `Turn_Button` impreso | Espiga en el poste, gira con fricción sobre el borde de la placa | Sin tornillos |
| Soporte M1 → base (×2) | `Bolt_M6x8` impreso | Rosca M6 en la base, por las ranuras | Ajuste radial ±8 mm |
| Pivote de M1 | Pasador de latón Ø2 × 14,0 + `Pin_Head` + `Push_Nut` | La presión de la tuerca regula la fricción |  |
| Portasensores Hall (×3) | — | Encastre desde arriba + gota de silicona en la pestaña | Extraíble con gancho |

Acceso comprobado [SIM]: 43 de 43 comprobaciones (ejes, pasadores, acceso con los dedos a pernos y tuercas M6, pestillos, extracción de portasensores, USB).
Fricción: grasa PTFE en bujes y columnas. Rigidez de PETG y juego real de bisagras: se miden con la galga (histéresis) en el ensayo 3. [FÍSICO]

## 8. Cables
Hall: por el canal del portasensor y la bajada exterior del anillo; pinzas en las columnas bajo el recorrido del plato; señales por el sur de la base, servo y 5 V por el norte
(separación ≥ 20 mm). Recorridos modelados como haces y verificados en el barrido (sin interferencias). [SIM]

## 9. Animación
Se calcula cuadro a cuadro con la misma cinemática del CAD. **No es una prueba de funcionamiento ni una medición.**
