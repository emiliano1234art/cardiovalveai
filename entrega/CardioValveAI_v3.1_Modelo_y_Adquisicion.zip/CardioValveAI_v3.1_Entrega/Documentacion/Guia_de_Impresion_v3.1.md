# Guía de impresión v3.1

> CardioValveAI · revisión **v3.1** · prototipo académico de banco **sin fluido**. No es un dispositivo médico ni de diagnóstico; los resultados del banco no equivalen a diagnosticar una válvula implantada.
> **[CÁLCULO]** cálculo · **[GEOM]** inspección geométrica · **[SIM]** simulación · **[COMPILACIÓN]** compilación · **[SW]** prueba de software · **[FÍSICO]** pendiente de ensayo físico

**Supuestos sobre la impresora (VERIFICAR):** FDM con boquilla 0,4 mm, cama ≥ 220 × 220 mm, PETG a 230–245 °C, cama 70–80 °C, flujo calibrado. Unidades de los STL:
**milímetros**; ya están orientados para la cama. Las tolerancias del diseño suponen ±0,1–0,2 mm: **la probeta decide** los diámetros finales.

**Primero imprimir las probetas:**
- `CardioValveAI_v3.1_Tolerance_Coupon.stl` (5 filas): 1 eje Ø2 libre · 2 eje Ø2 a presión (también decide `PIN_PRESS_HOLE` de cabezas y tuercas a presión) ·
  3 pilotos M2/M3 · 4 paso M6 (6,4 / 6,6 / 6,8) y espiga del pestillo (3,9 / 4,0 / 4,1) · 5 imanes Ø4 (4,05–4,30).
- `CardioValveAI_v3.1_Thread_Coupon.stl` + un `CardioValveAI_v3.1_Bolt_M6x8.stl`: elegir la rosca (1, 2 o 3 muescas = compensación 0,10 / 0,20 / 0,30 mm) en la que el perno entra **a mano**
  sin juego visible. `THREAD_COMP` = (0,15 del perno + la del agujero elegido) / 2 → 1 muesca: 0,125 · 2 muescas: 0,175 · 3 muescas: 0,225.
Actualizar `config.py` (`PIN_HOLE_LEAF`, `TAIL_PIN_HOLE`, `LINK_HOLE`, `PIN_PRESS_HOLE`, `M6_CLEAR`, `TURN_PEG_D`, `THREAD_COMP`, `MAG_POCKET_CLR`) y regenerar:
`python build_all.py && python verify.py && python make_docs_v3.py`.

Las piezas **NO DEFINITIVA** dependen de datos pendientes (doc 02). Ninguna pieza se imprimió ni se probó todavía: **no se declara «listo para imprimir»**; las mallas
pasaron las comprobaciones geométricas del informe de validación.

| Archivo | Cant. | Tamaño (mm) | Masa PETG (g) | Parámetros | Soporte | Superficie crítica | Nota |
|---|---|---|---|---|---|---|---|
| `CardioValveAI_v3.1_Valve_Ring.stl` | 1 | 70,0 × 70,0 × 24,0 | 28,8 | 0.2 mm · 50 % · 4 perím. | no | paredes del bolsillo Hall y agujeros de bisagra | Repasar los agujeros horizontales de Ø2,1 con broca de 2,0–2,1 mm si quedan ovalados. Superficie crítica: paredes del bolsillo Hall (0,55 mm hacia la ranura). |
| `CardioValveAI_v3.1_Hall_Carrier_000.stl` **NO DEFINITIVA** | 3 | 8,1 × 4,0 × 8,2 | 0,1 | 0.12 mm · 100 % · 3 perím. | no | lomo y pestaña | Pestaña en la cama. NO DEFINITIVA hasta confirmar el encapsulado del sensor. |
| `CardioValveAI_v3.1_Hall_Carrier_025.stl` **NO DEFINITIVA** | 3 | 7,9 × 4,0 × 8,2 | 0,1 | 0.12 mm · 100 % · 3 perím. | no | lomo y pestaña | Pestaña en la cama. NO DEFINITIVA hasta confirmar el encapsulado del sensor. |
| `CardioValveAI_v3.1_Hall_Carrier_050.stl` **NO DEFINITIVA** | 3 | 7,6 × 4,0 × 8,2 | 0,1 | 0.12 mm · 100 % · 3 perím. | no | lomo y pestaña | Pestaña en la cama. NO DEFINITIVA hasta confirmar el encapsulado del sensor. |
| `CardioValveAI_v3.1_Calib_Gauge_00.stl` | 1 | 27,6 × 15,0 × 11,6 | 1,3 | 0.12 mm · 100 % · 4 perím. | sí | cara de contacto | Acostada sobre su cara lateral. Superficie crítica: la cara de contacto (sin soportes). |
| `CardioValveAI_v3.1_Calib_Gauge_05.stl` | 1 | 27,6 × 14,3 × 11,6 | 1,3 | 0.12 mm · 100 % · 4 perím. | sí | cara de contacto | Acostada sobre su cara lateral. Superficie crítica: la cara de contacto (sin soportes). |
| `CardioValveAI_v3.1_Calib_Gauge_10.stl` | 1 | 27,6 × 13,7 × 11,6 | 1,2 | 0.12 mm · 100 % · 4 perím. | sí | cara de contacto | Acostada sobre su cara lateral. Superficie crítica: la cara de contacto (sin soportes). |
| `CardioValveAI_v3.1_Calib_Gauge_15.stl` | 1 | 27,4 × 13,0 × 11,6 | 1,2 | 0.12 mm · 100 % · 4 perím. | sí | cara de contacto | Acostada sobre su cara lateral. Superficie crítica: la cara de contacto (sin soportes). |
| `CardioValveAI_v3.1_Calib_Gauge_20.stl` | 1 | 27,2 × 12,4 × 11,6 | 1,2 | 0.12 mm · 100 % · 4 perím. | sí | cara de contacto | Acostada sobre su cara lateral. Superficie crítica: la cara de contacto (sin soportes). |
| `CardioValveAI_v3.1_Calib_Gauge_30.stl` | 1 | 26,4 × 11,1 × 11,6 | 1,1 | 0.12 mm · 100 % · 4 perím. | no | cara de contacto | Acostada sobre su cara lateral. Superficie crítica: la cara de contacto (sin soportes). |
| `CardioValveAI_v3.1_Calib_Gauge_40.stl` | 1 | 25,2 × 9,9 × 11,6 | 1,0 | 0.12 mm · 100 % · 4 perím. | no | cara de contacto | Acostada sobre su cara lateral. Superficie crítica: la cara de contacto (sin soportes). |
| `CardioValveAI_v3.1_Calib_Gauge_50.stl` | 1 | 23,7 × 9,2 × 11,6 | 0,9 | 0.12 mm · 100 % · 4 perím. | no | cara de contacto | Acostada sobre su cara lateral. Superficie crítica: la cara de contacto (sin soportes). |
| `CardioValveAI_v3.1_Calib_Gauge_60.stl` | 1 | 22,0 × 10,3 × 11,6 | 0,9 | 0.12 mm · 100 % · 4 perím. | no | cara de contacto | Acostada sobre su cara lateral. Superficie crítica: la cara de contacto (sin soportes). |
| `CardioValveAI_v3.1_Calib_Gauge_70.stl` | 1 | 20,0 × 10,9 × 11,6 | 0,8 | 0.12 mm · 100 % · 4 perím. | no | cara de contacto | Acostada sobre su cara lateral. Superficie crítica: la cara de contacto (sin soportes). |
| `CardioValveAI_v3.1_Calib_Gauge_80.stl` | 1 | 17,8 × 11,1 × 11,6 | 0,8 | 0.12 mm · 100 % · 4 perím. | no | cara de contacto | Acostada sobre su cara lateral. Superficie crítica: la cara de contacto (sin soportes). |
| `CardioValveAI_v3.1_Leaflet_1.stl` | 1 | 28,3 × 33,9 × 10,6 | 1,7 | 0.12 mm · 100 % · 3 perím. | sí | alojamiento del imán y barril | Imprimir con la cara inferior plana en la cama. Soporte mínimo (árbol) bajo la cola inclinada 40°. Imán Ø4×2 en la cara −y de la cola (polaridad marcada). |
| `CardioValveAI_v3.1_Leaflet_2.stl` | 1 | 28,3 × 33,9 × 10,6 | 1,7 | 0.12 mm · 100 % · 3 perím. | sí | alojamiento del imán y barril | Imprimir con la cara inferior plana en la cama. Soporte mínimo (árbol) bajo la cola inclinada 40°. Imán Ø4×2 en la cara −y de la cola (polaridad marcada). |
| `CardioValveAI_v3.1_Leaflet_3.stl` | 1 | 28,3 × 33,9 × 10,6 | 1,7 | 0.12 mm · 100 % · 3 perím. | sí | alojamiento del imán y barril | Imprimir con la cara inferior plana en la cama. Soporte mínimo (árbol) bajo la cola inclinada 40°. Imán Ø4×2 en la cara −y de la cola (polaridad marcada). |
| `CardioValveAI_v3.1_Link_Normal.stl` | 4 | 6,0 × 32,0 × 3,0 | 0,7 | 0.2 mm · 100 % · 3 perím. | no |  | Plana. Sin marcas. |
| `CardioValveAI_v3.1_Link_LostMotion.stl` | 2 | 6,0 × 37,5 × 3,0 | 0,7 | 0.2 mm · 100 % · 3 perím. | no |  | Plana. |
| `CardioValveAI_v3.1_Link_LostMotion_IC.stl` | 1 | 6,0 × 36,1 × 3,0 | 0,7 | 0.2 mm · 100 % · 3 perím. | no |  | Plana. |
| `CardioValveAI_v3.1_Opening_Stop_84.stl` | 3 | 11,0 × 12,0 × 4,4 | 0,4 | 0.2 mm · 100 % · 3 perím. | no |  | Brida en la cama. |
| `CardioValveAI_v3.1_Opening_Stop_60.stl` | 1 | 11,0 × 12,0 × 7,2 | 0,5 | 0.2 mm · 100 % · 3 perím. | no |  | Brida en la cama. |
| `CardioValveAI_v3.1_Opening_Stop_45.stl` | 1 | 11,0 × 12,0 × 8,3 | 0,5 | 0.2 mm · 100 % · 3 perím. | no |  | Brida en la cama. |
| `CardioValveAI_v3.1_Actuator_Plate.stl` | 1 | 66,6 × 69,5 × 13,0 | 13,8 | 0.2 mm · 40 % · 4 perím. | no | bujes | Repasar los bujes Ø8,6 con lija y lubricar con grasa de PTFE. |
| `CardioValveAI_v3.1_Pushrod.stl` | 1 | 5,6 × 35,6 × 3,0 | 0,7 | 0.2 mm · 100 % · 3 perím. | no |  | Plano. |
| `CardioValveAI_v3.1_Column.stl` | 3 | 8,0 × 8,0 × 93,6 | 4,7 | 0.12 mm · 100 % · 4 perím. | sí | superficie de deslizamiento | Vertical, espárrago inferior en la cama (el cono de 45° no lleva soporte). Capa 0,12 mm por las roscas. Lijar la superficie de deslizamiento (grano 400) y lubricar. |
| `CardioValveAI_v3.1_Cable_Clip.stl` | 3 | 16,8 × 11,8 × 6,0 | 0,7 | 0.2 mm · 100 % · 3 perím. | no |  |  |
| `CardioValveAI_v3.1_MEMS_Stand.stl` | 1 | 44,0 × 35,0 × 76,6 | 20,3 | 0.2 mm · 40 % · 4 perím. | no |  | Pie en la cama. |
| `CardioValveAI_v3.1_MEMS_Stand_Holder.stl` **NO DEFINITIVA** | 1 | 28,9 × 18,9 × 7,0 | 1,1 | 0.2 mm · 40 % · 3 perím. | sí |  | Cara del marco en la cama. |
| `CardioValveAI_v3.1_Servo_Mount.stl` **NO DEFINITIVA** | 1 | 45,4 × 43,0 × 20,2 | 7,6 | 0.2 mm · 50 % · 4 perím. | no |  | Fijar a la base sobre arandelas de goma (antivibración). |
| `CardioValveAI_v3.1_Electronics_Tray.stl` **NO DEFINITIVA** | 1 | 79,4 × 103,8 × 9,6 | 35,4 | 0.2 mm · 30 % · 3 perím. | no |  | Insertos M3 en los 4 postes. |
| `CardioValveAI_v3.1_Turn_Button.stl` **NO DEFINITIVA** | 5 | 6,4 × 14,4 × 7,4 | 0,3 | 0.12 mm · 100 % · 3 perím. | no | espiga | Cara superior en la cama, espiga hacia arriba. |
| `CardioValveAI_v3.1_Angle_Scale.stl` | 1 | 92,7 × 70,0 × 2,0 | 16,4 | 0.2 mm · 30 % · 3 perím. | no |  | Plano; marcas hacia arriba. |
| `CardioValveAI_v3.1_Base.stl` **NO DEFINITIVA** | 1 | 200,0 × 180,0 × 6,0 | 269,1 | 0.2 mm · 20 % · 4 perím. | sí | roscas M6 (5 perímetros alrededor) | Cabe en camas ≥ 220 × 220 mm. Usar borde (brim) de 5 mm para evitar alabeo. |
| `CardioValveAI_v3.1_Tolerance_Coupon.stl` | 1 | 66,0 × 46,0 × 6,5 | 23,2 | 0.2 mm · 100 % · 3 perím. | no |  | Imprimir primero: elegir los diámetros reales que ajustan con la varilla de latón, los imanes y las piezas impresas. |
| `CardioValveAI_v3.1_Thread_Coupon.stl` | 1 | 42,0 × 14,0 × 6,0 | 3,8 | 0.12 mm · 100 % · 4 perím. | sí | roscas | Imprimir junto con un Bolt_M6x8 ANTES que el resto de las fijaciones. |
| `CardioValveAI_v3.1_Bolt_M6x8.stl` | 9 | 10,0 × 10,0 × 12,0 | 0,6 | 0.12 mm · 100 % · 4 perím. | sí | rosca | Vertical, cabeza en la cama. Apretar SOLO con los dedos (la rosca de plástico se barre con herramientas). |
| `CardioValveAI_v3.1_Knurled_Nut_M6.stl` | 4 | 9,0 × 9,0 × 6,0 | 0,3 | 0.12 mm · 100 % · 4 perím. | sí | rosca | Plana en la cama. Apretar con los dedos. |
| `CardioValveAI_v3.1_Pin_Head.stl` | 10 | 3,8 × 3,8 × 1,6 | 0,0 | 0.12 mm · 100 % · 2 perím. | no | agujero a presión | Agujero hacia la cama. Se coloca a presión y se fija con una gota de cianoacrilato. |
| `CardioValveAI_v3.1_Push_Nut.stl` | 10 | 4,6 × 4,0 × 1,6 | 0,0 | 0.12 mm · 100 % · 2 perím. | no | agujero a presión | Plana. Se empuja con un alicate hasta apretar; se saca haciendo palanca. |

**Fijaciones impresas** (pernos, tuercas, cabezas, tuercas a presión, pestillos, columnas): 100 % de relleno, capa 0,12 mm, ≥ 4 perímetros, sin «ironing».
Pernos verticales con la cabeza en la cama; columnas verticales empezando por el espárrago inferior. La base lleva 5 perímetros para que las roscas queden en material macizo.
Ver `11_Fijaciones_Impresas.md`.
