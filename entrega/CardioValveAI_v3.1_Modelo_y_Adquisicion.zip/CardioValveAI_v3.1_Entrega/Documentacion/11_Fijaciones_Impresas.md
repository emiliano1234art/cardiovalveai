# 11 · Fijaciones impresas (v3.1): sin tornillería metálica comprada

> CardioValveAI · revisión **v3.1** · prototipo académico de banco **sin fluido**. No es un dispositivo médico ni de diagnóstico; los resultados del banco no equivalen a diagnosticar una válvula implantada.
> **[CÁLCULO]** cálculo · **[GEOM]** inspección geométrica · **[SIM]** simulación · **[COMPILACIÓN]** compilación · **[SW]** prueba de software · **[FÍSICO]** pendiente de ensayo físico

## 1. Por qué no se imprimen tornillos M2 ni M3
La rosca M2 avanza 0,4 mm por vuelta y la M3, 0,5 mm: lo mismo que el ancho de línea de una boquilla de 0,4 mm. Impresas salen deformes y se barren al apretar.
Por eso cada unión se resolvió con lo que **sí** funciona impreso, sin cambiar el mecanismo ni la medición:
- **Rosca M6 impresa** (paso 1,0 mm, perfil ISO) donde hay lugar: columnas, anillo, soporte del servo, bandeja y soporte del micrófono.
- **Pasador de latón Ø2** (la misma varilla de los ejes) con **cabeza impresa pegada** y **tuerca impresa a presión** donde no hay lugar para M6: topes, bielas, horquilla y
  pivote del micrófono. Funciona como un tornillo con tuerca: se arma, aprieta y desarma (la tuerca se saca con alicate).
- **Pestillos giratorios** en lugar de las barras y tornillos de la placa perforada.
Ventaja adicional: **no queda acero cerca de los sensores Hall** (todo es PETG o latón, no magnéticos).
Los **únicos tornillos metálicos** son los que vienen con el servo (orejas y horn).

## 2. Qué va en cada unión
| Unión | Elemento | Retención | Nota |
|---|---|---|---|
| Eje de bisagra (×3) | Varilla de LATÓN Ø2 × 56 | Ajuste en el anillo (Ø2,1) + gota de cianoacrilato SOLO en los extremos; libre en la valva | No magnético |
| Cola–biela (×3) | Pasador de LATÓN Ø2 × 9 | A presión en la cola, libre en la biela | No magnético |
| Biela–orejeta del plato (×3) | Pasador de latón Ø2 × 8,6 + `Pin_Head` + `Push_Nut` | Cabeza impresa pegada; tuerca impresa a presión | Se saca con alicate para cambiar de módulo |
| Horquilla–empujador | Pasador de latón Ø2 × 11,6 + `Pin_Head` + `Push_Nut` | Igual |  |
| Empujador–horn | Tornillo chico que trae el servo | Rosca en el horn | Único tornillo metálico (viene con el servo) |
| Topes (×3) | Pasador de latón Ø2 × 18,1 + `Pin_Head` + `Push_Nut` | Cabeza en el rebaje superior; tuerca a presión en la trampa de la brida | No magnético (junto a los Hall) |
| Columnas → base (×3) | Espárrago M6 impreso en la columna | Rosca hembra M6 impresa en la base + asiento cónico 45° | Se enrosca a mano |
| Anillo → columnas (×3) | Espárrago M6 de la columna + `Knurled_Nut_M6` | Tuerca moleteada sobre la comisura | Con los dedos |
| Orejas del servo (×2) | Tornillos que trae el servo | Autorroscante en piloto Ø1,8 | Vienen con el servo |
| Soporte del servo → base (×4) | `Bolt_M6x8` impreso | Rosca hembra M6 impresa en la base | Fuera de la huella del servo |
| Bandeja → base (×2) | `Bolt_M6x8` impreso | Rosca M6 en la base (2 en diagonal; hay 4 agujeros) | Antes de colocar la placa |
| Placa perforada (×4) | `Turn_Button` impreso | Espiga en el poste, gira con fricción sobre el borde de la placa | Sin tornillos |
| Soporte M1 → base (×2) | `Bolt_M6x8` impreso | Rosca M6 en la base, por las ranuras | Ajuste radial ±8 mm |
| Pivote de M1 | Pasador de latón Ø2 × 14,0 + `Pin_Head` + `Push_Nut` | La presión de la tuerca regula la fricción |  |
| Portasensores Hall (×3) | — | Encastre desde arriba + gota de silicona en la pestaña | Extraíble con gancho |

## 3. Piezas a imprimir
| Archivo | Cant. (incluye repuestos) | Uso |
|---|---|---|
| `CardioValveAI_v3.1_Bolt_M6x8.stl` | 9 | 4 servo, 2 bandeja, 2 soporte M1, 1 repuesto. Cabeza moleteada Ø10 × 4 con ranura |
| `CardioValveAI_v3.1_Knurled_Nut_M6.stl` | 4 | 3 comisuras + 1. Ø9 × 6 (no sobresale de la comisura) |
| `CardioValveAI_v3.1_Pin_Head.stl` | 10 | 8 pasadores + 2 |
| `CardioValveAI_v3.1_Push_Nut.stl` | 10 | 8 pasadores + 2 (son de un solo uso si quedan flojas) |
| `CardioValveAI_v3.1_Turn_Button.stl` | 5 | 4 pestillos + 1 |
| `CardioValveAI_v3.1_Thread_Coupon.stl` | 1 | Probeta de roscas (imprimir primero) |
| `CardioValveAI_v3.1_Column.stl` | 3 | Ahora con espárragos M6 en ambos extremos |

Pasadores de latón Ø2 a cortar: 3 × 18,1 (topes), 3 × 8,6 (bielas), 1 × 11,6 (horquilla), 1 × 14,0 (pivote),
además de los 3 ejes de 56 mm y los 3 pasadores de 9 mm de siempre.

## 4. Resistencia: orden de magnitud [CÁLCULO, con supuestos]
Supuesto conservador para PETG impreso **entre capas**: corte ≈ 10 MPa y tracción ≈ 10 MPa (el material macizo resiste más; VERIFICAR con la probeta).
| Caso | Capacidad estimada | Carga del banco | Margen |
|---|---|---|---|
| Barrido de la rosca M6 en la base (5 mm de rosca) | ≈ 471 N | ≈ 6 N por perno (reacción al par de bloqueo del servo, no verificado) | ≈ ×79 |
| Tracción del espárrago de la columna (Ø de fondo 4,77 mm) | ≈ 179 N | < 2 N (el plato empuja el anillo hacia arriba al cerrar) | > ×89 |
| Corte del pasador de latón Ø2 | ≈ 628 N | < 2 N | > ×314 |

Las cargas del banco son muy chicas (fuerza en el empujador ≈ 1,8 N). **El riesgo real no es la rotura en uso sino apretar de más:** una llave o
un destornillador pueden barrer la rosca de plástico. Por eso las cabezas son moleteadas y se aprietan **solo con los dedos**. El PETG se asienta con el tiempo: revisar el
apriete después de 24 h. La retención de las tuercas a presión depende del agujero real: se fija con la fila 2 de la probeta y se comprueba en el ensayo 1. [FÍSICO]

## 5. Comprobaciones digitales [SIM]
- Perno y tuerca M6 impresos: con la compensación de 0,15 mm por lado, las roscas encajan sin interferencia, con un juego axial
  de ≈ 0,3 mm (normal en roscas impresas). Se comprobó intersecando el sólido del perno con el de una tuerca en distintos ángulos de giro.
- Piezas fijas modificadas y fijaciones contra todo el ensamblaje: sin choques (informe de validación).
- Barrido de 125 poses con pasadores, cabezas y tuercas del plato: 0 interferencias.
- Accesos: tuercas moleteadas y pernos con espacio para los dedos; pasadores biela–plato con acceso por ambos lados (informe de validación).
