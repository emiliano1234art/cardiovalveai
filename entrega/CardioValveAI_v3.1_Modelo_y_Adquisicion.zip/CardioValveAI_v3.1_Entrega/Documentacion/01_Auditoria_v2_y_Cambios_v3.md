# 01 · Auditoría de la entrega v2 y cambios de la v3

> CardioValveAI · revisión **v3.1** · prototipo académico de banco **sin fluido**. No es un dispositivo médico ni de diagnóstico; los resultados del banco no equivalen a diagnosticar una válvula implantada.
> **[CÁLCULO]** cálculo · **[GEOM]** inspección geométrica · **[SIM]** simulación · **[COMPILACIÓN]** compilación · **[SW]** prueba de software · **[FÍSICO]** pendiente de ensayo físico

**Qué se auditó:** `entrega/CardioValAI_v2_Modelo_y_Adquisicion.zip` (v2, commit base 2b3999f): CAD paramétrico, STL, STEP, Blender, animación, firmware ESP-IDF,
herramientas para Mac, esquemas y documentación. **Las entregas v1 y v2 se conservan sin cambios** (`entrega/CardioValAI_Modelo_Final_STL.zip`,
`entrega/CardioValAI_v2_Modelo_y_Adquisicion.zip`); sus fuentes se archivaron en `hardware/legado/`. Todo lo nuevo se llama **CardioValveAI**, lleva el prefijo
`CardioValveAI_v3.1` y sale en `hardware/out_v3.1/`.

## 0. Revisión v3.1: fijaciones impresas
La v3.1 es la v3 sin tornillería metálica comprada: roscas M6 impresas, pasadores de latón Ø2 con cabeza y tuerca impresas, y pestillos giratorios en la
bandeja (doc 11). El mecanismo, los sensores, el firmware y la medición no cambian. La v3 se conserva en `entrega/CardioValveAI_v3_Modelo_y_Adquisicion.zip`.

## 1. Cambios de configuración pedidos (aplicados)

| Cambio | Qué se hizo | Comprobación |
|---|---|---|
| Nombre definitivo **CardioValveAI** | Títulos, prefijos de archivos, firmware (`CardioValveAI_v3_Adquisicion`), herramientas, esquemas, Blender y documentación | Búsqueda de nombres anteriores en fuentes y salidas v3 [SW] |
| Quitar los 2 piezoeléctricos | Se eliminaron soportes, tapas, adaptadores, almohadillas del anillo y del soporte del servo, canales, adquisición, gráficos y referencias | Barrido sin esas piezas [SIM]; búsqueda de texto [SW] |
| Quitar MCP6004/MCP6022 y componentes solo del piezo | Se quitaron amplificador, BAT54S, red de polarización, filtros Sallen-Key; la hoja eléctrica del piezo ya no existe | Esquemas regenerados [SW] |
| Quitar el 4.º Hall (H0 del plato) | Se eliminaron soporte, imán del plato, arandelas y canal ADC. La detección de «falta de movimiento» usa ahora los 3 Hall de las valvas | Firmware compilado [COMPILACIÓN]; prueba con emulador [SW] |
| Quitar el INA219 | Fuera del esquema y del firmware; el servo se protege con fusible PTC, parada física y límites por software | [COMPILACIÓN] |
| Sin IMU ni sensores nuevos | No se agregó ninguno | — |
| ECG fuera de alcance | No hay electrodos ni ECG en esta revisión | — |

## 2. Problemas encontrados en la v2 y corrección en la v3

| # | Problema en v2 | Evidencia | Corrección v3 | Estado |
|---|---|---|---|---|
| 1 | **Ubicación Hall frágil:** con el sensor 1 mm más lejos del imán la curva dejaba de ser monótona y con +0,5 mm la incertidumbre llegaba a ≈ 2,7° (A1). | Modelo de dipolos `sensing.py`, posición v2 (26,8; −8; 13,5) en el marco de la valva | Nueva posición (26,1; -8,0; 13,0) con ventana del bolsillo hacia la ranura; monótona con ±0,5 mm en x, y, z (tabla en doc 03). **Con +1 mm sigue dejando de ser monótona**: la posición la fija el lomo del portasensor apoyado en la pared del bolsillo, no el pegado | [CÁLCULO]; respuesta real [FÍSICO] |
| 2 | **Sensor Hall pegado en el anillo:** para cambiarlo había que desarmar la válvula. | Bolsillo cerrado en la pared | **Portasensor extraíble desde arriba** (`Hall_Carrier`), con pestaña y canal de cable; 3 variantes de separación (0 / 0,25 / 0,5 mm) solo por si satura | Extracción vertical sin choques [SIM]; ajuste real [FÍSICO] |
| 3 | **Equivalencia de sensores supuesta:** el texto usaba DRV5055 pero no se evaluaron 49E/SS49E. | — | Tabla de candidatos con la misma geometría: la familia 49E **no** cumple el objetivo de ≤ 1° (doc 03); A3144 no sirve (digital) | [CÁLCULO] con datos a VERIFICAR |
| 4 | **Calibración con el ángulo ORDENADO al servo** como referencia de posición y sin histéresis. | `cvai_calibrate.py guiado` v2 | Calibración con **galgas impresas** que tocan la valva a 0–80° (11 ángulos) + verificación con video; se registran apertura y cierre por separado; histéresis, repetibilidad y error de validación cruzada | Galgas: 11/11 correctas [SIM]; ajuste con datos sintéticos [SW]; real [FÍSICO] |
| 5 | Calibración solo en la computadora: el firmware no sabía si había calibración ni podía limitar ángulos. | Firmware v2 | Calibración por sensor **guardada en NVS** con CRC, validada (≥ 5 puntos, monótona, sin lecturas repetidas, rango ≥ 30°); límites en ángulo calibrado y aviso si falta | [COMPILACIÓN]; [SW] con emulador; [FÍSICO] |
| 6 | Umbrales de anomalía fijos en el código. | `cvai_analyze.py` v2 | Umbrales calculados con `--crear-umbrales` a partir de sesiones **normales reales** repetidas (rechaza sintéticas y no calibradas) | [SW] |
| 7 | Detección de atasco con el Hall del plato (H0). | Firmware v2 | «Falta de movimiento»: ninguna valva cambia su lectura cruda ≥ `stall_min_delta` durante un movimiento ordenado → parada controlada | [COMPILACIÓN]; [SW] |
| 8 | Muestreo de 8 canales a 64 kS/s para piezo + Hall. | Firmware v2 | Patrón de 3 canales H1 H2 H3 a 24 kS/s → 1 kS/s por valva (suma de 8); desfase entre valvas 41,7 µs (informado en INFO) | [COMPILACIÓN] |
| 9 | Vistas sin ampliación del par Hall–imán ni coordenadas desde un origen común. | Carpeta `Vistas` v2 | Vistas ampliadas por valva (cerrada/abierta), portasensor retirado y galga; tabla de coordenadas (doc 03, `Coordenadas_Sensores_v3.1.csv`) | [GEOM] |
| 10 | El servo figuraba como MG90S confirmado. | BOM v2 | Modelo y medidas del servo **por confirmar** (doc 02); el MG90S queda como referencia dimensional | — |

## 3. Riesgos que quedan sin resolver sin ensayo físico
- Respuesta real de los Hall y de los imanes comprados (modelo de dipolos aproximado; datos de sensibilidad a 3,3 V supuestos ratiométricos). [FÍSICO]
- Efecto cajón del plato si una valva se traba: Con cargas simétricas (3 valvas iguales) la resultante pasa por el centro: sin riesgo. Si UNA valva se traba, la resultante se desplaza hasta ≈ 27.1 mm: supera 17.1 mm en seco (puede trabarse el plato) y queda por debajo de 40.0 mm lubricado. Lubricar y dejar activa la detección de falta de movimiento (Hall de las valvas) del firmware. [CÁLCULO]
- Par y velocidad reales del servo (dato de distribuidores no verificado). [FÍSICO]
- Holguras reales de impresión → probeta de tolerancias. [FÍSICO]

## 4. Resultado de las comprobaciones digitales v3 (ejecutadas sobre los archivos entregados)
- Barrido: **125 poses** (25 posiciones del servo × 5 modos), intersección booleana: **0 interferencias**. [SIM]
- Contactos de diseño (< 0,05 mm³): Actuator_Plate × Plate_Fasteners_Reference, Link_1 × Plate_Fasteners_Reference, Link_2 × Plate_Fasteners_Reference, Link_3 × Plate_Fasteners_Reference.
- Montaje y acceso: 43 de 43 correctas. [SIM]
- Galgas de calibración: 11 de 11 detienen solo a la valva 1 en su ángulo (sin contacto 0,3° antes). [SIM]
- Mallas STL: cerradas, un cuerpo, apoyadas en z = 0, dentro de 220 × 220 mm. [SW]
- Firmware: compila con ESP-IDF v5.4.1 sin advertencias en el código propio. [COMPILACIÓN]
- Herramientas: prueba de extremo a extremo con datos **sintéticos** del emulador. [SW]

**Nada de esto demuestra que el prototipo físico funcione.** Ver `10_Pendientes_Fisicos.md`.
