# 10 · Pendientes de medición o ensayo físico

> CardioValveAI · revisión **v3.1** · prototipo académico de banco **sin fluido**. No es un dispositivo médico ni de diagnóstico; los resultados del banco no equivalen a diagnosticar una válvula implantada.
> **[CÁLCULO]** cálculo · **[GEOM]** inspección geométrica · **[SIM]** simulación · **[COMPILACIÓN]** compilación · **[SW]** prueba de software · **[FÍSICO]** pendiente de ensayo físico

- Datos de la lista única (doc 02): Hall, imanes, servo, ESP32, INMP441 → regenerar piezas afectadas.
- Diámetros reales de agujeros, ajustes a presión e imanes (probeta); ajuste y resistencia de las roscas M6 impresas y retención de las tuercas a presión (probetas, ensayo 1).
- Respuesta real de cada par Hall–imán; saturación; monotonía; ruido real del ADC.
- Calibración real: resolución, repetibilidad, histéresis, exactitud frente al video; repetición tras remontaje.
- Influencia real de las valvas vecinas y del servo sobre cada Hall.
- Firmware en la placa (no probado en hardware): tasas reales, pérdidas, paradas, PWM aceptado por el servo a 3,3 V.
- Par, velocidad y corriente de bloqueo del servo real; fricción del plato; efecto cajón.
- Si el audio aporta información sobre los eventos.
- Umbrales de anomalía a partir de sesiones normales repetidas.
- Todos los criterios del doc 09.
