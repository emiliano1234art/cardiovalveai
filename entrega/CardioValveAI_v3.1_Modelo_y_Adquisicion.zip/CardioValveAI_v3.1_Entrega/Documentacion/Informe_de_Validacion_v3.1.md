# Informe de validación digital v3.1

> CardioValveAI · revisión **v3.1** · prototipo académico de banco **sin fluido**. No es un dispositivo médico ni de diagnóstico; los resultados del banco no equivalen a diagnosticar una válvula implantada.
> **[CÁLCULO]** cálculo · **[GEOM]** inspección geométrica · **[SIM]** simulación · **[COMPILACIÓN]** compilación · **[SW]** prueba de software · **[FÍSICO]** pendiente de ensayo físico

Generado: 2026-10-29 01:29. Todo lo de este informe se ejecutó sobre los archivos entregados ([SIM], [GEOM], [SW]). **No reemplaza ningún ensayo físico.**

## Mallas de impresión [SW]
41 piezas imprimibles; con problemas: ninguna (cerradas, orientación coherente, un cuerpo, z mín. = 0, caben en 220 × 220).

## Interferencias [SIM]
125 poses (25 posiciones × 5 modos) con todas las piezas, imanes, sensores, pasadores, tornillería y cables: **0 interferencias**.
Contactos de diseño: Actuator_Plate × Plate_Fasteners_Reference, Link_1 × Plate_Fasteners_Reference, Link_2 × Plate_Fasteners_Reference, Link_3 × Plate_Fasteners_Reference.

## Holguras mínimas [SIM]
| Par | mm | modo |
|---|---|---|
| Leaflet_1 ↔ Stop_1 | 0,00 | RESTRINGIDA_60 |
| Link_1 ↔ Leaflet_1 | 0,30 | NORMAL |
| Actuator_Plate ↔ Column_1 | 0,30 | ASIMETRICO |
| Pushrod ↔ Servo_Horn_Reference | 0,30 | ASIMETRICO |
| Leaflet_1 ↔ Leaflet_2 | 0,49 | ASIMETRICO |
| Leaflet_2 ↔ Leaflet_3 | 0,49 | ASIMETRICO |
| Pushrod ↔ Actuator_Plate | 0,50 | NORMAL |
| Link_1 ↔ Valve_Ring | 0,60 | NORMAL |
| Leaflet_1 ↔ Valve_Ring | 0,67 | ASIMETRICO |
| Leaflet_1 ↔ Hall_1 | 1,46 | CIERRE_INCOMPLETO |
| Leaflet_1 ↔ Hall_Carrier_1 | 1,50 | NORMAL |
| Magnet_1 ↔ Hall_1 | 1,50 | NORMAL |
| Tail_Pin_1 ↔ Hall_Carrier_1 | 1,53 | ASIMETRICO |
| Cable_Routes_Reference ↔ Actuator_Plate | 2,60 | NORMAL |
| Pushrod ↔ Servo_MG90S_Reference | 2,82 | NORMAL |
| Link_1 ↔ Stop_1 | 3,89 | CIERRE_INCOMPLETO |
| Cable_Routes_Reference ↔ Column_1 | 4,50 | ASIMETRICO |

## Montaje y acceso [SIM]
| Comprobación | Resultado |
|---|---|
| Eje Ø2 de la valva 1: inserción desde el exterior (camino libre) | ✔ |
| Tuerca moleteada M6 de la columna 1: acceso con los dedos desde arriba | ✔ |
| Pasador de latón del tope 1: inserción vertical desde arriba | ✔ |
| Portasensor H1: extracción vertical sin desarmar (cuerpo del sensor) | ✔ |
| Portasensor H1: extracción vertical sin desarmar (lomo) | ✔ |
| Pasador Ø2 cola–biela de la valva 1: agujeros alineados | ✔ |
| Pasador biela–plato de la valva 1: agujeros alineados | ✔ |
| Eje Ø2 de la valva 2: inserción desde el exterior (camino libre) | ✔ |
| Tuerca moleteada M6 de la columna 2: acceso con los dedos desde arriba | ✔ |
| Pasador de latón del tope 2: inserción vertical desde arriba | ✔ |
| Portasensor H2: extracción vertical sin desarmar (cuerpo del sensor) | ✔ |
| Portasensor H2: extracción vertical sin desarmar (lomo) | ✔ |
| Pasador Ø2 cola–biela de la valva 2: agujeros alineados | ✔ |
| Pasador biela–plato de la valva 2: agujeros alineados | ✔ |
| Eje Ø2 de la valva 3: inserción desde el exterior (camino libre) | ✔ |
| Tuerca moleteada M6 de la columna 3: acceso con los dedos desde arriba | ✔ |
| Pasador de latón del tope 3: inserción vertical desde arriba | ✔ |
| Portasensor H3: extracción vertical sin desarmar (cuerpo del sensor) | ✔ |
| Portasensor H3: extracción vertical sin desarmar (lomo) | ✔ |
| Pasador Ø2 cola–biela de la valva 3: agujeros alineados | ✔ |
| Pasador biela–plato de la valva 3: agujeros alineados | ✔ |
| Pasador biela–plato de la valva 1: empujador por la cabeza (−y), plato abajo, transportador retirado | ✔ |
| Pasador biela–plato de la valva 1: alicate sobre la tuerca a presión (+y), plato abajo, transportador retirado | ✔ |
| Pasador biela–plato de la valva 2: empujador por la cabeza (−y), plato abajo, transportador retirado | ✔ |
| Pasador biela–plato de la valva 2: alicate sobre la tuerca a presión (+y), plato abajo, transportador retirado | ✔ |
| Pasador biela–plato de la valva 3: empujador por la cabeza (−y), plato abajo, transportador retirado | ✔ |
| Pasador biela–plato de la valva 3: alicate sobre la tuerca a presión (+y), plato abajo, transportador retirado | ✔ |
| Pasador horquilla–empujador: agujeros alineados | ✔ |
| Tornillo M2 oreja izq del servo: acceso con destornillador | ✔ |
| Tornillo M2 oreja der del servo: acceso con destornillador | ✔ |
| Perno M6 1 del soporte M1: acceso con los dedos | ✔ |
| Perno M6 2 del soporte M1: acceso con los dedos | ✔ |
| Perno M6 1 del soporte del servo: acceso con los dedos (antes de montar servo y válvula) | ✔ |
| Perno M6 2 del soporte del servo: acceso con los dedos (antes de montar servo y válvula) | ✔ |
| Perno M6 3 del soporte del servo: acceso con los dedos (antes de montar servo y válvula) | ✔ |
| Perno M6 4 del soporte del servo: acceso con los dedos (antes de montar servo y válvula) | ✔ |
| Perno M6 bandeja→base (18,22): acceso vertical sin la placa | ✔ |
| Perno M6 bandeja→base (61,82): acceso vertical sin la placa | ✔ |
| Pestillo 1 de la bandeja: gira sobre su espiga (agujero libre en el poste) | ✔ |
| Pestillo 2 de la bandeja: gira sobre su espiga (agujero libre en el poste) | ✔ |
| Pestillo 3 de la bandeja: gira sobre su espiga (agujero libre en el poste) | ✔ |
| Pestillo 4 de la bandeja: gira sobre su espiga (agujero libre en el poste) | ✔ |
| Conector USB del ESP32: enchufable desde +y sin obstáculos (referencia) | ✔ |

## Galgas de calibración [SIM]
| Galga | Correcta |
|---|---|
| 0° | ✔ |
| 5° | ✔ |
| 10° | ✔ |
| 15° | ✔ |
| 20° | ✔ |
| 30° | ✔ |
| 40° | ✔ |
| 50° | ✔ |
| 60° | ✔ |
| 70° | ✔ |
| 80° | ✔ |

## Piezas fijas y fijaciones impresas (choques estáticos) [SIM]
| Pieza | Resultado |
|---|---|
| Ring_Fasteners_Reference | ✔ |
| Base_Fasteners_Reference | ✔ |
| Stand_Fasteners_Reference | ✔ |
| Turn_Button_1 | ✔ |
| Turn_Button_2 | ✔ |
| Turn_Button_3 | ✔ |
| Turn_Button_4 | ✔ |
| Servo_Mount | ✔ |
| MEMS_Stand | ✔ |
| Electronics_Tray | ✔ |
| Column_1 | ✔ |
| Column_2 | ✔ |
| Column_3 | ✔ |
| Base | ✔ |

## Cálculos [CÁLCULO]
Servo: {"plate_and_links_g": 16.6, "force_N": 1.751, "torque_Nmm": 14.01, "torque_kgcm": 0.143, "mg90s_stall_kgcm_unverified": 1.8, "margin_x": 12.6}. Accionamiento: {"margen_punto_muerto_deg": 48.2, "velocidades": [{"t_apertura_ms": 400, "vel_pico_deg_s": 314.0, "MG90S_sin_carga_deg_s_no_verificado": 600, "margen_x": 1.9}, {"t_apertura_ms": 800, "vel_pico_deg_s": 157.0, "MG90S_sin_carga_deg_s_no_verificado": 600, "margen_x": 3.8}, {"t_apertura_ms": 1500, "vel_pico_deg_s": 84.0, "MG90S_sin_carga_deg_s_no_verificado": 600, "margen_x": 7.2}], "nota": "Velocidad del MG90S según distribuidores (0,1 s/60° a 4,8 V sin carga): NO verificada. Comenzar con t_apertura ≥ 1500 ms."}. Efecto cajón: Con cargas simétricas (3 valvas iguales) la resultante pasa por el centro: sin riesgo. Si UNA valva se traba, la resultante se desplaza hasta ≈ 27.1 mm: supera 17.1 mm en seco (puede trabarse el plato) y queda por debajo de 40.0 mm lubricado. Lubricar y dejar activa la detección de falta de movimiento (Hall de las valvas) del firmware.
