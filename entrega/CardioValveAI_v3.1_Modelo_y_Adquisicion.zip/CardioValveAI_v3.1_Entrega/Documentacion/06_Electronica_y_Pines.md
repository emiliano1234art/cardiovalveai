# 06 · Electrónica, esquema y tabla de pines

> CardioValveAI · revisión **v3.1** · prototipo académico de banco **sin fluido**. No es un dispositivo médico ni de diagnóstico; los resultados del banco no equivalen a diagnosticar una válvula implantada.
> **[CÁLCULO]** cálculo · **[GEOM]** inspección geométrica · **[SIM]** simulación · **[COMPILACIÓN]** compilación · **[SW]** prueba de software · **[FÍSICO]** pendiente de ensayo físico

Esquemas: `Electronica/Hoja1_Alimentacion_Servo` y `Electronica/Hoja2_Hall_MEMS` (SVG y PNG), generados con `hardware/electronica/esquema.py`.
Fuentes: Espressif (ESP32 Datasheet, Technical Reference Manual, ESP-IDF v5.4: ADC continuo, I2S, LEDC), TI DRV5055, TDK InvenSense INMP441, Microchip MCP1700.
**Las hojas de datos de TI y Diodes no se pudieron descargar desde este entorno** (bloqueo de red): los valores tomados de ellas están marcados VERIFICAR.
Ningún circuito fue armado ni medido todavía [FÍSICO].

## 1. Tabla de pines (ESP32 DevKit V1 — VERIFICAR con la serigrafía de su placa)
| Pin | Señal | Dirección | Periférico | Nota |
|---|---|---|---|---|
| GPIO36 (VP) | H1 Hall valva 1 | entrada analógica | ADC1_CH0 | Solo entrada |
| GPIO39 (VN) | H2 Hall valva 2 | entrada analógica | ADC1_CH3 | Solo entrada |
| GPIO32 | H3 Hall valva 3 | entrada analógica | ADC1_CH4 |  |
| GPIO26 | INMP441 SCK | salida | I2S1 BCLK | 33 Ω en serie |
| GPIO25 | INMP441 WS | salida | I2S1 WS |  |
| GPIO27 | INMP441 SD | entrada | I2S1 DIN | L/R del INMP441 a GND |
| GPIO18 | PWM servo | salida | LEDC 50 Hz, 16 bits | 220 Ω serie + 10 kΩ a GND |
| GPIO19 | LED de sincronización | salida |  | 330 Ω + LED a GND |
| GPIO23 | Parada por software | entrada | pull-up interno | contacto NA a GND |
| GPIO2 | LED de la placa | salida |  | pin de arranque: sin carga externa |
| GPIO1 / GPIO3 | UART0 (USB) | — | protocolo binario | reservado |
| 3V3 | INMP441 | alimentación |  | regulador de la placa + 100 nF |
| VIN / 5V (del USB) | MCP1700-3302 → 3V3_A (solo los 3 Hall) | alimentación |  | NUNCA conectar +5V_SERVO |
| GND | masa | — |  | unión a la estrella ★ |
| Libres | GPIO33, GPIO34, GPIO35 (ADC1, reserva) |  |  | quedan sin conectar |
| No usar | GPIO6–11 (flash), GPIO0/5/12/15 (arranque), ADC2 (sin DMA) |  |  |  |

## 2. Hall: dos opciones según el sensor real
- **Opción A (recomendada): DRV5055A1 a 3,3 V** desde 3V3_A. Salida 0,2–3,1 V aprox., centrada en VCC/2 sin campo; con el imán orientado para que la salida **baje** queda entre
  ≈ 0,5 y 1,65 V, dentro del rango lineal del ADC con 12 dB de atenuación. RC 1 kΩ/100 nF antes del ADC.
- **Opción B: sensor de 5 V (49E/SS49E/AH49E o DRV5055 a 5 V).** Salida de hasta ≈ 4–4,5 V → **divisor 20 kΩ/30 kΩ (×0,6)** antes del RC: máximo ≈ 2,7 V en el pin.
  Sensibilidad efectiva menor (doc 03). Alimentación de los sensores desde 5 V del USB, con 100 nF junto a cada uno.
- **Módulos con comparador o A3144:** salida digital, no sirve para medir el ángulo (doc 02).

## 3. Micrófono INMP441
3,3 V con 100 nF; L/R a GND (canal izquierdo); I2S1 maestro a 16 kHz, palabra de 32 bits (dato de 24 bits). Cable ≤ 20 cm con GND entre SCK y SD, lejos del servo y de los
cables de 5 V. Soporte independiente con el puerto acústico libre (doc 08).

## 4. Alimentación, masas y protección
- **Servo:** fuente externa de 5 V. Dimensionar con la corriente de bloqueo del **servo real** (dato por confirmar); para un micro servo, 5 V ≥ 2 A (3 A recomendado).
  PTC 2,5 A, P-MOS AO3401A contra polaridad invertida, TVS SMBJ5.0A, 1000 µF de bajo ESR + 100 nF en el conector J1 (con traba y polaridad marcada). S1 (NC) corta la potencia.
- **ESP32:** solo por USB. **+5V_SERVO nunca se une a VIN/5V**: así no hay realimentación entre la fuente externa y el USB; solo se comparten las masas en un punto ★.
- **Masa en estrella:** retorno del servo con su propio cable hasta ★; masas de los Hall y del micrófono juntas y unidas a ★ por un solo punto.
- **PWM a 3,3 V:** muchos micro servos lo aceptan (VERIFICAR con el servo real). Si no, 74AHCT125 alimentado a 5 V.
- **Ninguna señal de 5 V va directa a un pin del ESP32.**

## 5. Componentes que se mantienen y por qué
| Componente | Justificación |
|---|---|
| MCP1700-3302 + 1 µF/1 µF | Alimentación limpia y propia de los Hall (salida ratiométrica: el ruido de la alimentación aparece en la lectura) |
| 100 nF junto a cada Hall | Desacoplo recomendado por los fabricantes de sensores Hall lineales |
| RC 1 kΩ / 100 nF por canal Hall | Antialias (fc ≈ 1,6 kHz < 4 kHz, mitad de 8 kS/s por canal) y reserva de carga para el muestreo del ADC |
| Divisor 20 kΩ/30 kΩ (solo opción B) | Reduce una salida de 5 V a ≤ 3 V: **no se conectan señales de 5 V directamente al ESP32** |
| PTC 2,5 A, AO3401A, SMBJ5.0A | Protección de la fuente del servo: sobrecorriente, polaridad invertida, sobretensiones |
| 1000 µF bajo ESR + 100 nF | Picos de corriente del servo junto a su conector |
| S1 (NC) + J1 | Corte físico de la potencia del servo y desconexión para los ensayos sin servo |
| 220 Ω + 10 kΩ en PWM | Limita corriente y mantiene la señal en bajo mientras el ESP32 arranca |
| 33 Ω en SCK | Reduce flancos y reflexiones en el cable del micrófono |

**Eliminados en v3:** MCP6004/MCP6022, BAT54S y la red del canal piezoeléctrico, INA219 y el canal del Hall del plato.

## 6. Recursos del ESP32 clásico [CÁLCULO + COMPILACIÓN]
- El **ADC continuo (DMA) usa I2S0** en el ESP32 clásico → el micrófono va en **I2S1**.
- **ADC2 no tiene DMA** y choca con Wi-Fi → los 3 Hall están en ADC1.
- Muestreo **secuencial**: patrón H1 H2 H3 a 24 kS/s (mínimo admitido por el driver: 20 kS/s) → 8 kS/s por canal → suma de 8 → **1 kS/s por valva**. Desfase fijo entre valvas:
  0 / 41,7 / 83,3 µs (informado en INFO).
- LEDC (PWM) y esp_timer (marcas en µs) son independientes del ADC y del I2S.

## 7. Capacidad del enlace USB-serie [CÁLCULO]
| Flujo | kB/s |
|---|---|
| Hall H1–H3 (1 kS/s, 16 bits, bloques de 32) | 6,78 |
| Audio 8 kHz 16 bits (bloques de 256) | 16,78 |
| Comando del servo (200 Hz, solo en movimiento) | 5,20 |
| Estado (2 Hz) + eventos (≈ 20/s) | 0,61 |
| **Total** | **29,4** |

A 921 600 baudios (8N1) caben 92,2 kB/s → uso ≈ 32 %. Datos binarios con CRC.
