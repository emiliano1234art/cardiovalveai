# Materiales no impresos (lista mínima)

## Mecánica
| Cant. | Material | Medida | Uso | Nota |
|---|---|---|---|---|
| 1 | Varilla de latón (o acero) | Ø3,0 mm, ≥ 300 mm | los 8 pasadores (ÚNICA fijación comprada) | se usan 200,9 mm; sobra para equivocarse |
| 3 (+2) | Imán de neodimio N35–N52 | Ø4,0 × 2,0 mm, magnetización AXIAL | uno por valva | VERIFICAR medidas reales (pregunta 2) |
| 1 | Cianoacrilato (gotita) | — | imanes y manivela sobre el horn |  |
| 1 | Grasa PTFE o vaselina | — | zapatas del pistón, pasadores |  |
| 1 | Cinta adhesiva o pegamento caliente | — | fijar las pestañas de los 3 portasensores |  |

Corte de la varilla:
| Pasador | Cantidad | Largo (mm) |
|---|---|---|
| R1 pasador de bisagra | 3 | 49,0 |
| R2 pasador de horquilla | 3 | 10,8 |
| R3 pasador de manivela | 1 | 9,5 |
| R4 pasador de traba | 1 | 12,0 |

**Total: 200,9 mm.** Limar las puntas (sin rebabas, con un chaflán leve) para que entren rectos.

## Electrónica
| Cant. | Componente | Nota |
|---|---|---|
| 1 | Servo MG90S 180° (con sus horns y tornillos) | se usan el horn de UN brazo, su tornillo central y los 2 tornillos de las orejas |
| 3 | Sensor Hall LINEAL TO-92: DRV5055A1QLPG (recomendado) o SS49E/49E | NO un A3144 ni otro digital. VERIFICAR modelo (pregunta 1) |
| 1 | ESP32 DevKit V1 (ESP32-WROOM-32) + cable USB de datos | se alimenta por USB |
| 1 | Fuente 5 V ≥ 2 A (cargador USB de 5 V 2 A + cable cortado, o fuente de banco) | SOLO para el servo |
| 1 | Interruptor de palanca | corta los 5 V del servo |
| 1 | Condensador electrolítico 470–1000 µF 10 V | en los bornes del servo |
| 6 | Condensador cerámico 100 nF | 3 en los Hall + 3 en los filtros RC |
| 1 | Resistencia 220 Ω | señal PWM del servo |
| 3 | Resistencia 1 kΩ | filtros RC de los Hall |
| 3 × 40 cm | Cable de 3 hilos delgado (o cable plano) | uno por Hall |
| 1 | Placa perforada chica o protoboard + cables dupont |  |
| — | Termorretráctil o cinta aislante | patas de los Hall |

Si el Hall comprado solo funciona a 5 V (algunos 49E): agregar 3 × 20 kΩ y 3 × 30 kΩ (divisor de la salida). Ver el esquema.

## Herramientas
Sierra chica o alicate de corte para el latón · lima o lija · alicate · destornillador Phillips chico · cautín y estaño · pie de metro (recomendado).
