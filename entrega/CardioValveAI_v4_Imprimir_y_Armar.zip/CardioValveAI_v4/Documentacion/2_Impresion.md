# Impresión (PETG, boquilla 0,4 mm)

**Ninguna pieza necesita soportes.** Los agujeros horizontales son chicos (Ø3) y el techo de la ventana del servo es a dos aguas (45°), así que se imprimen sin soporte.
No hay piezas de soporte que retirar: todo lo que sale de la impresora es funcional. Lo único a limpiar es el borde (brim) del cuerpo.

## Parámetros comunes
- PETG · cama 75–85 °C · boquilla 230–245 °C · ventilador 30–50 %.
- Velocidad moderada (≤ 60 mm/s en perímetros externos) para que los agujeros salgan redondos.
- Sin «compensación de agujeros» del laminador: los ajustes ya están en el diseño y se comprueban con la probeta.
- Costura (seam) alineada atrás, lejos de los agujeros de los pasadores.

## Por pieza
| Archivo | Copias | Orientación en la cama | Soportes | Parámetros | PETG aprox. |
|---|---|---|---|---|---|
| 00_Probeta_x1 | 1 | De pie, como figura (cara de 66 × 12 mm en la cama) | No | capa 0,2 mm · 4 perímetros · 25 % relleno (igual que el cuerpo, sin brim) | 22,8 g |
| 01_Cuerpo_x1 | 1 | De pie, cara inferior en la cama | No (techo de la ventana a dos aguas; agujeros horizontales chicos) | capa 0,2 mm · 4 perímetros · 25 % relleno · borde (brim) 4 mm | 153,5 g |
| 02_Valva_x3 | 3 | Boca abajo: cara superior de la valva en la cama (barril, cola y alma hacia arriba) | No | capa 0,16 mm · 3 perímetros · 40 % relleno | 9,6 g |
| 03_Piston_x1 | 1 | Cara inferior del disco en la cama | No | capa 0,2 mm · 3 perímetros · 40 % relleno | 8,8 g |
| 04_Yugo_x1 | 1 | Acostado (placa plana en la cama) | No | capa 0,2 mm · 4 perímetros · 60 % relleno | 3,8 g |
| 05_Manivela_x1 | 1 | Plana, encastre del horn hacia ARRIBA (cara del pasador en la cama) | No | capa 0,16 mm · 4 perímetros · 100 % relleno | 1,3 g |
| 06_Portasensor_Hall_x3 | 3 | Acostado sobre el lomo (canal abierto hacia arriba) | No | capa 0,12 mm · 2 perímetros · 100 % relleno | 0,9 g |
| 07_Galga_XX (5 archivos) | 1 c/u | Acostada sobre una cara lateral | No | capa 0,16 mm · 3 perímetros · 50 % relleno | 4,0 g |

Total (obligatorias + probeta) ≈ 200,7 g de PETG (masas calculadas con relleno 100 %; las reales son menores).

## Placas 3MF (carpeta `3MF`)
Cada placa agrupa piezas con la misma altura de capa. Ábrelas en PrusaSlicer, OrcaSlicer, Bambu Studio o Cura y aplica los parámetros de la tabla.

| Placa | Contenido | Parámetros | Cabe en la cama |
|---|---|---|---|
| Placa_0_Probeta | 00_Probeta | capa 0,2 mm | sí |
| Placa_1_Cuerpo | 01_Cuerpo | capa 0,2 mm · brim 4 mm | sí |
| Placa_2_Piston_Yugo | 03_Piston, 04_Yugo | capa 0,2 mm | sí |
| Placa_3_Valvas_Manivela | 02_Valva_1, 02_Valva_2, 02_Valva_3, 05_Manivela | capa 0,16 mm | sí |
| Placa_4_Portasensores | 06_Portasensor_Hall_1, 06_Portasensor_Hall_2, 06_Portasensor_Hall_3 | capa 0,12 mm | sí |
| Placa_5_Galgas_OPCIONAL | 07_Galga_00, 07_Galga_20, 07_Galga_40, 07_Galga_60, 07_Galga_80 | capa 0,16 mm | sí |

## Después de imprimir
- Quitar el brim del cuerpo y repasar la primera capa con una lima si quedó «pata de elefante» (sobre todo en las ranuras guía del pistón).
- **No** agrandar los agujeros de los pasadores a ciegas: comparar primero con la probeta (Paso 1 de la guía).
- Las zapatas de los brazos del pistón (los 3 extremos) y sus ranuras llevan una capa fina de grasa PTFE o vaselina.
