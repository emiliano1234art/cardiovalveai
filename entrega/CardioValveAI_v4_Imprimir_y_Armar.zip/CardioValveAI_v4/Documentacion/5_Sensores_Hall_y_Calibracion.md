# Sensores Hall y calibración

## Cómo funciona
El imán va pegado en el extremo del barril y **gira con la valva**. El Hall está fijo en el portasensor, sobre la prolongación del eje de la bisagra,
a 5,1 mm del imán. Cuando la valva gira, cambia la dirección del campo que ve el Hall: la salida varía de forma continua y **monótona**
(siempre en el mismo sentido) en todo el recorrido. Cada Hall ve solo su imán (efecto de los otros dos ≈ 0,04 mT, despreciable).

## Digital vs. analógico
- **Analógico / lineal** (DRV5055, SS49E, 49E): entrega un voltaje proporcional al campo. **Es el que se necesita.**
- **Digital / interruptor** (A3144, US1881, módulos KY-003): solo cambia entre dos estados al pasar un umbral. **No sirve** para medir el ángulo.

## Señal esperada (CÁLCULO con un modelo de imán ideal, NO medición)
Campo radial en el Hall: 14.06 mT con la valva cerrada, -0.0 mT a 40°, -14.06 mT abierta a 80°.

| Sensor | V cerrada | V abierta 80° | Sin saturar 0–80° | Pendiente mín. (mV/°) |
|---|---|---|---|---|
| DRV5055A1 @3,3 V | 2,58 | 0,72 | sí | 19,4 |
| DRV5055A2 @3,3 V | 2,11 | 1,19 | sí | 9,7 |
| SS49E @3,3 V | 1,78 | 1,52 | sí | 2,7 |
| 49E/SS49E @5 V + divisor 0,6 | 1,62 | 1,38 | sí | 2,5 |

Los voltajes reales dependerán del imán real (grado N35–N52), de la tolerancia del sensor y de la impresión: **por eso se calibra**.

## Qué tan sensible es al montaje (cálculo)
| Desviación | Error si se usa la calibración original (°) |
|---|---|
| juego radial del barril u ±0,15 | 0,20 |
| juego vertical del barril z ±0,15 | 0,08 |
| portasensor 0,2 mm sin tocar el barril | 5,28 |
| portasensor 0,5 mm sin tocar el barril | 11,35 |

Lectura: el juego del barril casi no afecta, pero el **portasensor debe quedar tocando el barril**. Si se mueve, se recalibra esa valva.

## Calibración (por valva, con el servo SIN montar)
Una lectura Hall NO es un ángulo: hasta calibrar, solo indica que la valva se mueve.
1. Imprime las galgas opcionales `07_Galga_00 … 80`. Cada una apoya en la cara superior del cuerpo con su chaveta en la muesca índice de la valva, y su cara inclinada marca el ángulo.
2. `python cvai_calibrate.py galgas --port … --valva 1 --galgas 0,20,40,60,80 --repeticiones 3 --salida cal_valva1.csv`
   Para cada galga: empuja el yugo a mano hasta que la valva **toque** la galga, sostén y pulsa Enter. Repite con las valvas 2 y 3.
3. `python cvai_calibrate.py ajustar cal_valva1.csv cal_valva2.csv cal_valva3.csv --salida calib_hall.json` → curva por sensor, ruido y repetibilidad.
4. `python cvai_calibrate.py subir calib_hall.json --port …` → guarda la calibración en el ESP32.
5. Con el servo montado: `python cvai_calibrate.py video --port … --salida cal_video.csv` y un video lateral para comprobar ángulos intermedios e **histéresis** (abriendo vs. cerrando).

Sin galgas: se puede calibrar con fotos o video lateral y un transportador, con menor exactitud.
La curva se interpola entre puntos medidos; fuera de 0–80° no se extrapola.
