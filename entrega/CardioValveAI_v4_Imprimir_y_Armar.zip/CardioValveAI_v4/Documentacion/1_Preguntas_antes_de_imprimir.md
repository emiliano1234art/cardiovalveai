# Preguntas antes de imprimir (lista única)

Las piezas se dibujaron con medidas típicas. Responde esta lista (o mide con un pie de metro) **antes de imprimir las piezas afectadas**.
Si todo coincide, imprime tal cual. Si algo difiere, se cambia un número en `CAD/fuente/config4.py` y se regeneran las STL (`python build4.py`).

| # | Dato que falta | Valor usado en el diseño | Piezas afectadas | Por qué importa |
|---|---|---|---|---|
| 1 | Modelo EXACTO del sensor Hall (texto impreso en la cara plana, o enlace de compra) y si es un componente suelto TO-92 o viene en una placa (módulo) | TO-92 suelto, cuerpo 4,0 × 1,55 × 3,0 mm, lineal (analógico), p. ej. DRV5055A1QLPG | 06 Portasensor_Hall · esquema | Un módulo con placa NO entra en el portasensor. Un Hall digital (A3144, KY-003…) solo da sí/no: no sirve para medir el ángulo. |
| 2 | Imanes: diámetro × espesor y dirección de magnetización | Ø4,0 × 2,0 mm, axial (polos en las caras planas) | 02 Valva (ranura del imán) | La ranura tiene 0,2 mm de holgura. Un imán de otro tamaño no entra o queda suelto. |
| 3 | Servo: medidas reales del MG90S comprado (largo y ancho del cuerpo, separación de los agujeros de las orejas, distancia del eje al borde) | cuerpo 22,8 × 12,2 mm, orejas a 27,8 mm, eje a 5,9 mm del borde | 01 Cuerpo (tabique y ventana del servo) | Hay clones con medidas distintas. |
| 4 | Horn de UN brazo que trae el servo: diámetro del cubo, largo (centro → punta), ancho de la punta, espesor del brazo | cubo Ø7,0, largo 20,0, punta 4,0, espesor 1,8 mm | 05 Manivela | La manivela encastra sobre el horn. |
| 5 | Tamaño de la cama de la impresora | 220 × 220 mm | placas 3MF | Si es más chica, se redistribuyen las placas (la pieza mayor mide 90 × 90 mm). |
| 6 | ¿Consigues varilla de latón (o acero) de Ø3,0 mm? | Latón Ø3,0 mm | todas (agujeros a presión y libres) | Es la única fijación. Acero Ø3 también sirve (cuesta más cortarlo). Otro diámetro obliga a regenerar los agujeros. |

Lo que NO depende de estas respuestas y se puede imprimir ya: **00 Probeta**, **03 Pistón** y **04 Yugo** (salvo la respuesta 6).

La probeta (00) resuelve además el ajuste de TU impresora: ver «Paso 1» en la guía de armado.
