# Verificación (SOLO en CAD) · generado 2026-10-29 16:24

Todo lo de este documento se calculó sobre los modelos 3D. **Nada se ha probado físicamente.** La última sección lista lo que hay que comprobar con las piezas reales.

## Movimiento completo
- Barrido de todo el recorrido del servo en 37 posiciones (manivela por un lado) y 37 (servo girando al revés): **interferencias 0**.
- Apertura: 0–80° con comando 130°→50°; con el recorrido completo del servo, -12,6° a 92,6° sin topes (punto muerto del yugo).
- Contactos de diseño: la punta del portasensor apoya en el extremo del barril (tope axial).
- Piezas fijas sin choques entre sí: sí.

Holguras mínimas en todo el recorrido (mm):
| Par | Mínima |
|---|---|
| Valva_1 ↔ Cuerpo | 0,20 |
| Valva_1 ↔ Valva_2 | 0,60 |
| Valva_1 ↔ Portasensor_1 | 0,00 |
| Valva_1 ↔ Piston | 0,40 |
| Valva_1 ↔ Pasadores_horquilla | 0,20 |
| Piston ↔ Cuerpo | 0,25 |
| Yugo ↔ Cuerpo | 12,50 |
| Manivela ↔ Cuerpo | 6,00 |
| Manivela ↔ Yugo | 0,50 |
| Horn ↔ Cuerpo | 4,72 |
| Piston ↔ Servo | 4,40 |
| Pasador_traba ↔ Valva_1 | 7,05 |
| Valva_3 ↔ Cuerpo | 0,20 |

## Montaje y accesos
| Comprobación | OK |
|---|---|
| Pasador de bisagra 1: entra desde afuera hasta el fondo del barril sin chocar | sí |
| Pasador de bisagra 1: el extremo que sobresale se toma con un alicate (Ø10 libre) | sí |
| Portasensor 1: se retira hacia afuera sin desarmar la válvula | sí |
| Cable del Hall 1: sale hacia afuera sin obstáculos | sí |
| Pasador de bisagra 2: entra desde afuera hasta el fondo del barril sin chocar | sí |
| Pasador de bisagra 2: el extremo que sobresale se toma con un alicate (Ø10 libre) | sí |
| Portasensor 2: se retira hacia afuera sin desarmar la válvula | sí |
| Cable del Hall 2: sale hacia afuera sin obstáculos | sí |
| Pasador de bisagra 3: entra desde afuera hasta el fondo del barril sin chocar | sí |
| Pasador de bisagra 3: el extremo que sobresale se toma con un alicate (Ø10 libre) | sí |
| Portasensor 3: se retira hacia afuera sin desarmar la válvula | sí |
| Cable del Hall 3: sale hacia afuera sin obstáculos | sí |
| Subconjunto pistón + valvas: entra desde arriba (valvas abiertas) hasta su lugar, sin chocar con el cuerpo | sí |
| Servo con horn y manivela: entra por la ventana (horn colgando) y el pasador entra en la ranura del yugo | sí |
| Tornillo 1 de la oreja del servo: destornillador Ø4 desde afuera por la ventana | sí |
| Tornillo 2 de la oreja del servo: destornillador Ø4 desde afuera por la ventana | sí |
| Cable del servo: sale por la ventana | sí |
| Corredera: el pasador recorre la ranura de la cola sin llegar a sus extremos | sí |
| Yugo: el pasador de la manivela recorre la ranura sin llegar a sus extremos | sí |

## Retención de pasadores y piezas
| Unión | Ajuste | Nota |
|---|---|---|
| Pasador de bisagra en la pared y el resalte | a presión | Se saca tirando con alicate del extremo que sobresale 4 mm del rebaje |
| Valva en el pasador | libre (3.3 sobre Ø3.0) | Axialmente queda entre el resalte del cuerpo (−v) y la punta del portasensor (+v) |
| Pasadores de las horquillas | a presión en las dos mejillas | La cola los encierra: no pueden salir con la válvula armada |
| Pasador de la manivela | a presión | No puede retroceder: detrás está el horn |
| Espiga del yugo | pasador de traba a presión en la espiga, apoyado en el disco | Empuja el pistón hacia arriba con el hombro y tira hacia abajo con la traba |
| Imán | ranura con 0,2 mm de holgura + gota de cianoacrilato | Empujado hasta el fondo; la ranura fija su orientación |
| Portasensor | deslizante en el túnel (0.25 mm por lado) | Empujado hasta tocar el barril; fijarlo con cinta o una gota de pegamento caliente en la pestaña |

## Impresión
| Pieza | Malla cerrada | Cuerpos | Cabe en la cama | Área en voladizo > 45° (mm²) |
|---|---|---|---|---|
| 00_Probeta_x1 | sí | 1 | sí | 302,9 |
| 01_Cuerpo_x1 | sí | 1 | sí | 240,9 |
| 02_Valva_x3 | sí | 1 | sí | 157,3 |
| 03_Piston_x1 | sí | 1 | sí | 45,9 |
| 04_Yugo_x1 | sí | 1 | sí | 0,0 |
| 05_Manivela_x1 | sí | 1 | sí | 0,0 |
| 06_Portasensor_Hall_x3 | sí | 1 | sí | 0,0 |
| 07_Galga_00_x1 | sí | 1 | sí | 3,4 |
| 07_Galga_20_x1 | sí | 1 | sí | 4,2 |
| 07_Galga_40_x1 | sí | 1 | sí | 4,7 |
| 07_Galga_60_x1 | sí | 1 | sí | 4,6 |
| 07_Galga_80_x1 | sí | 1 | sí | 4,6 |
Los voladizos corresponden a techos de agujeros chicos y chaflanes: puentes cortos que el PETG imprime sin soporte.

## Galgas
Cada galga toca la valva en su ángulo y no la toca en los demás: sí.

## Esfuerzo del servo (estimación)
Par necesario ≈ 0,10 kg·cm frente a ≈ 1,8 kg·cm del MG90S (dato de catálogo NO verificado) → margen ≈ ×17,7.
Peor ángulo de transmisión: coseno 0,77 (bueno). Si UNA valva se traba, la fuerza actúa a 21.5 mm del eje; el pistón podría acuñarse en seco (límite ≈ 12.9 mm con μ 0,35) pero no lubricado (≈ 30.0 mm con μ 0,15): engrasar las zapatas.

## Lo que falta probar con las piezas reales
1. Ajustes reales de la impresora (probeta): latón a presión y libre, imán, pilotos, túnel.
2. Que las 3 valvas abran y cierren a mano, suaves y juntas (Paso 8), y que los portasensores no las frenen.
3. Medidas reales del servo y del horn (encastre de la manivela, orejas en el tabique).
4. Sentido y recorrido del servo (comandos 130° y 50°) y que no zumbe en reposo.
5. Señal real de cada Hall: que sea monótona, sin saturar, y su ruido. Curva de calibración con galgas, repetibilidad e histéresis.
6. Que los portasensores no se muevan con el uso (si se mueven, recalibrar).
7. Desgaste de las ranuras de las colas y del yugo tras muchos ciclos.
