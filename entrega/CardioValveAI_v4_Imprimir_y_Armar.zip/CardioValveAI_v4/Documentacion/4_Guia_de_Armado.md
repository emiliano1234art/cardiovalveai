# Guía de armado

Mira `Vistas/Despiece_numerado.png`: los números (01–06) son los de las piezas impresas y R1–R9 los de las compradas.
Cada valva tiene su número grabado en la cara superior del cuerpo, junto a una muesca índice: valva 1 ↔ Hall 1 ↔ GPIO36, etc.

Convención: el **lado del pasador** de cada bisagra es por donde entra el latón; el **lado del sensor** es el extremo opuesto del mismo eje, donde entra el portasensor.

### Paso 1 · Probeta (antes que nada)
Imprime `00_Probeta_x1` con los mismos parámetros del cuerpo. Las muescas de arriba numeran las columnas 1, 2 y 3. La columna **2** es el valor del diseño.
- **Ø3 a presión** (2,85 / 2,95 / 3,05): el latón debe entrar con alicate o golpecitos y NO salir con la mano.
- **Ø3 libre** (3,20 / 3,30 / 3,40): el latón debe girar sin juego visible.
- **Ranura del imán** (4,1 / 4,2 / 4,3 mm): el imán entra con el dedo.
- **Pilotos** de los tornillos del servo (1,6 / 1,8 / 2,0): el tornillo entra firme sin partir el plástico.
- **Túnel**: el portasensor (06) entra y desliza sin juego lateral.

Si la columna 2 funciona en todo, imprime el resto tal cual. Si otra columna es mejor, cambia `PIN_PRESS`, `PIN_FREE` o `SERVO_PILOT` en `config4.py` y regenera, o repasa a mano con una broca del diámetro de la columna buena.

### Paso 2 · Cortar el latón
Corta 3 × 49,0 mm (R1), 3 × 10,8 mm (R2), 1 × 9,5 mm (R3) y 1 × 12,0 mm (R4). Lima las puntas.

### Paso 3 · Imanes en las valvas (02)
En el extremo del barril del lado del sensor hay una ranura vertical. Pon una gota chica de cianoacrilato y empuja el imán **hasta el fondo**, de canto.
Que no entre pegamento en el agujero del barril. La polaridad no importa (la calibración la absorbe), pero pon los 3 iguales para que las curvas se parezcan.

### Paso 4 · Valvas en el pistón (03)
Mete la cola de cada valva entre las dos mejillas de una horquilla del pistón y empuja un pasador **R2 (10,8 mm)** a presión por las dos mejillas, atravesando la ranura de la cola.
Debe quedar al ras de ambas mejillas. Mueve la valva: debe girar y la cola deslizar sin trabarse.

### Paso 5 · Yugo (04) en el pistón
Pasa la espiga del yugo de abajo hacia arriba por la ranura central del pistón. Encima del disco, empuja el pasador **R4 (12,0 mm)** a presión por el agujero de la espiga.
El yugo queda colgando bajo el pistón con su ranura horizontal.

### Paso 6 · Subconjunto en el cuerpo (01)
Abre las tres valvas al máximo y baja el subconjunto desde arriba: las zapatas de los 3 brazos entran en las 3 ranuras guía del cuerpo (en las comisuras) y el yugo baja hacia el faldón.
Gíralo hasta que cada valva quede frente a su número. Baja hasta que el agujero de cada barril quede alineado con el agujero de la pared.

### Paso 7 · Pasadores de bisagra (R1)
Desde AFUERA, por el rebaje plano del lado del pasador, mete cada R1 (49,0 mm): atraviesa la pared, el resalte de empuje y el barril,
hasta el fondo ciego del barril. Los últimos ~17,3 mm van a presión en la pared: termina con alicate o golpecitos. Queda asomando ≈ 4,0 mm para sacarlo con alicate si hace falta.

### Paso 8 · Prueba a mano (sin servo)
Empuja el yugo hacia arriba y abajo por la ventana del servo. Las tres valvas deben abrir y cerrar **juntas y suaves**, de cerradas a abiertas, sin roces.
Si algo roza: localiza el punto, lima y repite. Engrasa las zapatas. **No sigas hasta que esto funcione.**

### Paso 9 · Hall en los portasensores (06)
Suelda un cable de 3 hilos a cada Hall (aísla cada pata). Coloca el Hall en el canal del portasensor, **cara plana mirando hacia el centro de la válvula**,
apoyado contra el labio de la punta; las patas salen hacia afuera. Una gota de pegamento caliente lo sujeta.

### Paso 10 · Portasensores en el cuerpo
Por el rebaje plano del lado del sensor, mete el portasensor en su túnel (el nervio del lomo entra en la ranura del túnel: solo entra en una posición)
y empújalo **hasta que la punta toque el extremo del barril** (se siente el tope). No fuerces. Fija la pestaña a la pared con cinta o una gota de pegamento caliente.
Repite la prueba del Paso 8: las valvas deben seguir moviéndose libres. Si un portasensor se mueve después, hay que recalibrar esa valva.
Para cambiar un Hall: despega la pestaña y tira del portasensor; no hace falta desarmar nada más.

### Paso 11 · Electrónica y calibración
Arma el circuito de `Electronica/Esquema_v4.png` **sin el servo**. Carga el firmware (el mismo de la v3: mismos pines; el micrófono queda sin conectar).
Calibra cada valva empujando el yugo a mano (ver `5_Sensores_Hall_y_Calibracion.md`).

### Paso 12 · Servo (R7)
1. Prensa el pasador **R3 (9,5 mm)** en la manivela (05): entra por el lado del encastre y queda al ras del fondo del encastre.
2. Conecta solo el servo (sin montar) y su fuente, y ejecuta `python cvai_montaje.py --port …`: el servo va a **180°** y queda sin pulsos.
3. Calza el horn de un brazo en el eje con el brazo **hacia abajo** (colgando) y aprieta su tornillo central. Pega la manivela sobre el horn (encastre del lado del horn) con 2 gotas de cianoacrilato: el pasador queda hacia afuera.
4. Lleva el servo por la ventana, acostado, con la manivela colgando, hasta que el pasador entre en la ranura del yugo y las orejas apoyen en el tabique.
5. Atornilla las 2 orejas con los tornillos del servo, desde afuera por la ventana. El cable sale por la ventana.
6. Con el firmware: `MOVE 130 1000` → valvas cerradas; `MOVE 50 1000` → abiertas. Son los valores por omisión del firmware (cerrado 130°, abierto 50°).
   Si al revés: el horn quedó mal calzado; repite 2–3.

Listo: `python cvai_record.py --port … --ciclos 10 --live`.
