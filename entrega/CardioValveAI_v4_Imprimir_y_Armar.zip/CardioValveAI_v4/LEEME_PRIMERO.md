# CardioValveAI v4 · banco académico de una válvula trivalva (SIN fluido, NO es un dispositivo médico)

Diámetro exterior 90,0 mm · alto 56,5 mm · 3 valvas movidas por UN servo MG90S (180°) · 3 sensores Hall + 3 imanes · ESP32.
Apertura de trabajo 0–80° (comando del servo 130° → 50°). El mecanismo no tiene topes: el servo no se fuerza en ningún punto de su recorrido.

## 1 · Antes de imprimir
Lee **Documentacion/1_Preguntas_antes_de_imprimir.md**. Las medidas del Hall, los imanes, el servo y su horn se tomaron de valores típicos:
si lo que compraste es distinto, hay que ajustar 4 piezas antes de imprimirlas.

## 2 · Qué imprimir (PETG) — carpeta `STL/01_Imprimir_Obligatorio`
El número del final del nombre es la **cantidad de copias**. Las STL ya están orientadas como van en la cama.

| Archivo | Copias | Para qué |
|---|---|---|
| `00_Probeta_x1.stl` | 1 | Probeta de ajustes: latón Ø3 a presión y libre, ranura del imán, pilotos de los tornillos del servo y túnel del portasensor |
| `01_Cuerpo_x1.stl` | 1 | Cuerpo único: anillo de bisagras, faldón, ranuras guía del pistón, túneles de los Hall, tabique y ventana del servo |
| `02_Valva_x3.stl` | 3 | Valva con barril de bisagra, imán en el extremo +v y cola ranurada (las tres son iguales) |
| `03_Piston_x1.stl` | 1 | Pistón: disco con 3 horquillas y 3 brazos con zapatas guía |
| `04_Yugo_x1.stl` | 1 | Yugo escocés: ranura horizontal para el pasador de la manivela; espiga que atraviesa el pistón |
| `05_Manivela_x1.stl` | 1 | Manivela que encastra sobre el horn de UN brazo del servo; lleva el pasador del yugo |
| `06_Portasensor_Hall_x3.stl` | 3 | Portasensor del Hall TO-92: entra desde afuera por el túnel del cuerpo (se cambia sin desarmar) |

Total obligatorio: **10 piezas** (+ 1 probeta). Ninguna lleva soportes.
Opcional (`STL/02_Opcional`): 5 galgas de calibración (`07_Galga_00 … 80`), 1 copia de cada una.
`STL/03_Referencia_NO_IMPRIMIR`: servo, horn, pasadores de latón, imanes y Hall, solo para ver y medir.

Atajo: la carpeta `3MF` trae una placa lista por cada grupo de parámetros (todas las copias ya distribuidas). Orden: Placa_0 (probeta) → Placa_1 … Placa_4 → Placa_5 (opcional).

## 3 · Qué comprar (lista completa en Documentacion/3_Materiales_no_impresos.md)
- 1 varilla de **latón Ø3 mm** (≥ 300 mm). Es la ÚNICA fijación: se corta en 8 pasadores.
- 3 imanes de neodimio **Ø4 × 2 mm**, magnetización axial (+2 de repuesto).
- 3 sensores Hall **lineales** TO-92 (recomendado DRV5055A1QLPG). Un A3144 (digital) NO sirve.
- Servo MG90S (trae el horn y los 2 tornillos que se usan), ESP32 DevKit V1, fuente de 5 V ≥ 2 A, cables, 4 resistencias, 7 condensadores.
**No hay tornillos, tuercas ni insertos que comprar.**

## 4 · Armado
**Documentacion/4_Guia_de_Armado.md** (12 pasos, con el despiece numerado `Vistas/Despiece_numerado.png`).
Herramientas: sierra chica o alicate de corte, lima o lija, alicate, destornillador Phillips chico, cautín, cianoacrilato.

## 5 · Otros archivos
- `CAD/` sólidos STEP editables (cada pieza y el conjunto) + `CAD/fuente/`, el código Python paramétrico que los genera: `config4.py` tiene TODAS las medidas;
  `python build4.py && python verify4.py && python plates4.py` regenera STL, comprobación y placas (requiere build123d, trimesh, manifold3d, shapely).
- `CardioValveAI_v4_Animacion.mp4` (26 s): armado desde el despiece, apertura y cierre por fuera, el mecanismo por dentro y la vista superior.
- `Blender/CardioValveAI_v4.blend` conjunto con animación de apertura y cierre.
- `Electronica/Esquema_v4.png` alimentación y conexiones.
- `Firmware/` el firmware del ESP32 (el de la v3: mismos pines) y `Herramientas_Mac/` los programas de registro, calibración y `cvai_montaje.py` (posición de montaje del servo).
- `Documentacion/6_Verificacion_CAD.md` qué se comprobó en el CAD y qué falta probar con las piezas reales.

**Estado:** diseño verificado SOLO en CAD (interferencias, holguras, accesos, montaje y campo magnético calculado). No se ha impreso ni probado físicamente.
