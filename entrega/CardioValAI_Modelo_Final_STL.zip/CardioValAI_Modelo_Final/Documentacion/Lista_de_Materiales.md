# CardioVal AI — Lista de materiales

«VERIFICAR» = medida tomada de fichas o de modelos de referencia, no de un plano oficial: mídela en la pieza comprada y, si cambia, ajusta `config.py` y regenera.

| Componente | Cant. | Función | Tipo | Especificación / dimensiones críticas |
|---|---|---|---|---|
| CardioValAI_Valve_Ring.stl | 1 | Anillo valvular con comisuras, bisagras, ranuras de mando, almohadillas de sensores y alojamiento Hall | Imprimible (PETG) | 72,0 × 78,1 × 24,0 mm |
| CardioValAI_Leaflet_1.stl | 1 | Valva 1 (semilunar simplificada, barril de bisagra y cola de mando) | Imprimible (PETG) | 28,3 × 33,9 × 10,6 mm |
| CardioValAI_Leaflet_2.stl | 1 | Valva 2 (semilunar simplificada, barril de bisagra y cola de mando) | Imprimible (PETG) | 28,3 × 33,9 × 10,6 mm |
| CardioValAI_Leaflet_3.stl | 1 | Valva 3 (semilunar simplificada, barril de bisagra y cola de mando) | Imprimible (PETG) | 28,3 × 33,9 × 10,6 mm |
| CardioValAI_Link_Normal.stl | 4 | Biela rígida (modo normal). 3 + 1 de repuesto | Imprimible (PETG) | 6,0 × 32,0 × 3,0 mm |
| CardioValAI_Link_LostMotion.stl | 2 | Biela con recorrido perdido (apertura restringida / asimétrica). 1 marca | Imprimible (PETG) | 6,0 × 37,5 × 3,0 mm |
| CardioValAI_Link_LostMotion_IC.stl | 1 | Biela corta con recorrido perdido (cierre incompleto 12°). 2 marcas | Imprimible (PETG) | 6,0 × 36,1 × 3,0 mm |
| CardioValAI_Opening_Stop_84.stl | 3 | Tope de seguridad (84°) — se usa en modo normal y cierre incompleto | Imprimible (PETG) | 7,8 × 11,0 × 4,4 mm |
| CardioValAI_Opening_Stop_60.stl | 1 | Tope intercambiable 60° | Imprimible (PETG) | 7,8 × 11,0 × 7,2 mm |
| CardioValAI_Opening_Stop_45.stl | 1 | Tope intercambiable 45° | Imprimible (PETG) | 7,8 × 11,0 × 8,3 mm |
| CardioValAI_Actuator_Plate.stl | 1 | Plato actuador (corredera) con bujes, orejetas y horquilla | Imprimible (PETG) | 66,6 × 69,5 × 13,0 mm |
| CardioValAI_Pushrod.stl | 1 | Empujador servo → plato | Imprimible (PETG) | 5,6 × 35,6 × 3,0 mm |
| CardioValAI_Column.stl | 3 | Columna guía y soporte del anillo | Imprimible (PETG) | 8,0 × 8,0 × 58,1 mm |
| CardioValAI_Piezo_Mount.stl | 1 | Soporte del disco piezoeléctrico (Ø15; adaptador para Ø12) | Imprimible (PETG) | 22,0 × 30,0 × 4,0 mm |
| CardioValAI_Piezo_Cover.stl | 1 | Tapa protectora del piezo (no lo presiona) | Imprimible (PETG) | 22,0 × 30,0 × 3,4 mm |
| CardioValAI_Piezo_Adapter_12mm.stl | 1 | Anillo adaptador para disco Ø12 | Imprimible (PETG) | 15,2 × 15,2 × 0,6 mm |
| CardioValAI_MEMS_Mount.stl | 1 | Escuadra regulable y portaplaca del micrófono INMP441 | Imprimible (PETG) | 36,0 × 30,0 × 17,7 mm |
| CardioValAI_Servo_Mount.stl | 1 | Soporte del MG90S con escuadras | Imprimible (PETG) | 40,2 × 34,0 × 20,2 mm |
| CardioValAI_ESP32_Mount.stl | 1 | Cuna del ESP32 DevKit (apoya en los extremos, pines libres) | Imprimible (PETG) | 59,8 × 32,8 × 19,0 mm |
| CardioValAI_Angle_Scale.stl | 1 | Transportador 0–90° para medir la valva 1 con cámara lateral | Imprimible (PETG) | 92,7 × 70,0 × 2,0 mm |
| CardioValAI_Base.stl | 1 | Base modular 200 × 180 mm | Imprimible (PETG) | 200,0 × 180,0 × 6,0 mm |
| CardioValAI_Tolerance_Coupon.stl | 1 | Probeta de holguras: ejes Ø2 y pilotos M2/M3 | Imprimible (PETG) | 60,0 × 14,0 × 6,0 mm |
| Servomotor MG90S (con horn de un brazo) | 1 | Mueve el plato actuador | Comercial | Cuerpo ≈ 22,8 × 12,2 × 22,7 mm; orejas a 27,8 mm (VERIFICAR); agujero del horn a 8 mm del eje (VERIFICAR) |
| ESP32 DevKit (30 o 38 pines) | 1 | Adquisición y control | Comercial | Referencia 55 × 28 mm (VERIFICAR; cuna para 55,8 × 28,8) |
| Módulo micrófono MEMS INMP441 (I²S) | 1 | Sonido de apertura y cierre | Comercial | Placa ≈ 14 mm (VERIFICAR; ranura para 14,5 × 14,5 × 1,6) |
| Disco piezoeléctrico Ø15 mm (o Ø12 con adaptador) | 2 | Vibración transmitida al anillo (1 de repuesto) | Comercial | Espesor ≈ 0,45 mm, con cables |
| Varilla de acero rectificada Ø2 mm, cortada a 56 mm | 3 | Ejes de bisagra de las valvas | Comercial | Ø2,00 h8; extremos sin rebabas |
| Tornillo M2×8 cabeza cilíndrica (DIN 912) | 5 | Cola–biela (autorroscante en la cola) ×3 · orejas del servo ×2 | Comercial | Acero o inox |
| Tornillo M2×10 + tuerca M2 | 3 | Biela–orejeta del plato | Comercial |  |
| Tornillo M2×14 + tuerca M2 | 1 | Horquilla del plato–empujador | Comercial |  |
| Tornillo M2×6 (o el del horn) | 1 | Empujador–horn | Comercial | Autorroscante en el agujero del horn |
| Tornillo M2×20 + tuerca M2 | 3 | Topes de apertura (desde la cara superior) | Comercial | +2 de repuesto para módulos |
| Tornillo M2×16 | 2 | Tapa + soporte del piezo a la almohadilla | Comercial |  |
| Tornillo M2×8 | 2 | Escuadra del MEMS a la almohadilla | Comercial |  |
| Tornillo M3×10 | 3 | Columnas a la base (desde abajo) | Comercial |  |
| Tornillo M3×30 | 3 | Anillo a las columnas (desde las comisuras) | Comercial |  |
| Tornillo M3×10 + arandela de goma M3 | 4 | Soporte del servo a la base (antivibración) | Comercial | 8 arandelas (una arriba y otra abajo del pie) |
| Tornillo M3×8 | 2 | Cuna del ESP32 a la base (desde abajo) | Comercial |  |
| Arandelas M2 | 10 | Bajo cabezas y tuercas | Comercial |  |
| Resorte de extensión pequeño (Ø3 × 15–20 mm, k ≈ 0,05 N/mm) o elástico de silicona Ø1 mm | 2 | Abre la valva en los módulos de recorrido perdido | Comercial | Fuerza ≈ 0,3–0,6 N |
| Patas de goma adhesivas Ø10 mm | 4 | Aislamiento de vibraciones externas | Comercial |  |
| Fuente 5 V ≥ 2 A + condensador 470–1000 µF | 1 | Alimentación del servo (tierra común con el ESP32) | Comercial |  |
| Protoboard + cables Dupont | 1 | Conexiones | Comercial |  |
| Resistencia 1 MΩ + diodo zener 3,3 V (o divisor + protección) | 1 | Acondicionamiento del piezo hacia el ADC | Comercial | Ver guía de ensamblaje |
| Bridas plásticas 2,5 mm | 10 | Alivio de tensión y canales de cable | Comercial |  |
| Grasa de PTFE | 1 | Bujes del plato y bisagras | Comercial |  |
| Cianoacrilato | 1 | Fijar los ejes en el anillo (solo en los extremos) | Comercial |  |
| (Opcional) Imán de neodimio Ø3 × 1 mm + sensor Hall lineal (p. ej. DRV5055 / SS49E) | 3 | Medición del ángulo real (alternativa B) | Comercial | Alojamientos ya previstos en la cola y en el anillo |

También en formato CSV: `Lista_de_Materiales.csv`.
