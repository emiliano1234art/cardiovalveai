# CardioVal AI — Guía de impresión 3D (FDM, PETG)

**Impresora de referencia:** cama ≥ 220 × 220 mm · boquilla 0,4 mm · PETG 230–245 °C · cama 70–80 °C · ventilador 30–50 %.
Todas las piezas caben en el volumen de impresión de referencia (verificado automáticamente). Masa total estimada (densidad 1,27 g/cm³, 100 % macizo): **≈ 397 g** (con el relleno indicado será menor).

**Primero imprime `CardioValAI_Tolerance_Coupon.stl`**: fila superior = agujeros para el eje Ø2 (2,0–2,5 mm); fila inferior = pilotos para tornillos (1,6–1,9 = M2, 2,4/2,6 = M3).
Elige el diámetro que gira libre con el eje (valvas y bielas) y el que queda firme (anillo). Si difieren de los valores por defecto, cámbialos en `config.py`
(`PIN_HOLE_LEAF`, `PIN_HOLE_RING`, `M2_PILOT`, `M3_PILOT`) y vuelve a generar todo con `python build_all.py`.

| Archivo STL | Cant. | Material | Orientación | Capa | Relleno | Perímetros | Soportes | Tamaño (mm) | Masa c/u | Observaciones |
|---|---|---|---|---|---|---|---|---|---|---|
| `CardioValAI_Valve_Ring.stl` | 1 | PETG | Cara inferior en la cama (comisuras hacia arriba). | 0,20 mm | 50 % | 4 | No | 72,0 × 78,1 × 24,0 | 35,4 g | Repasar los agujeros horizontales de Ø2,1 con broca de 2,0–2,1 mm si quedan ovalados. |
| `CardioValAI_Leaflet_1.stl` | 1 | PETG | Cara inferior plana de la valva en la cama. | 0,12 mm | 100 % | 3 | Sí (árbol, solo bajo la cola) | 28,3 × 33,9 × 10,6 | 1,7 g | Imprimir con la cara inferior plana en la cama. Soporte mínimo (árbol) bajo la cola inclinada 40°. |
| `CardioValAI_Leaflet_2.stl` | 1 | PETG | Cara inferior plana de la valva en la cama. | 0,12 mm | 100 % | 3 | Sí (árbol, solo bajo la cola) | 28,3 × 33,9 × 10,6 | 1,7 g | Imprimir con la cara inferior plana en la cama. Soporte mínimo (árbol) bajo la cola inclinada 40°. |
| `CardioValAI_Leaflet_3.stl` | 1 | PETG | Cara inferior plana de la valva en la cama. | 0,12 mm | 100 % | 3 | Sí (árbol, solo bajo la cola) | 28,3 × 33,9 × 10,6 | 1,7 g | Imprimir con la cara inferior plana en la cama. Soporte mínimo (árbol) bajo la cola inclinada 40°. |
| `CardioValAI_Link_Normal.stl` | 4 | PETG | Plana (3 mm de alto). | 0,20 mm | 100 % | 3 | No | 6,0 × 32,0 × 3,0 | 0,7 g | Plana. Sin marcas. |
| `CardioValAI_Link_LostMotion.stl` | 2 | PETG | Plana. | 0,20 mm | 100 % | 3 | No | 6,0 × 37,5 × 3,0 | 0,7 g | Plana. |
| `CardioValAI_Link_LostMotion_IC.stl` | 1 | PETG | Plana. | 0,20 mm | 100 % | 3 | No | 6,0 × 36,1 × 3,0 | 0,7 g | Plana. |
| `CardioValAI_Opening_Stop_84.stl` | 3 | PETG | Brida en la cama. | 0,20 mm | 100 % | 3 | No | 7,8 × 11,0 × 4,4 | 0,3 g | Brida en la cama. |
| `CardioValAI_Opening_Stop_60.stl` | 1 | PETG | Brida en la cama. | 0,20 mm | 100 % | 3 | No | 7,8 × 11,0 × 7,2 | 0,3 g | Brida en la cama. |
| `CardioValAI_Opening_Stop_45.stl` | 1 | PETG | Brida en la cama. | 0,20 mm | 100 % | 3 | No | 7,8 × 11,0 × 8,3 | 0,4 g | Brida en la cama. |
| `CardioValAI_Actuator_Plate.stl` | 1 | PETG | Cara inferior en la cama (bujes, orejetas y horquilla hacia arriba). | 0,20 mm | 40 % | 4 | No | 66,6 × 69,5 × 13,0 | 13,8 g | Repasar los bujes Ø8,6 con lija y lubricar con grasa de PTFE. |
| `CardioValAI_Pushrod.stl` | 1 | PETG | Plano. | 0,20 mm | 100 % | 3 | No | 5,6 × 35,6 × 3,0 | 0,7 g | Plano. |
| `CardioValAI_Column.stl` | 3 | PETG | Vertical. | 0,20 mm | 40 % | 4 | No | 8,0 × 8,0 × 58,1 | 3,5 g | Vertical. Lijar la superficie de deslizamiento (grano 400) y lubricar. |
| `CardioValAI_Piezo_Mount.stl` | 1 | PETG | Cara de contacto con el anillo en la cama. | 0,20 mm | 100 % | 4 | No | 22,0 × 30,0 × 4,0 | 3,0 g | Cara de contacto con el anillo en la cama. |
| `CardioValAI_Piezo_Cover.stl` | 1 | PETG | Cara exterior en la cama. | 0,20 mm | 40 % | 3 | No | 22,0 × 30,0 × 3,4 | 2,2 g | Cara exterior en la cama. |
| `CardioValAI_Piezo_Adapter_12mm.stl` | 1 | PETG | Plano. | 0,15 mm | 100 % | 2 | No | 15,2 × 15,2 × 0,6 | 0,0 g | Solo si el disco comprado es de 12 mm. |
| `CardioValAI_MEMS_Mount.stl` | 1 | PETG | Cara exterior de la escuadra en la cama. | 0,20 mm | 40 % | 3 | Sí | 36,0 × 30,0 × 17,7 | 4,6 g | Apoyar la cara exterior de la escuadra en la cama; soportes bajo el portaplaca. |
| `CardioValAI_Servo_Mount.stl` | 1 | PETG | Pie en la cama. | 0,20 mm | 50 % | 4 | No | 40,2 × 34,0 × 20,2 | 7,6 g | Fijar a la base sobre arandelas de goma (antivibración). |
| `CardioValAI_ESP32_Mount.stl` | 1 | PETG | Piso en la cama. | 0,20 mm | 30 % | 3 | No | 59,8 × 32,8 × 19,0 | 14,1 g |  |
| `CardioValAI_Angle_Scale.stl` | 1 | PETG | Plano, marcas hacia arriba. | 0,20 mm | 30 % | 3 | No | 92,7 × 70,0 × 2,0 | 16,4 g | Plano; marcas hacia arriba. |
| `CardioValAI_Base.stl` | 1 | PETG | Plana; usar borde (brim) 5 mm. | 0,20 mm | 20 % | 4 | No | 200,0 × 180,0 × 6,0 | 271,1 g | Cabe en camas ≥ 220 × 220 mm. Usar borde (brim) de 5 mm para evitar alabeo. |
| `CardioValAI_Tolerance_Coupon.stl` | 1 | PETG | Plana. | 0,20 mm | 100 % | 3 | No | 60,0 × 14,0 × 6,0 | 6,1 g | Imprimir primero: elegir los diámetros reales que ajustan con el eje y los tornillos comprados. |

**Notas generales**
- Los STL ya vienen orientados y apoyados en z = 0. No escalar: unidades en milímetros.
- Agujeros horizontales pequeños (ejes Ø2,1 del anillo y pilotos M2 de las almohadillas) se imprimen como puentes; si quedan ovalados, repasarlos con broca manual.
- Las valvas se imprimen al 100 % y con capa 0,12 mm para que la superficie y el barril de la bisagra salgan precisos.
- Piezas móviles y fijas se imprimen por separado (ninguna pieza móvil está fusionada).
- «Soportes = Sí» proviene del análisis automático de voladizos (> 45° y techos anchos); los agujeros pequeños (≤ 3 mm) y los techos planos de hasta 12 mm se consideran puentes imprimibles.
