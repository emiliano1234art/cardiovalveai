# CardioVal AI — Modelo mecánico definitivo v1 (impresión 3D)

Prototipo universitario de **válvula aórtica trivalva** accionada por **un solo servomotor MG90S**, con sensor piezoeléctrico, micrófono MEMS INMP441 y ESP32.
**Uso académico y experimental. No es un dispositivo médico ni implantable. No usa presión ni líquido.**

## Contenido del paquete
- `CardioValAI_STL/` — piezas imprimibles, una por archivo, orientadas para la cama (mm).
- `CardioValAI_STL/CardioValAI_Valve_Ring.stl` × 1 — Anillo valvular con comisuras, bisagras, ranuras de mando, almohadillas de sensores y alojamiento Hall
- `CardioValAI_STL/CardioValAI_Leaflet_1.stl` × 1 — Valva 1 (semilunar simplificada, barril de bisagra y cola de mando)
- `CardioValAI_STL/CardioValAI_Leaflet_2.stl` × 1 — Valva 2 (semilunar simplificada, barril de bisagra y cola de mando)
- `CardioValAI_STL/CardioValAI_Leaflet_3.stl` × 1 — Valva 3 (semilunar simplificada, barril de bisagra y cola de mando)
- `CardioValAI_STL/CardioValAI_Link_Normal.stl` × 4 — Biela rígida (modo normal). 3 + 1 de repuesto
- `CardioValAI_STL/CardioValAI_Link_LostMotion.stl` × 2 — Biela con recorrido perdido (apertura restringida / asimétrica). 1 marca
- `CardioValAI_STL/CardioValAI_Link_LostMotion_IC.stl` × 1 — Biela corta con recorrido perdido (cierre incompleto 12°). 2 marcas
- `CardioValAI_STL/CardioValAI_Opening_Stop_84.stl` × 3 — Tope de seguridad (84°) — se usa en modo normal y cierre incompleto
- `CardioValAI_STL/CardioValAI_Opening_Stop_60.stl` × 1 — Tope intercambiable 60°
- `CardioValAI_STL/CardioValAI_Opening_Stop_45.stl` × 1 — Tope intercambiable 45°
- `CardioValAI_STL/CardioValAI_Actuator_Plate.stl` × 1 — Plato actuador (corredera) con bujes, orejetas y horquilla
- `CardioValAI_STL/CardioValAI_Pushrod.stl` × 1 — Empujador servo → plato
- `CardioValAI_STL/CardioValAI_Column.stl` × 3 — Columna guía y soporte del anillo
- `CardioValAI_STL/CardioValAI_Piezo_Mount.stl` × 1 — Soporte del disco piezoeléctrico (Ø15; adaptador para Ø12)
- `CardioValAI_STL/CardioValAI_Piezo_Cover.stl` × 1 — Tapa protectora del piezo (no lo presiona)
- `CardioValAI_STL/CardioValAI_Piezo_Adapter_12mm.stl` × 1 — Anillo adaptador para disco Ø12
- `CardioValAI_STL/CardioValAI_MEMS_Mount.stl` × 1 — Escuadra regulable y portaplaca del micrófono INMP441
- `CardioValAI_STL/CardioValAI_Servo_Mount.stl` × 1 — Soporte del MG90S con escuadras
- `CardioValAI_STL/CardioValAI_ESP32_Mount.stl` × 1 — Cuna del ESP32 DevKit (apoya en los extremos, pines libres)
- `CardioValAI_STL/CardioValAI_Angle_Scale.stl` × 1 — Transportador 0–90° para medir la valva 1 con cámara lateral
- `CardioValAI_STL/CardioValAI_Base.stl` × 1 — Base modular 200 × 180 mm
- `CardioValAI_STL/CardioValAI_Tolerance_Coupon.stl` × 1 — Probeta de holguras: ejes Ø2 y pilotos M2/M3
- `CardioValAI_STEP/` — las mismas piezas como sólidos B-rep editables (STEP), en el marco del ensamblaje.
- `CardioValAI_Assembly_Cerrada.step` — ensamblaje completo con todas las piezas y referencias en posición (válvula cerrada).
- `CardioValAI_Final.blend` — escena de Blender con el ensamblaje y la animación completa (10 segmentos marcados en la línea de tiempo).
- `CardioValAI_Animacion.mp4` — animación renderizada.
- `Referencia_NO_IMPRIMIR/` — modelos de referencia (servo, horn, ESP32, INMP441, piezo, ejes). **No imprimir.**
- `Documentacion/` — Guía de ensamblaje, Guía de impresión, Lista de materiales (MD y CSV), Medición del ángulo, Tabla cinemática (CSV) e Informe de validación.
- `CAD_parametrico/` — código fuente: `config.py` (todos los parámetros), piezas, cinemática, ensamblaje, verificación, documentos y animación.

## Regenerar después de cambiar medidas
```
pip install build123d trimesh manifold3d shapely rtree networkx bpy
python build_all.py      # STL + STEP + ensamblaje
python verify.py         # verificaciones (mallas, interferencias, holguras, montaje)
python make_docs.py      # guías e informe
python blender_anim.py --render   # .blend y cuadros de la animación
```
