# CardioVal AI — Guía de ensamblaje

Prototipo **académico y experimental**: no es un dispositivo médico, no es implantable y no se conecta a pacientes. El movimiento lo produce un servomotor; **no** hay presión ni circulación de líquido.

## Cómo funciona el mecanismo (un solo servo)
`MG90S → palanca de 8,0 mm (horn) → empujador → plato actuador (corredera vertical guiada por 3 columnas) → 3 bielas → cola de cada valva → 3 valvas`.
- Cada valva gira sobre un **eje de acero Ø2** que atraviesa el anillo en una cuerda a 20 mm del centro. Su «cola» sale por una ranura de la pared y recibe la biela.
- Al **bajar** el plato 10,29 mm, las tres valvas abren de 0° a 80°; al **subir**, cierran. El servo recorre ±40° respecto de la horizontal (comando ≈ 130° = cerrada, 50° = abierta).
- Las alteraciones se hacen con **módulos intercambiables** en una valva (biela + tope), sin cambiar el comando del servo y **sin que el servo empuje contra un tope** (ver «Módulos»).

## Herramientas
Destornillador allen 1,5 y 2,5 mm (o Phillips según tornillos), alicate de punta, broca manual 2,0 / 2,1 / 2,4 mm, lija 400, cortaalambre para la varilla Ø2, cianoacrilato, grasa PTFE.

## Orden de montaje
1. **Calibración de holguras.** Imprime la probeta y define los diámetros reales (ver Guía de impresión). Repasa con broca: agujeros del eje en el anillo (Ø2,1) y en valvas/bielas (Ø2,4).
2. **Columnas.** Atornilla las 3 columnas a la base con M3×10 desde abajo (cabezas en los rebajes).
3. **Plato actuador.** Lija y engrasa las columnas; desliza el plato por las 3 columnas (bujes hacia arriba). Debe bajar por su propio peso sin trabarse.
4. **Servo.** Antes de montar el horn, centra el servo (comando 90°). Monta el horn con el brazo **horizontal apuntando hacia el centro de la válvula** (+x). Fija el servo al `Servo_Mount` con 2× M2×8 en las orejas y el soporte a la base con 4× M3×10 **sobre arandelas de goma**.
5. **Empujador.** Extremo inferior al agujero del horn a 8 mm del eje (M2×6); extremo superior a la horquilla del plato (M2×14 + tuerca), pasando por el agujero central del plato.
6. **Valvas + bielas (en el banco).** Une cada biela normal a la cola de su valva con M2×8 (cabeza del lado de la biela; el tornillo rosca en la cola). Comprueba que la biela gira libre.
7. **Valvas en el anillo.** Coloca cada valva en el sector con su número grabado (1–3 en el anillo; 1–3 puntos en la valva), con la biela pasando hacia abajo por la ranura. Introduce el eje Ø2×56 **desde el exterior** por el agujero de la pared, atravesando el barril, hasta la pared opuesta. Fija el eje con una gota de cianoacrilato **solo en los extremos** (nunca en el barril). Gira cada valva a mano: 0°–90° sin roce.
8. **Topes.** Inserta un `Opening_Stop_84` desde abajo en cada ranura (cara inclinada hacia la cola) y fíjalo con M2×20 desde la cara superior del anillo (+ tuerca bajo la brida).
9. **Anillo sobre las columnas.** Retira el transportador `Angle_Scale` (solo va encajado). Con el servo en 50° (plato abajo), apoya el anillo en las columnas haciendo coincidir las comisuras con las columnas. Une cada biela a su orejeta del plato con M2×10 + tuerca (acceso lateral bajo el anillo). Fija el anillo con 3× M3×30 desde las comisuras.
10. **Piezoeléctrico.** Limpia el asiento del `Piezo_Mount`; pega el disco con cinta doble faz fina o un punto de cianoacrilato (reemplazable). Pasa los cables por el canal y fija con brida en las ranuras inferiores (alivio de tensión). Atornilla soporte + `Piezo_Cover` a la almohadilla de la valva 2 con 2× M2×16. La tapa **no toca** el disco. Hay otras dos almohadillas para comparar posiciones.
11. **Micrófono MEMS.** Desliza la placa INMP441 en la ranura del portaplaca (ventanas en ambas caras: el puerto queda libre esté arriba o abajo). Atornilla la escuadra a la almohadilla de la valva 1 con 2× M2×8; las ranuras permiten ±3 mm de altura. El micrófono **no toca piezas móviles** y está unido al anillo, lejos del servo.
12. **ESP32.** Atornilla la cuna a la base (2× M3×8 desde abajo). Apoya la placa en las repisas de los extremos (pines hacia abajo, libres) y sujétala con una brida por la ranura inferior.
13. **Cableado** (asignación propuesta; confirmar en el firmware):
    - Servo: señal → GPIO 18 (PWM 50 Hz); rojo → **+5 V de la fuente externa**; café → GND. **Unir la GND de la fuente con la GND del ESP32.** Condensador 470–1000 µF en la alimentación del servo.
    - INMP441: VDD → 3,3 V; GND; SCK → GPIO 26; WS → GPIO 25; SD → GPIO 33; L/R → GND.
    - Piezo: en paralelo con 1 MΩ; protección (zener 3,3 V o divisor) → GPIO 34 (ADC1). Cables trenzados y cortos.
    - ECG futuro: **solo** mediante un módulo aislado y alimentado por batería, preferentemente inalámbrico. **Nunca** conectar electrodos corporales a este circuito alimentado por USB.
    - Lleva los cables por las ranuras de bridas de la base, lejos del recorrido de las bielas y del plato.

## Ajustes mecánicos
- **Extremos del servo.** Ajusta en el firmware los ángulos de comando para que: plato arriba → valvas cerradas con ≈ 1 mm de separación visible entre bordes; plato abajo → 80° (mide con el transportador `Angle_Scale` o con las marcas ópticas).
- **Radio real del horn.** Si el agujero del horn no está a 8 mm, el recorrido necesario cambia:

| Radio del agujero del horn | Barrido de la palanca | Comando (cerrada → abierta) |
|---|---|---|
| 7 mm | ±47,3° | 137° → 43° |
| 8 mm | ±40,0° | 130° → 50° |
| 9 mm | ±34,8° | 125° → 55° |
| 10 mm | ±30,9° | 121° → 59° |

## Módulos (modos de ensayo)
| Modo | Valva 1 | Valva 2 | Valva 3 | Cómo funciona |
|---|---|---|---|---|
| Normal | Biela normal + tope 84 | Normal + tope 84 | Normal + tope 84 | Unión rígida: las tres valvas 0° → 80°. El tope 84 es de seguridad (no se toca). |
| Apertura restringida 60° | `Link_LostMotion` + `Opening_Stop_60` + resorte | Normal | Normal | El resorte abre la valva hasta el tope; el pasador del plato sigue bajando dentro de la ranura de la biela (recorrido perdido): **el servo nunca empuja contra el tope**. Al cerrar, el pasador vuelve a empujar la biela. |
| Apertura restringida 45° | `Link_LostMotion` + `Opening_Stop_45` + resorte | Normal | Normal | Igual, con tope de 45°. |
| Cierre incompleto | `Link_LostMotion_IC` + `Opening_Stop_84` + resorte | Normal | Normal | La biela es 1,40 mm más corta: con el plato arriba la valva queda en 12°. Al abrir llega al tope de 84° y la ranura absorbe el resto. |
| Asimétrico | `Link_LostMotion` + tope 60 + resorte | `Link_LostMotion` + tope 45 + resorte | Normal | Tres recorridos diferentes (60°, 45°, 80°). |
| Ritmo irregular | Normal | Normal | Normal | Se programa en el firmware (cambio de frecuencia/retardo del ciclo). |

**Resorte de los módulos:** se ata en el agujero Ø1,5 de la cola y baja por el canal del tope; se anuda (o engancha) bajo la brida. Tensión suave (≈ 0,3–0,6 N).

**Cambiar un módulo:** servo en 50° → retirar el tornillo biela–plato → empujar el eje Ø2 hacia afuera → levantar la valva con su biela → cambiar biela y/o tope → volver a montar.

## Pruebas iniciales (en este orden)
1. **Sin servo:** retira el tornillo del empujador y mueve el plato a mano: las tres valvas deben abrir y cerrar juntas, sin trabas.
2. **Prueba de control del servo (sin transmitir movimiento):** con el empujador desconectado, haz funcionar el servo con el ciclo normal y registra piezo y MEMS. Esto mide la vibración/sonido propios del servo para restarlos o compararlos.
3. **Ciclo lento:** 10 ciclos/min, luego 60–75 ciclos/min. Revisar ruidos de roce y temperatura del servo.
4. **Medición del ángulo real:** cámara superior (marcas ópticas) y cámara lateral alineada con el eje de la valva 1 frente al `Angle_Scale`.
5. **Modos alterados**, uno a la vez, comparando con el registro normal.
