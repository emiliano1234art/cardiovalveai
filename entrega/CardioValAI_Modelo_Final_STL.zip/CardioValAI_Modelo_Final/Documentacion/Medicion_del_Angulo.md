# CardioVal AI — Medición del ángulo real de las valvas

El ángulo **ordenado** al servo no es necesariamente el ángulo **real** de la valva (holguras, flexión, roce). El diseño deja dos caminos:

## Alternativa A — Óptica (incluida)
- **Marcas en cada valva:** dos hoyuelos Ø1,5 en la línea central, a 6 y 16 mm del eje. **Marca fiduciaria** grabada en el anillo junto a cada valva y números 1–3.
- **Cámara superior:** la distancia proyectada entre las marcas es d·cos θ → θ = arccos(d_medida / d_real). Sensibilidad baja cerca de 0° (usar la cámara lateral en ese rango); a 60–80° una incertidumbre de 0,2 mm equivale a ≈ 1°.
- **Cámara lateral + `Angle_Scale`:** el transportador (marcas cada 5°, largas cada 30°) se encaja en la ranura de la base, en el plano perpendicular al eje de la valva 1 y centrado a la altura del eje. Filmar con la cámara alineada con el eje (teleobjetivo para reducir paralaje).
- **Mide directamente:** el ángulo geométrico de la valva. **Precisión a evaluar:** ±1–3° (depende de la resolución, el paralaje y la calibración).

## Alternativa B — Sensor Hall (espacio reservado)
- Alojamiento Ø3,2 × 0,8 mm en la cara −y de cada cola para un imán Ø3 × 1 mm, y bolsillo vertical abierto arriba en la pared del anillo (junto a cada ranura) para un sensor Hall lineal (p. ej. DRV5055/SS49E en una placa pequeña).
- **Mide directamente:** la intensidad del campo del imán, que cambia con la posición de la cola; el ángulo se obtiene con una **curva de calibración** (Hall vs. ángulo medido ópticamente).
- **Precisión a evaluar:** depende de la calibración y de la temperatura; típicamente mejor resolución que la óptica pero menos exactitud absoluta sin calibrar.
