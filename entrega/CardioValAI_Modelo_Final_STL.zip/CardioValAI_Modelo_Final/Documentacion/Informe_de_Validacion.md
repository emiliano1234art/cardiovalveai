# CardioVal AI — Informe de validación (v1, 2026-10-21 18:19)

Este informe separa lo **verificado digitalmente** (ejecutado de verdad sobre los archivos entregados) de lo **pendiente de prueba física**.
Una verificación digital **no** aprueba un ensayo físico.

## 1. Verificaciones ejecutadas
### 1.1 Mallas STL de impresión  — ✔ todas correctas
Cerradas (watertight), orientación de caras coherente, malla «manifold» válida (manifold3d), **un solo cuerpo por archivo**, apoyadas en z = 0, en milímetros y dentro del volumen 220 × 220 × 250 mm.

| Pieza | Malla cerrada y válida | Cuerpos | Volumen (mm³) | Tamaño (mm) | Cabe | Voladizo (mm²) | Puentes (mm²) |
|---|---|---|---|---|---|---|---|
| Valve_Ring | ✔ | 1 | 27872,2 | 72,0 × 78,1 × 24,0 | ✔ | 0,0 | 171,1 |
| Leaflet_1 | ✔ | 1 | 1328,6 | 28,3 × 33,9 × 10,6 | ✔ | 64,6 | 59,2 |
| Leaflet_2 | ✔ | 1 | 1328,3 | 28,3 × 33,9 × 10,6 | ✔ | 64,6 | 59,2 |
| Leaflet_3 | ✔ | 1 | 1328,0 | 28,3 × 33,9 × 10,6 | ✔ | 64,6 | 59,2 |
| Link_Normal | ✔ | 1 | 525,7 | 6,0 × 32,0 × 3,0 | ✔ | 0,0 | 0,0 |
| Link_LostMotion | ✔ | 1 | 583,2 | 6,0 × 37,5 × 3,0 | ✔ | 0,0 | 0,0 |
| Link_LostMotion_IC | ✔ | 1 | 555,9 | 6,0 × 36,1 × 3,0 | ✔ | 0,0 | 0,0 |
| Opening_Stop_84 | ✔ | 1 | 197,4 | 7,8 × 11,0 × 4,4 | ✔ | 0,0 | 0,0 |
| Opening_Stop_60 | ✔ | 1 | 249,2 | 7,8 × 11,0 × 7,2 | ✔ | 0,0 | 0,0 |
| Opening_Stop_45 | ✔ | 1 | 289,8 | 7,8 × 11,0 × 8,3 | ✔ | 0,0 | 0,0 |
| Actuator_Plate | ✔ | 1 | 10830,1 | 66,6 × 69,5 × 13,0 | ✔ | 0,0 | 22,9 |
| Pushrod | ✔ | 1 | 550,7 | 5,6 × 35,6 × 3,0 | ✔ | 0,0 | 0,0 |
| Column | ✔ | 1 | 2790,6 | 8,0 × 8,0 × 58,1 | ✔ | 0,0 | 5,3 |
| Piezo_Mount | ✔ | 1 | 2372,2 | 22,0 × 30,0 × 4,0 | ✔ | 0,0 | 0,0 |
| Piezo_Cover | ✔ | 1 | 1729,0 | 22,0 × 30,0 × 3,4 | ✔ | 0,0 | 18,7 |
| Piezo_Adapter_12mm | ✔ | 1 | 36,4 | 15,2 × 15,2 × 0,6 | ✔ | 0,0 | 0,0 |
| MEMS_Mount | ✔ | 1 | 3634,6 | 36,0 × 30,0 × 17,7 | ✔ | 214,4 | 126,9 |
| Servo_Mount | ✔ | 1 | 5952,2 | 40,2 × 34,0 × 20,2 | ✔ | 0,0 | 104,8 |
| ESP32_Mount | ✔ | 1 | 11137,1 | 59,8 × 32,8 × 19,0 | ✔ | 0,0 | 193,8 |
| Angle_Scale | ✔ | 1 | 12941,6 | 92,7 × 70,0 × 2,0 | ✔ | 0,0 | 0,0 |
| Base | ✔ | 1 | 213438,8 | 200,0 × 180,0 × 6,0 | ✔ | 0,0 | 476,0 |
| Tolerance_Coupon | ✔ | 1 | 4798,6 | 60,0 × 14,0 × 6,0 | ✔ | 0,0 | 0,0 |

### 1.2 Cinemática (un solo servo, plato compartido)
Carrera del plato 10,29 mm · palanca 8,00 mm · biela normal 26,0 mm · biela IC 24,59 mm.
El ángulo de transmisión (biela–cola) se mantiene lejos de los puntos muertos (0°/180°): mínimo ≥ 40° en todos los modos.

| Modo | Valva 1 | Valva 2 | Valva 3 | Recorrido perdido usado (máx. 5,5 mm) | Transmisión mín. |
|---|---|---|---|---|---|
| Normal | 0,0° → 80,0° | 0,0° → 80,0° | 0,0° → 80,0° | 0,00 mm | 47,9° |
| Restringida 60 | 0,0° → 60,0° | 0,0° → 80,0° | 0,0° → 80,0° | 2,39 mm | 47,9° |
| Restringida 45 | 0,0° → 45,0° | 0,0° → 80,0° | 0,0° → 80,0° | 4,44 mm | 47,9° |
| Cierre Incompleto | 12,0° → 84,0° | 0,0° → 80,0° | 0,0° → 80,0° | 1,01 mm | 43,0° |
| Asimetrico | 0,0° → 60,0° | 0,0° → 45,0° | 0,0° → 80,0° | 4,44 mm | 47,9° |

La tabla completa (comando del servo → posición del plato → ángulo de cada valva) está en `Tabla_Cinematica.csv`.

### 1.3 Interferencias en todo el recorrido — ✔ 0 interferencias
Intersección booleana exacta (manifold3d) entre **todas** las piezas del ensamblaje (anillo, valvas, ejes, bielas, topes, plato, columnas, empujador, horn, servo, soportes, sensores, ESP32, base, transportador) en **125 poses** (25 posiciones del servo × 5 modos). Umbral: volumen > 0,05 mm³.


### 1.4 Holguras mínimas medidas (distancia punto–superficie, 9 posiciones × 5 modos)
| Par | Holgura mínima (mm) | Dónde |
|---|---|---|
| Leaflet_1 ↔ Stop_1 | 0,00 | restringida 60 · servo 60° |
| Link_1 ↔ Leaflet_1 | 0,30 | normal · servo 130° |
| Actuator_Plate ↔ Column_1 | 0,30 | asimetrico · servo 50° |
| Pushrod ↔ Servo_Horn_Reference | 0,30 | asimetrico · servo 50° |
| Leaflet_1 ↔ Leaflet_2 | 0,49 | asimetrico · servo 120° |
| Leaflet_2 ↔ Leaflet_3 | 0,49 | asimetrico · servo 120° |
| Pushrod ↔ Actuator_Plate | 0,50 | normal · servo 130° |
| Link_1 ↔ Valve_Ring | 0,60 | normal · servo 90° |
| Leaflet_1 ↔ Valve_Ring | 0,68 | asimetrico · servo 80° |
| Pushrod ↔ Servo_MG90S_Reference | 2,82 | normal · servo 120° |
| Link_1 ↔ Stop_1 | 3,89 | cierre incompleto · servo 50° |
| Leaflet_1 ↔ MEMS_Mount | 5,00 | cierre incompleto · servo 50° |

«Valva ↔ tope = 0» es el **contacto previsto** del tope en los modos restringidos.

### 1.5 Montaje (trayectorias de ejes, tornillos y herramientas)
| Verificación | Resultado |
|---|---|
| Eje Ø2 de la valva 1: inserción desde el exterior (camino libre) | ✔ |
| Tornillo M3 de la columna 1: acceso vertical desde arriba | ✔ |
| Tornillo M2 del tope 1: acceso vertical desde arriba | ✔ |
| Tornillo M2 de la almohadilla 1a: acceso radial | ✔ |
| Tornillo M2 de la almohadilla 1b: acceso radial | ✔ |
| Tornillo M2 cola–biela de la valva 1: agujeros alineados | ✔ |
| Tornillo M2 biela–plato de la valva 1: agujeros alineados | ✔ |
| Eje Ø2 de la valva 2: inserción desde el exterior (camino libre) | ✔ |
| Tornillo M3 de la columna 2: acceso vertical desde arriba | ✔ |
| Tornillo M2 del tope 2: acceso vertical desde arriba | ✔ |
| Tornillo M2 de la almohadilla 2a: acceso radial | ✔ |
| Tornillo M2 de la almohadilla 2b: acceso radial | ✔ |
| Tornillo M2 cola–biela de la valva 2: agujeros alineados | ✔ |
| Tornillo M2 biela–plato de la valva 2: agujeros alineados | ✔ |
| Eje Ø2 de la valva 3: inserción desde el exterior (camino libre) | ✔ |
| Tornillo M3 de la columna 3: acceso vertical desde arriba | ✔ |
| Tornillo M2 del tope 3: acceso vertical desde arriba | ✔ |
| Tornillo M2 de la almohadilla 3a: acceso radial | ✔ |
| Tornillo M2 de la almohadilla 3b: acceso radial | ✔ |
| Tornillo M2 cola–biela de la valva 3: agujeros alineados | ✔ |
| Tornillo M2 biela–plato de la valva 3: agujeros alineados | ✔ |
| Tornillo M2 biela–plato de la valva 1: acceso del destornillador (plato abajo; transportador retirado) | ✔ |
| Tornillo M2 biela–plato de la valva 2: acceso del destornillador (plato abajo; transportador retirado) | ✔ |
| Tornillo M2 biela–plato de la valva 3: acceso del destornillador (plato abajo; transportador retirado) | ✔ |
| Tornillo M2 horquilla–empujador: agujeros alineados | ✔ |
| Tornillo M2 oreja izq del servo: acceso con destornillador | ✔ |
| Tornillo M2 oreja der del servo: acceso con destornillador | ✔ |

### 1.6 Carga estimada del servo (cálculo, no medición)
Plato + bielas + empujador ≈ 16,6 g; fuerza estimada 1,75 N (peso, par de las valvas, roce supuesto μ = 0,35 y dos resortes de módulo) → par ≈ 0,143 kg·cm.
Par de bloqueo del MG90S según distribuidores: 1,8 kg·cm (**no verificado**). Margen ≈ ×12,6. El valor real depende del roce de los bujes impresos: medir la corriente del servo en la prueba inicial.

## 2. Cambios respecto de los parámetros iniciales (justificación)
- **Valvas planas «semilunares simplificadas»:** cada valva gira sobre un eje recto (cuerda a 20 mm del centro); su contorno se calculó para que, **con el espesor incluido**, no toque la pared en todo el recorrido hasta 86° (holgura de diseño 1,0 mm) y deje 1,0 mm entre bordes al cerrar. Una valva curva real necesitaría flexión del material.
- **Mando por «cola»:** la cola de cada valva atraviesa una ranura de la pared y forma un mecanismo biela–manivela con el plato. Ángulo inicial de la cola 40° sobre la horizontal: el recorrido de ±40° alrededor de la horizontal evita puntos muertos.
- **Comisuras de 8 mm sobre el anillo** (altura total 24 mm) para el aspecto de raíz aórtica y para alojar los tornillos M3 de las columnas.
- **Alteraciones con recorrido perdido + resorte** en lugar de topes simples: con topes solos el servo empujaría contra ellos (bloqueo).
- **Tope de seguridad a 84°** (no 80°) en modo normal: la unión rígida ya limita a 80°; un tope exacto en 80° forzaría el servo por tolerancias.
- **Base 200 × 180 mm en una pieza**: cabe en camas de 220 × 220 mm; no fue necesario dividirla.

## 3. Pendiente de prueba física (NO verificado)
- Tolerancias reales de impresión (agujeros, ejes, bujes): usar la probeta.
- Dimensiones reales del MG90S, del horn (radio del agujero), del INMP441 y del ESP32 comprados.
- Roce y posible atascamiento del plato en las columnas impresas; repetibilidad del ciclo.
- Par real del servo, temperatura y consumo en ciclos largos; durabilidad y desgaste de bisagras, bielas y bujes.
- Fuerza real de los resortes y comportamiento de los módulos de recorrido perdido.
- Calidad del acoplamiento del piezo al anillo y separación acústica del MEMS respecto del servo.
- Exactitud de la medición del ángulo (óptica y Hall): requiere calibración experimental.
- Resistencia mecánica: **no** se realizó análisis de esfuerzos ni de fatiga (la simulación es cinemática).
