# CardioValveAI v3.1 — fijaciones impresas (STL)

Archivos en **milímetros**, ya orientados para la cama. Material: **PETG**.
Fuente: `hardware/cad/fasteners.py` y `parts.py` (revisión v3.1). El resto de las piezas está en el ZIP completo de la v3.1.

## Qué imprimir y cuántas

| Archivo | Imprimir | Uso |
|---|---|---|
| `CardioValveAI_v3.1_Thread_Coupon.stl` | 1 | **Primero.** Probeta de roscas M6 (1, 2 y 3 muescas = holgura 0,10 / 0,20 / 0,30 mm) |
| `CardioValveAI_v3.1_Tolerance_Coupon.stl` | 1 | **Primero.** Probeta de agujeros (fila 2 = ajuste a presión sobre latón Ø2) |
| `CardioValveAI_v3.1_Bolt_M6x8.stl` | 9 | 4 soporte del servo · 2 bandeja · 2 soporte del micrófono · 1 repuesto |
| `CardioValveAI_v3.1_Knurled_Nut_M6.stl` | 4 | 3 sobre las columnas (anillo) · 1 repuesto |
| `CardioValveAI_v3.1_Pin_Head.stl` | 10 | Cabeza de los pasadores de latón (8 + 2 repuesto) |
| `CardioValveAI_v3.1_Push_Nut.stl` | 10 | Tuerca a presión de los pasadores de latón (8 + 2 repuesto) |
| `CardioValveAI_v3.1_Turn_Button.stl` | 5 | Pestillos que sujetan la placa electrónica (4 + 1 repuesto) |
| `CardioValveAI_v3.1_Column.stl` | 3 | Columnas con rosca M6 en ambos extremos |

**Pasadores de latón Ø2 (no se imprimen; se cortan de la varilla):** 3 × 18,1 mm (topes) · 3 × 8,6 mm (bielas) · 1 × 11,6 mm (horquilla) · 1 × 14 mm (pivote del micrófono).

## Configuración de impresión (supuesta; ajustar a su impresora)
- Boquilla 0,4 mm · capa **0,12 mm** · relleno **100 %** · **4 perímetros** · PETG 230–245 °C.
- **Sin soportes.** El programa de verificación marca «soporte» en las piezas con rosca por los flancos de la rosca. Son voladizos de menos de 0,7 mm y normalmente se
  imprimen sin soporte; un soporte dentro de la rosca la arruina. Se confirma con la probeta.
- Pernos con la cabeza en la cama; columnas verticales con el espárrago inferior en la cama (usar borde/brim: miden 94 mm de alto y solo 8 mm de diámetro).
- Cabezas y tuercas a presión son muy chicas (≈ 4 mm): imprimir las 10 juntas en una misma tanda, a velocidad baja, para que cada capa tenga tiempo de enfriar.

## Orden
1. Imprimir `Thread_Coupon` + 1 `Bolt_M6x8`. Elegir la rosca en la que el perno entra **a mano y sin juego visible**.
   Poner en `THREAD_COMP` (`config.py`) el valor que corresponde y regenerar: 1 muesca → 0,125 · 2 muescas → 0,175 · 3 muescas → 0,225 (hoy está en 0,15).
2. Imprimir `Tolerance_Coupon`, fila 2: el agujero donde el latón Ø2 entra a presión firme define `PIN_PRESS_HOLE` (hoy 1,95 mm).
3. Recién entonces imprimir el resto.

## Uso
- Las roscas M6 se aprietan **solo con los dedos**: una llave o un destornillador las barre.
- Revisar el apriete a las 24 h (el PETG se asienta).
- Las cabezas se fijan al latón con una gota de cianoacrilato. Las tuercas a presión se empujan con un alicate y se sacan haciendo palanca; si quedan flojas, usar una nueva.

Nada de esto se imprimió ni se probó todavía: las medidas se verificaron en el CAD (mallas cerradas, sin choques en el ensamblaje), no en piezas reales.
