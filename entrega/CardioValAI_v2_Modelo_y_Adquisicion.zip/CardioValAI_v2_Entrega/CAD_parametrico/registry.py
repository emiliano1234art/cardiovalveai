"""Catálogo de piezas: constructor, cantidad, orientación de impresión y notas de fabricación."""
from __future__ import annotations
import math
from dataclasses import dataclass, field
import numpy as np
import config as C
import kinematics as K
import parts as P
import assembly as A

def Rx(deg):
    c, s = math.cos(math.radians(deg)), math.sin(math.radians(deg))
    m = np.eye(4); m[1, 1], m[1, 2], m[2, 1], m[2, 2] = c, -s, s, c; return m

@dataclass
class Item:
    name: str                 # nombre de archivo (sin prefijo)
    build: callable
    qty: int
    printable: bool
    print_tf: np.ndarray = field(default_factory=lambda: np.eye(4))
    role: str = ''
    infill: str = '40 %'
    walls: int = 3
    layer: float = 0.2
    notes: str = ''
    instances: tuple = ()     # nombres de instancia en el ensamblaje

ITEMS: list[Item] = [
    Item('Valve_Ring', P.valve_ring, 1, True, np.eye(4), 'Anillo valvular con comisuras, bisagras, ranuras de mando, almohadillas con insertos M2 y 3 bolsillos para Hall TO-92',
         '50 %', 4, 0.2, 'Repasar los agujeros horizontales de Ø2,1 con broca de 2,0–2,1 mm si quedan ovalados. Insertos M2 en las almohadillas con soldador a 220 °C.', ('Valve_Ring',)),
    *[Item(f'Leaflet_{i+1}', (lambda i=i: P.leaflet(i)), 1, True, A.T(0, 0, -P.PLATE_Z0), f'Valva {i+1} (semilunar simplificada, barril de bisagra y cola de mando)',
           '100 %', 3, 0.12, 'Imprimir con la cara inferior plana en la cama. Soporte mínimo (árbol) bajo la cola inclinada 40°. Imán Ø4×2 en la cara −y de la cola (polaridad marcada).', (f'Leaflet_{i+1}',)) for i in range(3)],
    Item('Link_Normal', lambda: P.link(C.LINK_L, False), 4, True, Rx(90), 'Biela rígida (modo normal). 3 + 1 de repuesto', '100 %', 3, 0.2, 'Plana. Sin marcas.', ('Link_1', 'Link_2', 'Link_3')),
    Item('Link_LostMotion', lambda: P.link(C.LINK_L, True), 2, True, Rx(90), 'Biela con recorrido perdido (apertura restringida / asimétrica). 1 marca', '100 %', 3, 0.2, 'Plana.'),
    Item('Link_LostMotion_IC', lambda: P.link(K.MODULES['IC'].L, True), 1, True, Rx(90), f'Biela corta con recorrido perdido (cierre incompleto {C.IC_RESIDUAL:.0f}°). 2 marcas', '100 %', 3, 0.2, 'Plana.'),
    Item('Opening_Stop_84', lambda: P.opening_stop(84.0), 3, True, A.T(0, 0, 2.5), 'Tope de seguridad (84°) — se usa en modo normal y cierre incompleto', '100 %', 3, 0.2, 'Brida en la cama.', ('Stop_1', 'Stop_2', 'Stop_3')),
    Item('Opening_Stop_60', lambda: P.opening_stop(60.0), 1, True, A.T(0, 0, 2.5), 'Tope intercambiable 60°', '100 %', 3, 0.2, 'Brida en la cama.'),
    Item('Opening_Stop_45', lambda: P.opening_stop(45.0), 1, True, A.T(0, 0, 2.5), 'Tope intercambiable 45°', '100 %', 3, 0.2, 'Brida en la cama.'),
    Item('Actuator_Plate', P.actuator_plate, 1, True, np.eye(4), 'Plato actuador (corredera) con bujes, orejetas y horquilla', '40 %', 4, 0.2,
         'Repasar los bujes Ø8,6 con lija y lubricar con grasa de PTFE.', ('Actuator_Plate',)),
    Item('Pushrod', P.pushrod, 1, True, Rx(90), 'Empujador servo → plato', '100 %', 3, 0.2, 'Plano.', ('Pushrod',)),
    Item('Column', lambda: P.column(A.COLUMN_H), 3, True, np.eye(4), 'Columna guía y soporte del anillo (insertos M3 en ambos extremos)', '40 %', 4, 0.2,
         'Vertical. Lijar la superficie de deslizamiento (grano 400) y lubricar.', ('Column_1', 'Column_2', 'Column_3')),
    Item('Column_Spacer', P.column_spacer, 2, True, A.T(0, 0, C.SPACER_T), 'Arandela de 2 mm entre columna y anillo (columnas 2 y 3)', '100 %', 3, 0.2, '', ('Column_Spacer_2', 'Column_Spacer_3')),
    Item('H0_Holder', P.hall0_holder, 1, True, A.T(0, 0, C.SPACER_T), 'Soporte del sensor H0 (DRV5055A2) sobre el imán del plato; reemplaza la arandela de la columna 1', '100 %', 4, 0.2,
         'Arandela en la cama, pata hacia arriba.', ('H0_Holder',)),
    Item('Cable_Clip', P.cable_clip, 3, True, np.eye(4), 'Pinza de cables a presión en cada columna (bajo el recorrido del plato)', '100 %', 3, 0.2, '', ('Cable_Clip_1', 'Cable_Clip_2', 'Cable_Clip_3')),
    Item('Piezo_Mount', P.piezo_mount, 2, True, A.T(0, 0, -C.PAD_FACE_R) @ np.array([[0, 0, -1, 0], [0, 1, 0, 0], [1, 0, 0, 0], [0, 0, 0, 1]], float),
         'Soporte del disco piezoeléctrico (Ø15; adaptador para Ø12). P1 en el anillo, P2 en el soporte del servo', '100 %', 4, 0.2, 'Cara de contacto en la cama.', ('Piezo_Mount', 'Piezo_Mount_P2')),
    Item('Piezo_Cover', P.piezo_cover, 2, True, A.T(0, 0, C.PAD_FACE_R + 4.0 + 3.4) @ np.array([[0, 0, 1, 0], [0, 1, 0, 0], [-1, 0, 0, 0], [0, 0, 0, 1]], float),
         'Tapa protectora del piezo (no lo presiona)', '40 %', 3, 0.2, 'Cara exterior en la cama.', ('Piezo_Cover', 'Piezo_Cover_P2')),
    Item('Piezo_Adapter_12mm', P.piezo_adapter_12, 1, True, A.T(0, 0, -(C.PAD_FACE_R + 4.0 - 0.8)) @ np.array([[0, 0, -1, 0], [0, 1, 0, 0], [1, 0, 0, 0], [0, 0, 0, 1]], float),
         'Anillo adaptador para disco Ø12', '100 %', 2, 0.15, 'Solo si el disco comprado es de 12 mm.'),
    Item('MEMS_Mount', P.mems_mount, 1, True, A.T(0, 0, C.PAD_FACE_R + 3.5) @ np.array([[0, 0, 1, 0], [0, 1, 0, 0], [-1, 0, 0, 0], [0, 0, 0, 1]], float),
         'ALTERNATIVA: escuadra y portaplaca del INMP441 sobre el anillo (comparar con MEMS_Stand)', '40 %', 3, 0.2, 'Apoyar la cara exterior de la escuadra en la cama; soportes bajo el portaplaca.', ('MEMS_Mount',)),
    Item('MEMS_Stand', P.mems_stand, 1, True, np.eye(4), 'Soporte independiente del micrófono M1 (configuración inicial recomendada): ranura radial ±8 mm y pivote de inclinación',
         '40 %', 4, 0.2, 'Pie en la cama.', ('MEMS_Stand',)),
    Item('MEMS_Stand_Holder', P.stand_holder, 1, True, A.T(0, 0, 0) @ np.array([[0, 0, 1, 0], [0, 1, 0, 0], [-1, 0, 0, 0], [0, 0, 0, 1]], float) ,
         'Portaplaca del INMP441 con lengüeta de pivote', '40 %', 3, 0.2, 'Cara del marco en la cama.', ('MEMS_Stand_Holder',)),
    Item('Servo_Mount', lambda: P.servo_mount(A.ZS), 1, True, A.T(0, 0, -C.BASE_T), 'Soporte del MG90S con escuadras y almohadilla P2', '50 %', 4, 0.2,
         'Fijar a la base sobre arandelas de goma (antivibración). Insertos M2 en la almohadilla P2.', ('Servo_Mount',)),
    Item('Electronics_Tray', P.electronics_tray, 1, True, np.eye(4), 'Bandeja de la placa perforada 70×90 (ESP32 en zócalos hembra, antena libre, USB accesible)', '30 %', 3, 0.2,
         'Insertos M3 en los 4 postes.', ('Electronics_Tray',)),
    Item('Tray_Clamp', P.tray_clamp, 2, True, Rx(180), 'Barra de sujeción de la placa perforada (sin perforar ni flexionar)',
         '100 %', 3, 0.2, 'Cara superior en la cama.', ('Tray_Clamp_L', 'Tray_Clamp_R')),
    Item('Angle_Scale', lambda: P.angle_scale(A.Z_RING + C.Z_HINGE - C.BASE_T), 1, True, A.T(0, 0, 0) @ np.array([[0, 0, -1, 0], [0, 1, 0, 0], [1, 0, 0, 0], [0, 0, 0, 1]], float),
         'Transportador 0–90° para medir la valva 1 con cámara lateral', '30 %', 3, 0.2, 'Plano; marcas hacia arriba.', ('Angle_Scale',)),
    Item('Base', lambda: P.base([A.column_xy(i) for i in range(3)], A.servo_mount_holes(), A.TRAY_XY, A.SCALE_XY, A.stand_insert_xy(), A.zip_points(), A.base_labels()), 1, True, np.eye(4),
         'Base modular 200 × 180 mm con insertos M3 y ranuras para bridas', '20 %', 4, 0.2, 'Cabe en camas ≥ 220 × 220 mm. Usar borde (brim) de 5 mm para evitar alabeo.', ('Base',)),
    Item('Tolerance_Coupon', P.tolerance_coupon, 1, True, np.eye(4), 'Probeta v2: ejes libres y a presión, pilotos, insertos e imanes', '100 %', 3, 0.2,
         'Imprimir primero: elegir los diámetros reales que ajustan con los ejes, insertos e imanes comprados.'),
    # referencias (NO imprimir)
    Item('Servo_MG90S_Reference', lambda: P.ref_servo(A.ZS), 1, False, instances=('Servo_MG90S_Reference',), role='Modelo dimensional de referencia del MG90S (VERIFICAR con el servo comprado)'),
    Item('Servo_Horn_Reference', P.ref_horn, 1, False, instances=('Servo_Horn_Reference',), role='Horn de un brazo (referencia; se usa el original del servo)'),
    Item('Perfboard_ESP32_Reference', P.ref_perfboard, 1, False, instances=('Perfboard_ESP32_Reference',), role='Placa perforada 70×90 + zócalos + ESP32 DevKit (referencia NO DEFINITIVA: medidas del ESP32 por confirmar)'),
    Item('MEMS_Board_Reference', P.ref_mems_board, 1, False, instances=('MEMS_Board_Reference', 'MEMS_Board_Reference_Alt'), role='Placa INMP441 (referencia, VERIFICAR medidas); _Alt = posición alternativa en el anillo'),
    Item('Piezo_Disc_Reference', P.ref_piezo, 2, False, instances=('Piezo_Disc_Reference', 'Piezo_Disc_Reference_P2'), role='Disco piezoeléctrico Ø15 (referencia) P1 y P2'),
    Item('Hinge_Pin_Reference', P.ref_pin, 3, False, instances=('Pin_1', 'Pin_2', 'Pin_3'), role='Eje de LATÓN Ø2 × 56 mm (no magnético)'),
    Item('Tail_Pin_Reference', P.ref_tail_pin, 3, False, instances=('Tail_Pin_1', 'Tail_Pin_2', 'Tail_Pin_3'), role='Pasador de latón Ø2 × 9 cola–biela (a presión en la cola)'),
    Item('Magnet_Leaf_Reference', P.ref_magnet_leaf, 3, False, instances=('Magnet_1', 'Magnet_2', 'Magnet_3'), role='Imán N42 Ø4×2 axial (cola de cada valva)'),
    Item('Magnet_Plate_Reference', P.ref_magnet_plate, 1, False, instances=('Plate_Magnet',), role='Imán N42 Ø3×2 axial (plato, H0)'),
    Item('Hall_Sensors_Reference', P.ref_hall_ring, 1, False, instances=('Hall_Sensors_Reference',), role='3 × DRV5055A1QLPG (TO-92) en el anillo: H1–H3'),
    Item('Hall0_Reference', P.ref_hall0, 1, False, instances=('Hall0_Reference',), role='DRV5055A2QLPG (TO-92) del plato: H0'),
    Item('Plate_Fasteners_Reference', P.ref_plate_fasteners, 1, False, instances=('Plate_Fasteners_Reference',), role='Tornillería que se mueve con el plato (M2 + tuercas)'),
    Item('Ring_Fasteners_Reference', P.ref_ring_fasteners, 1, False, instances=('Ring_Fasteners_Reference',), role='Tornillos de los topes (latón) y de las comisuras'),
    Item('Cable_Routes_Reference', lambda: P.ref_cable_all(), 1, False, instances=('Cable_Routes_Reference',), role='Recorridos de cables (haces Ø3): señales por el sur, servo por el norte'),
]

def by_name(n):
    return next(i for i in ITEMS if i.name == n)
