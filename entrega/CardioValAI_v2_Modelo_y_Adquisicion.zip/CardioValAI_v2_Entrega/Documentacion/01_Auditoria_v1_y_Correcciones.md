# 01 · Auditoría de la entrega v1 y correcciones de la v2

> CardioVal AI · revisión **v2** · prototipo académico de banco **sin fluido**. No es un dispositivo médico ni de diagnóstico.
> **[CÁLCULO]** verificado por cálculo · **[SIM]** inspección o simulación geométrica · **[SW]** compilado o probado en software · **[FÍSICO]** pendiente de ensayo físico

**Qué se auditó:** `entrega/CardioValAI_Modelo_Final_STL.zip` (v1, commit 519c9ac): CAD paramétrico (Python/build123d), 23 STL, STEP de piezas y
ensamblaje, archivo Blender, animación, guías, lista de materiales, informe de validación y el firmware `CardioValAI_ServoTest.ino`.
**La v1 se conserva sin cambios.** Todo lo nuevo lleva el prefijo `CardioValAI_v2` y sale en `hardware/out_v2/`.

## 1. Problemas que impedían MEDIR apertura y cierre (prioridad máxima)

| # | Problema en v1 | Evidencia | Corrección en v2 | Estado |
|---|---|---|---|---|
| 1 | **No había medición de la posición real de las valvas.** Solo se conocía el ángulo ORDENADO al servo. | El firmware solo mueve el servo; no hay sensor de posición. | Imán N42 Ø4×2 en la cola de cada valva + sensor Hall lineal DRV5055A1 (TO-92) en la pared del anillo (H1–H3) y un Hall DRV5055A2 sobre el plato (H0). Posición elegida con un modelo de dipolos (`sensing.py`). | Diseño [CÁLCULO] [SIM]; respuesta real [FÍSICO] |
| 2 | **Los eventos de apertura y cierre no producen contacto mecánico** en modo normal: al cerrar quedan 1,0 mm entre bordes y el tope de 84° no se toca a 80°. | Geometría del CAD (holgura de coaptación) y tabla cinemática. | Se declara explícitamente: piezo y micrófono probablemente **no** marcan inicio/fin de apertura ni de cierre; registran sobre todo el ruido del servo. Los eventos se miden con los Hall; piezo y audio quedan como señales complementarias a evaluar (ensayos 5, 6 y 11). | [CÁLCULO]; confirmación [FÍSICO] |
| 3 | Alojamiento de imán de v1 con **0,8 mm de profundidad para un imán de 1 mm** y bolsillo Hall sin posición calculada. | `parts.py` v1. | Alojamiento Ø4,2 × 2,2 mm; bolsillo TO-92 en (26,8; -8,0; 13,5) (marco de la valva) con piso que fija la altura, canal de patas y bajada exterior de cables. | [SIM] |
| 4 | **Ejes de acero y tornillo de acero en la cola** a pocos mm del imán: deforman el campo. | BOM v1: eje de acero Ø2; cola–biela M2 autorroscante. | Ejes de **latón** Ø2 (o inox 316); pasador de latón Ø2 × 9 a presión en la cola; tornillo de los topes de latón. | [CÁLCULO] |
| 5 | Firmware sin adquisición, con `delay()` bloqueante; la guía decía «registra piezo y MEMS». | `CardioValAI_ServoTest.ino`. | Firmware ESP-IDF nuevo: ADC continuo (DMA), I2S, servo no bloqueante, protocolo binario con CRC, contadores de pérdidas, paradas controladas. **Compila (ESP-IDF v5.4.1); no se probó en hardware.** | [SW]; funcionamiento [FÍSICO] |
| 6 | Protección del piezo descripta como «1 MΩ + zener» (insuficiente) y conexión casi directa al ADC. | Guía v1. | Acondicionamiento completo por canal: descarga, limitación de corriente, recorte con Schottky a ambos rieles, polarización, amplificación seleccionable y antialias de 2.º orden (Hoja 2). | [CÁLCULO]; [FÍSICO] |

## 2. Inconsistencias de montaje y tornillería

| # | Problema en v1 | Corrección v2 | Estado |
|---|---|---|---|
| 7 | Tope: piloto de 1,8 mm (autorroscante) pero la guía pedía «M2×20 + tuerca». | Agujero de paso Ø2,4 + **tuerca M2 atrapada** en la brida; tornillo de latón desde arriba (se cambia sin desarmar). | [SIM] |
| 8 | BOM: «M2×8 DIN 912 autorroscante» (un DIN 912 es métrico, no autorroscante). | Tabla de uniones con el tipo correcto por unión (métrico + tuerca, inserto termofijado o autorroscante solo donde corresponde). | [CÁLCULO] |
| 9 | Columnas y almohadillas con rosca directa en PETG para piezas que se desmontan a menudo. | **Insertos de latón** M3 en columnas y base, M2 en almohadillas. | [SIM]; ajuste de los agujeros [FÍSICO] (probeta) |
| 10 | Radio del horn fijado en 8 mm sin poder cambiarlo. | El dato de entrada es el radio medido; el barrido se calcula (tabla en 04). | [CÁLCULO] |
| 11 | Cuna del ESP32 para 55×28 mm sin confirmar; perforaba/apoyaba la placa sin retención clara ni zona de antena. | Bandeja para placa perforada 70×90 con el ESP32 en zócalos hembra (no se perfora ni flexiona), barras de sujeción, antena fuera del borde, USB/EN/BOOT accesibles. **No definitiva** hasta recibir medidas. | [SIM]; medidas [FÍSICO] |
| 12 | Cables sin recorrido definido; riesgo de roce con el plato. | Recorridos modelados (haces Ø2–3) incluidos en el barrido de interferencias; pinzas en columnas, canales en el anillo, ranuras para bridas. | [SIM] |
| 13 | Tornillería no incluida en el control de interferencias. | Tornillos y tuercas del plato, topes y comisuras modelados y verificados en todo el recorrido. | [SIM] |
| 14 | Archivo `.blend` guardado con Blender 5.0 (no abre en 4.5 LTS). | `.blend` v2 guardado con **Blender 4.5.15 LTS** (bpy 4.5). | [SW] |
| 15 | Micrófono solo en una escuadra sobre el anillo (transmisión estructural, sin ajuste de distancia). | Soporte independiente `MEMS_Stand` (ranura radial ±8 mm, pivote) + se conserva la escuadra como alternativa para comparar. | [SIM]; elección [FÍSICO] |
| 16 | P2 sin alojamiento definido. | Almohadilla P2 en el soporte del servo (misma interfaz de 22 mm que P1). | [SIM] |

## 3. Riesgos mecánicos identificados (no resueltos del todo sin ensayo)

- **Efecto cajón del plato:** si una sola valva se traba, la resultante se va a 27,1 mm del eje y supera el límite en seco
  (17,1 mm con μ = 0,35). Con grasa PTFE el límite sube a 40,0 mm. Mitigación: lubricar; detección de atasco por H0 en el firmware. [CÁLCULO] / [FÍSICO]
- **Gomas antivibración del servo:** aíslan solo por encima de ≈ 1,4·fn; estimación fn ≈ 250 Hz (no medida). Por debajo pueden amplificar. [CÁLCULO aproximado] / [FÍSICO]
- **Holgura de bujes (0,3 mm radial) y agujeros de PETG:** dependen de la impresora → probeta. [FÍSICO]
- **Servo MG90S:** par de bloqueo 1,8 kg·cm es dato de distribuidores, no verificado; margen calculado ×12,6 sobre una carga estimada. [CÁLCULO] / [FÍSICO]

## 4. Resultado de las verificaciones digitales v2 (ejecutadas sobre los archivos entregados)

- Barrido de interferencias: **125 poses** (25 posiciones × 5 modos), intersección booleana exacta: **0 interferencias**. [SIM]
- Contactos de diseño (volumen < 0,05 mm³): Actuator_Plate × Plate_Fasteners_Reference, Link_1 × Plate_Fasteners_Reference, Link_2 × Plate_Fasteners_Reference, Link_3 × Plate_Fasteners_Reference.
- Holgura mínima medida entre pares móviles: ver `Informe_de_Validacion_v2.md` (el 0,0 corresponde al apoyo previsto de la valva sobre su tope en los modos con tope).
- Comprobaciones de montaje: 46 de 46 correctas. [SIM]
- Mallas STL: cerradas, orientación coherente, un cuerpo, apoyadas en z = 0, dentro de una cama 220 × 220. [SW]
- Firmware: compila sin advertencias en el código propio con ESP-IDF v5.4.1. [SW]
- Herramientas de computadora: prueba de extremo a extremo con datos **sintéticos** del emulador (protocolo, CRC, detección de fallas inyectadas). [SW]

**Nada de lo anterior demuestra que el prototipo físico funcione.** Ver `10_Pendientes_Fisicos.md`.
