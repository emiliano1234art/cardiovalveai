# 08 · Método de medición, calibración de la posición y criterios de inconsistencia

> CardioVal AI · revisión **v2** · prototipo académico de banco **sin fluido**. No es un dispositivo médico ni de diagnóstico.
> **[CÁLCULO]** verificado por cálculo · **[SIM]** inspección o simulación geométrica · **[SW]** compilado o probado en software · **[FÍSICO]** pendiente de ensayo físico

## 1. Qué se mide y qué se estima
- **Medido:** ángulo de cada valva (Hall H1–H3 calibrados contra transportador/video) y carrera del plato (H0). Tiempos en µs del reloj del ESP32.
- **Ordenado (no es posición):** ángulo de comando del servo; se grafica aparte con línea discontinua.
- **Estimado / complementario:** vibración (P1, P2) y sonido (M1): no se usan para marcar eventos.

## 2. Calibración de la posición de las valvas
1. Montar el `Angle_Scale` y una cámara lateral alineada con el eje de la valva 1 (teleobjetivo o lejos, para reducir el paralaje); cámara superior para las valvas 2 y 3
   (hoyuelos de la línea central y marca fiduciaria).
2. `python cvai_calibrate.py guiado --port …`: el servo va a 17 posiciones fijas (130° → 50°). En cada una se promedian 0,5 s de H0–H3 y se escriben los ángulos medidos.
3. `python cvai_calibrate.py ajustar calib_puntos.csv`: curva PCHIP monótona por valva; informa el error de validación cruzada. **Aceptar si ≤ 1° (propuesto).**
4. Verificación diaria: posición cerrada y abierta; si difiere > 2° de la calibración, recalibrar. Recalibrar siempre tras desmontar imanes o sensores.
5. H0: se relaciona con el comando estático (linealiza la carrera del plato); se usa para detectar atascos, no como ángulo de valva.

## 3. Eventos por ciclo (cvai_analyze.py)
- base (cerrada) = mediana 20–200 ms antes del comando de apertura; meseta = mediana del 60 % final de la espera abierta; residual = mediana del 40 % final de la espera cerrada.
- S_ref = mediana de (meseta − base) en la sesión.
- **Inicio de apertura:** cruce de base + 10 % S_ref; **fin:** cruce de base + 90 % (meseta − base). **Cierre:** simétrico. Duración = fin − inicio; retardo = inicio − comando.
- Interpolación lineal entre muestras (1 ms).

## 4. Criterios propuestos (a ajustar con los datos del ensayo 12)
| Indicador | Criterio |
|---|---|
| Apertura incompleta | meseta − base < 90 % S_ref, o (calibrado) meseta < ángulo esperado del modo − 5° |
| Cierre incompleto | residual − base de la sesión > máx(5 % S_ref, 2°) |
| Asimetría | (calibrado) diferencia de mesetas entre valvas, descontando la del modo declarado, > 5° |
| Atasco | carrera del plato < 90 % de la de referencia, o parada del firmware por atasco/sobrecorriente |
| Variación ciclo a ciclo | z robusto > 3,5 (z = (x − mediana)/(1,4826·MAD)), con pisos de 5 ms y 1° |
| Datos no confiables | saturación, desborde del ADC/I2S, tramas descartadas o saltos de secuencia dentro del ciclo |
| **Ciclos equivalentes** | ninguno de los anteriores |

## 5. Comparación de señales complementarias
Por ciclo: contraste (dB) en ±30 ms del fin de apertura/cierre medido respecto de la espera quieta y de la mitad del recorrido, tiempo del pico respecto del evento (mediana e IQR),
energía en 20–200 / 200–1000 / 1000–3000 Hz. Se considera que una señal **ayuda** a identificar el evento solo si, en varias sesiones, el contraste respecto de la mitad del
recorrido es ≥ 6 dB y el IQR del tiempo del pico ≤ 10 ms (criterios propuestos). Si no, se informa que no se distingue del ruido del servo.

**Importante:** detectar cambios en este banco **no** equivale a diagnosticar una prótesis implantada.
