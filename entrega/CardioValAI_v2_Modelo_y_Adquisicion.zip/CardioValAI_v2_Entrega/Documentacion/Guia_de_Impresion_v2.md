# Guía de impresión v2

> CardioVal AI · revisión **v2** · prototipo académico de banco **sin fluido**. No es un dispositivo médico ni de diagnóstico.
> **[CÁLCULO]** verificado por cálculo · **[SIM]** inspección o simulación geométrica · **[SW]** compilado o probado en software · **[FÍSICO]** pendiente de ensayo físico

Material: **PETG** (piezas móviles y estructurales). Boquilla 0,4 mm. Unidades de los STL: **milímetros**; ya están orientados para la cama.
**Primero imprimir `CardioValAI_v2_Tolerance_Coupon.stl`** (5 filas × 6 agujeros, número de fila grabado):
1 eje Ø2 libre (2,0–2,5) · 2 eje Ø2 a presión (1,80–2,05) · 3 pilotos M2/M3 (1,6–1,9 / 2,4 / 2,6) · 4 insertos M2 (3,1–3,3) y M3 (4,0–4,2) · 5 imanes Ø4 (4,1–4,3) y Ø3 (3,1–3,3).
Elegir los diámetros que funcionan con lo comprado y actualizar en `config.py`: `PIN_HOLE_LEAF`, `TAIL_PIN_HOLE`, `LINK_HOLE`, `M2_INSERT_D`, `M3_INSERT_D`, `MAG_POCKET_CLR`;
luego `python build_all.py && python verify.py && python make_docs_v2.py`.

Las piezas marcadas **NO DEFINITIVA** dependen de medidas pendientes (doc 02): imprimirlas solo después de actualizarlas o como prueba.

| Archivo | Cant. | Tamaño (mm) | Masa PETG (g) | Parámetros | Soporte | Nota |
|---|---|---|---|---|---|---|
| `CardioValAI_v2_Valve_Ring.stl` | 1 | 72,0 × 78,1 × 24,0 | 35,2 | 0.2 mm · 50 % · 4 perímetros | no | Repasar los agujeros horizontales de Ø2,1 con broca de 2,0–2,1 mm si quedan ovalados. Insertos M2 en las almohadillas con soldador a 220 °C. |
| `CardioValAI_v2_Leaflet_1.stl` | 1 | 28,3 × 33,9 × 10,6 | 1,7 | 0.12 mm · 100 % · 3 perímetros | sí | Imprimir con la cara inferior plana en la cama. Soporte mínimo (árbol) bajo la cola inclinada 40°. Imán Ø4×2 en la cara −y de la cola (polaridad marcada). |
| `CardioValAI_v2_Leaflet_2.stl` | 1 | 28,3 × 33,9 × 10,6 | 1,7 | 0.12 mm · 100 % · 3 perímetros | sí | Imprimir con la cara inferior plana en la cama. Soporte mínimo (árbol) bajo la cola inclinada 40°. Imán Ø4×2 en la cara −y de la cola (polaridad marcada). |
| `CardioValAI_v2_Leaflet_3.stl` | 1 | 28,3 × 33,9 × 10,6 | 1,7 | 0.12 mm · 100 % · 3 perímetros | sí | Imprimir con la cara inferior plana en la cama. Soporte mínimo (árbol) bajo la cola inclinada 40°. Imán Ø4×2 en la cara −y de la cola (polaridad marcada). |
| `CardioValAI_v2_Link_Normal.stl` | 4 | 6,0 × 32,0 × 3,0 | 0,7 | 0.2 mm · 100 % · 3 perímetros | no | Plana. Sin marcas. |
| `CardioValAI_v2_Link_LostMotion.stl` | 2 | 6,0 × 37,5 × 3,0 | 0,7 | 0.2 mm · 100 % · 3 perímetros | no | Plana. |
| `CardioValAI_v2_Link_LostMotion_IC.stl` | 1 | 6,0 × 36,1 × 3,0 | 0,7 | 0.2 mm · 100 % · 3 perímetros | no | Plana. |
| `CardioValAI_v2_Opening_Stop_84.stl` | 3 | 11,0 × 12,0 × 4,4 | 0,4 | 0.2 mm · 100 % · 3 perímetros | no | Brida en la cama. |
| `CardioValAI_v2_Opening_Stop_60.stl` | 1 | 11,0 × 12,0 × 7,2 | 0,5 | 0.2 mm · 100 % · 3 perímetros | no | Brida en la cama. |
| `CardioValAI_v2_Opening_Stop_45.stl` | 1 | 11,0 × 12,0 × 8,3 | 0,5 | 0.2 mm · 100 % · 3 perímetros | no | Brida en la cama. |
| `CardioValAI_v2_Actuator_Plate.stl` | 1 | 66,6 × 69,5 × 13,0 | 13,7 | 0.2 mm · 40 % · 4 perímetros | no | Repasar los bujes Ø8,6 con lija y lubricar con grasa de PTFE. |
| `CardioValAI_v2_Pushrod.stl` | 1 | 5,6 × 35,6 × 3,0 | 0,7 | 0.2 mm · 100 % · 3 perímetros | no | Plano. |
| `CardioValAI_v2_Column.stl` | 3 | 8,0 × 8,0 × 56,1 | 3,3 | 0.2 mm · 40 % · 4 perímetros | no | Vertical. Lijar la superficie de deslizamiento (grano 400) y lubricar. |
| `CardioValAI_v2_Column_Spacer.stl` | 2 | 12,0 × 12,0 × 2,0 | 0,3 | 0.2 mm · 100 % · 3 perímetros | no |  |
| `CardioValAI_v2_H0_Holder.stl` | 1 | 19,5 × 12,0 × 15,3 | 0,9 | 0.2 mm · 100 % · 4 perímetros | no | Arandela en la cama, pata hacia arriba. |
| `CardioValAI_v2_Cable_Clip.stl` | 3 | 16,8 × 11,8 × 6,0 | 0,7 | 0.2 mm · 100 % · 3 perímetros | no |  |
| `CardioValAI_v2_Piezo_Mount.stl` **NO DEFINITIVA** | 2 | 22,0 × 30,0 × 4,0 | 3,0 | 0.2 mm · 100 % · 4 perímetros | no | Cara de contacto en la cama. |
| `CardioValAI_v2_Piezo_Cover.stl` **NO DEFINITIVA** | 2 | 22,0 × 30,0 × 3,4 | 2,2 | 0.2 mm · 40 % · 3 perímetros | no | Cara exterior en la cama. |
| `CardioValAI_v2_Piezo_Adapter_12mm.stl` **NO DEFINITIVA** | 1 | 15,2 × 15,2 × 0,6 | 0,0 | 0.15 mm · 100 % · 2 perímetros | no | Solo si el disco comprado es de 12 mm. |
| `CardioValAI_v2_MEMS_Mount.stl` **NO DEFINITIVA** | 1 | 36,0 × 30,0 × 17,7 | 4,6 | 0.2 mm · 40 % · 3 perímetros | sí | Apoyar la cara exterior de la escuadra en la cama; soportes bajo el portaplaca. |
| `CardioValAI_v2_MEMS_Stand.stl` | 1 | 44,0 × 32,0 × 76,6 | 20,4 | 0.2 mm · 40 % · 4 perímetros | no | Pie en la cama. |
| `CardioValAI_v2_MEMS_Stand_Holder.stl` **NO DEFINITIVA** | 1 | 28,9 × 18,9 × 7,0 | 1,1 | 0.2 mm · 40 % · 3 perímetros | sí | Cara del marco en la cama. |
| `CardioValAI_v2_Servo_Mount.stl` **NO DEFINITIVA** | 1 | 40,2 × 35,0 × 22,0 | 12,0 | 0.2 mm · 50 % · 4 perímetros | no | Fijar a la base sobre arandelas de goma (antivibración). Insertos M2 en la almohadilla P2. |
| `CardioValAI_v2_Electronics_Tray.stl` **NO DEFINITIVA** | 1 | 79,4 × 103,8 × 9,6 | 35,6 | 0.2 mm · 30 % · 3 perímetros | no | Insertos M3 en los 4 postes. |
| `CardioValAI_v2_Tray_Clamp.stl` **NO DEFINITIVA** | 2 | 8,0 × 103,8 × 3,0 | 2,9 | 0.2 mm · 100 % · 3 perímetros | no | Cara superior en la cama. |
| `CardioValAI_v2_Angle_Scale.stl` | 1 | 92,7 × 70,0 × 2,0 | 16,4 | 0.2 mm · 30 % · 3 perímetros | no | Plano; marcas hacia arriba. |
| `CardioValAI_v2_Base.stl` **NO DEFINITIVA** | 1 | 200,0 × 180,0 × 6,0 | 270,4 | 0.2 mm · 20 % · 4 perímetros | no | Cabe en camas ≥ 220 × 220 mm. Usar borde (brim) de 5 mm para evitar alabeo. |
| `CardioValAI_v2_Tolerance_Coupon.stl` | 1 | 66,0 × 46,0 × 6,5 | 23,9 | 0.2 mm · 100 % · 3 perímetros | no | Imprimir primero: elegir los diámetros reales que ajustan con los ejes, insertos e imanes comprados. |

Insertos termofijados: soldador a ≈ 220–230 °C con punta para insertos; presionar recto hasta quedar a ras; dejar enfriar sin mover.
