# 07 · Herramientas de computadora (Mac): registro, vista en vivo, análisis y calibración

> CardioVal AI · revisión **v2** · prototipo académico de banco **sin fluido**. No es un dispositivo médico ni de diagnóstico.
> **[CÁLCULO]** verificado por cálculo · **[SIM]** inspección o simulación geométrica · **[SW]** compilado o probado en software · **[FÍSICO]** pendiente de ensayo físico

Carpeta `host/`. Python ≥ 3.10: `python3 -m pip install -r requirements.txt` (numpy, scipy, matplotlib, pyserial). Puerto en Mac: `/dev/cu.usbserial-*`, `/dev/cu.SLAB_USBtoUART`
(CP2102) o `/dev/cu.wchusbserial*` (CH340): `ls /dev/cu.*`.

| Programa | Uso |
|---|---|
| `cvai_record.py` | Registra una sesión (`raw.bin` sin modificar + `session.json` + `session.npz` + `audio.wav`). `--live` abre la vista en vivo: ángulo medido (o cuentas si no hay calibración) **y aparte** el comando del servo, H0, P1/P2, envolvente del audio y alertas de saturación, pérdidas, CRC y parada. `--modo` declara las piezas instaladas. |
| `cvai_analyze.py` | Por ciclo: inicio y fin MEDIDOS de apertura y cierre, retardos respecto del comando, duraciones, meseta, residual, período, carrera del plato, asimetría, z robusto ciclo a ciclo, clasificación «equivalente / inconsistente» con motivos. Señales complementarias: contraste en ventanas de evento, tiempo del pico y energía por bandas. Gráficos y `ciclos.csv`. |
| `cvai_calibrate.py` | `guiado`: lleva el servo a posiciones fijas y pide los ángulos medidos (transportador/video). `ajustar`: curva monótona por valva con validación cruzada. |
| `cvai_emulator.py` | **Emulador con datos SINTÉTICOS** (puerto virtual, mismo protocolo). Solo para probar el software. Todo lo que produce lleva la marca «SINTÉTICO» en `session.json` y en los gráficos. Puede inyectar fallas inventadas (`--falla atasco:N`, `asimetria:N`, `cierre:N`). |
| `tests/test_e2e.py` | Prueba automática emulador → registro → calibración sintética → análisis. Resultado en este entorno: **aprobada** [SW]. |

**Separación de datos reales y de demostración:** el campo `fuente` de `session.json` viene de la trama INFO del firmware; el emulador declara «EMULADOR — DATOS SINTÉTICOS».
Nunca se mezclan sesiones sintéticas con reales en el análisis de variabilidad.

**Sin IA por ahora.** Si más adelante se entrena un clasificador, separar entrenamiento y evaluación **por sesión** (nunca ciclos de la misma sesión en ambos conjuntos)
para evitar fuga de información.
