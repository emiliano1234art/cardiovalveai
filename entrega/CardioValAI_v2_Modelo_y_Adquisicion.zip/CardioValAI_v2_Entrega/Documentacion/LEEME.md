# CardioVal AI — paquete v2

> CardioVal AI · revisión **v2** · prototipo académico de banco **sin fluido**. No es un dispositivo médico ni de diagnóstico.
> **[CÁLCULO]** verificado por cálculo · **[SIM]** inspección o simulación geométrica · **[SW]** compilado o probado en software · **[FÍSICO]** pendiente de ensayo físico

Banco experimental universitario de válvula aórtica trivalva accionada por un servo, **sin circulación de líquido**. Objetivo principal: medir de forma repetible la apertura y
el cierre y detectar inconsistencias entre ciclos. Vibración y sonido son señales complementarias. **Detectar cambios en este banco no equivale a diagnosticar una prótesis.**

La revisión **v1** se conserva sin cambios en `entrega/CardioValAI_Modelo_Final_STL.zip`. Todos los archivos de este paquete se generaron desde el mismo código (ver `REVISION.json`).

| Carpeta / archivo | Contenido |
|---|---|
| `Documentacion/01…10` | Auditoría, medidas pendientes, sensores, mecanismo, electrónica, firmware, herramientas, método, ensayos, pendientes |
| `Documentacion/Guia_de_Impresion_v2.md`, `Guia_de_Ensamblaje_v2.md`, `Lista_de_Materiales_v2.*`, `Informe_de_Validacion_v2.md` | Fabricación y verificación |
| `CardioValAI_v2_STL/` | Piezas imprimibles (mm, orientadas) |
| `CardioValAI_v2_STEP/`, `CardioValAI_v2_Assembly_Cerrada.step` | Sólidos editables y ensamblaje |
| `Referencia_NO_IMPRIMIR/` | Servo, ESP32+placa, sensores, imanes, tornillería, cables |
| `CardioValAI_v2_Final.blend` | Ensamblaje animado (Blender 4.5 LTS) |
| `CardioValAI_v2_Animacion.mp4` | Animación cinemática (no es prueba de funcionamiento) |
| `Vistas/` | Ubicación de sensores y recorrido de cables |
| `Electronica/` | Esquemas (SVG/PNG) |
| `CAD_parametrico/`, `Firmware_v2/`, `Herramientas_Mac/`, `Electronica_fuente/` | Código fuente reproducible |
| `Firmware_v1_original/` | Prueba de servo de v1 (solo mueve el servo) |
