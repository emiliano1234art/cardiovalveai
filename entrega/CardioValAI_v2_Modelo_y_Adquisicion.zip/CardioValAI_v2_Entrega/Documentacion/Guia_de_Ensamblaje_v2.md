# Guía de ensamblaje v2 (paso a paso)

> CardioVal AI · revisión **v2** · prototipo académico de banco **sin fluido**. No es un dispositivo médico ni de diagnóstico.
> **[CÁLCULO]** verificado por cálculo · **[SIM]** inspección o simulación geométrica · **[SW]** compilado o probado en software · **[FÍSICO]** pendiente de ensayo físico

Herramientas: soldador para insertos, destornillador allen 1,5 y 2,5 mm, llave de tubo 4 mm, alicate de punta, calibre, cianoacrilato, silicona neutra, grasa PTFE, bridas finas.

1. **Probeta** y ajuste de diámetros (guía de impresión).
2. **Insertos:** M3 en las columnas (ambos extremos) y en la base (servo, bandeja, soporte M1); M2 en las 3 almohadillas del anillo y en la almohadilla P2; M3 en los 4 postes de la bandeja.
3. **Imanes:** uno por valva, en el alojamiento de la cara −y de la cola, con cianoacrilato y **la misma cara hacia afuera en las tres** (marcar la polaridad con un punto). Imán Ø3 en el
   lóbulo de la columna 1 del plato.
4. **Columnas → base:** M3×10 desde abajo (cabezas en los rebajes).
5. **Servo:** centrarlo (comando 90°) antes de colocar el horn; horn con el brazo horizontal hacia el centro de la válvula. Servo al `Servo_Mount` con sus tornillos; el soporte a la base con
   M3×12, dos arandelas de goma y el casquillo limitador (no aplastar la goma).
6. **Plato:** lubricar los bujes con grasa PTFE; deslizar sobre las columnas (imán hacia arriba, en la columna 1). Empujador al horn y a la horquilla (M2×14 + tuerca).
7. **Valvas + bielas (en el banco):** pasador de latón Ø2×9 a presión en la cola (a ras de la cara −y), biela normal en el pasador (gira libre).
8. **Valvas en el anillo:** número grabado de la valva = número del sector; biela hacia abajo por la ranura; eje de latón Ø2×56 desde afuera; cianoacrilato solo en los extremos.
   Girar a mano: 0–90° sin roce.
9. **Topes:** `Opening_Stop_84` desde abajo en cada ranura; tuerca M2 en la trampa de la brida; tornillo M2×20 de latón desde arriba.
10. **Sensores Hall:** soldar 3 hilos finos (≈ 30 cm) a cada DRV5055A1 (patas dobladas hacia arriba), insertar en su bolsillo hasta el piso con la cara plana hacia el centro, gota de
    silicona; cables por el canal superior y la bajada exterior.
11. **Arandelas y soporte H0:** `Column_Spacer` sobre las columnas 2 y 3; `H0_Holder` sobre la columna 1 con el DRV5055A2 acostado (cara plana hacia abajo) en su bolsillo.
12. **Anillo sobre las columnas:** servo en 50° (plato abajo); unir cada biela a su orejeta del plato (M2×10 + tuerca, llave de tubo por el lado de la tuerca; retirar antes el
    `Angle_Scale`); fijar el anillo con M3×30 desde las comisuras.
13. **Comprobar a mano** (ensayo 2) con el empujador desconectado y luego conectado.
14. **Piezo P1** (almohadilla de la valva 2) y **P2** (almohadilla P2 del soporte del servo): cinta doble faz fina recortada, disco en el asiento, cables por el canal, brida, tapa (no toca
    el disco), 2× M2×10.
15. **Micrófono M1:** placa en `MEMS_Stand_Holder` (puerto libre), pivote M3×16 + autoblocante, soporte a la base por las ranuras (M3×10). Alternativa: `MEMS_Mount` en la almohadilla de la valva 1.
16. **Cables:** pinzas en las columnas (bajo el recorrido del plato), bridas en las ranuras de la base: señales por el sur, servo/5 V por el norte. Mover el servo a mano por todo el
    recorrido y comprobar que nada roce.
17. **Electrónica:** placa perforada en la bandeja (barras de sujeción), ESP32 en zócalos hembra con la antena fuera del borde −y; prueba previa del acondicionamiento (doc 05) ANTES de
    enchufar el ESP32.
18. **Cambio de módulo:** servo en 50° → retirar tornillo biela–plato → sacar el eje → cambiar biela y tope (y elástico) → volver a montar → recalibrar si se tocó el imán/sensor.
