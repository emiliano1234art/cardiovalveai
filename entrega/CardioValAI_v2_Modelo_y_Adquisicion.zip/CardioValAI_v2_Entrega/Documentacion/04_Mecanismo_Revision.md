# 04 · Revisión del mecanismo y del montaje

> CardioVal AI · revisión **v2** · prototipo académico de banco **sin fluido**. No es un dispositivo médico ni de diagnóstico.
> **[CÁLCULO]** verificado por cálculo · **[SIM]** inspección o simulación geométrica · **[SW]** compilado o probado en software · **[FÍSICO]** pendiente de ensayo físico

## 1. Geometría principal [SIM]
- Valvas planas de 1,6 mm sobre ejes de cuerda a 20 mm del centro; holgura con la pared ≥ 1,0 mm en todo el recorrido hasta
  86° (incluye el espesor); separación entre bordes al cerrar 1,0 mm (no hay contacto valva–valva).
- Carrera del plato 10,285 mm; radio del horn 8,0 mm → barrido ±40,0° (comando 50,0° = abierta, 130,0° = cerrada).
- Holguras móviles por defecto 0,40 mm; bujes del plato 0,3 mm radial, largo 12 mm.

## 2. Modos: piezas alternativas y simultáneas [CÁLCULO]

| Modo | Módulos (valva 1, 2, 3) | Recorrido de cada valva | ángulo de transmisión mín. |
|---|---|---|---|
| NORMAL | N, N, N | v1: 0→80° · v2: 0→80° · v3: 0→80° | 48° |
| RESTRINGIDA_60 | R60, N, N | v1: 0→60° · v2: 0→80° · v3: 0→80° | 48° |
| RESTRINGIDA_45 | R45, N, N | v1: 0→45° · v2: 0→80° · v3: 0→80° | 48° |
| CIERRE_INCOMPLETO | IC, N, N | v1: 12→84° · v2: 0→80° · v3: 0→80° | 43° |
| ASIMETRICO | R60, R45, N | v1: 0→60° · v2: 0→45° · v3: 0→80° | 48° |

- **Se montan siempre:** anillo, 3 valvas, plato, empujador, columnas, servo, sensores.
- **Alternativas por valva:** biela normal `Link_Normal` + tope 84° (modo normal) **o** biela con recorrido perdido `Link_LostMotion` + tope 60° o 45° + resorte/elástico
  **o** `Link_LostMotion_IC` + tope 84° + elástico (cierre incompleto). Asimétrico = valva 1 con 60° y valva 2 con 45°.
- **El servo nunca empuja contra un tope:** en modo normal la valva llega a 80° y el tope está en 84°; en los modos alterados la ranura de la biela absorbe el resto
  de la carrera (ranura usada ≤ 4,44 de 5,5 mm). El rango de comando del firmware está limitado por software.
- **Elástico (v2):** se engancha en la oreja del barril de la valva (lado −y) y pasa por el agujero de la brida del tope (se anuda debajo). Solo en los modos con
  recorrido perdido. Fuerza sugerida 0,3–0,6 N (banda elástica fina o resorte de tracción pequeño): VERIFICAR que la valva llegue al tope.

## 3. Holguras mínimas medidas en el barrido [SIM]

| Par | mínimo (mm) | modo | servo β |
|---|---|---|---|
| Leaflet_1 ↔ Stop_1 | 0,00 | RESTRINGIDA_60 | -30,0° |
| Link_1 ↔ Leaflet_1 | 0,30 | NORMAL | 40,0° |
| Actuator_Plate ↔ Column_1 | 0,30 | ASIMETRICO | -40,0° |
| Pushrod ↔ Servo_Horn_Reference | 0,30 | ASIMETRICO | -40,0° |
| Leaflet_1 ↔ Leaflet_2 | 0,49 | ASIMETRICO | 30,0° |
| Leaflet_2 ↔ Leaflet_3 | 0,49 | ASIMETRICO | 30,0° |
| Pushrod ↔ Actuator_Plate | 0,50 | NORMAL | 40,0° |
| Actuator_Plate ↔ H0_Holder | 0,60 | NORMAL | 40,0° |
| Link_1 ↔ Valve_Ring | 0,60 | NORMAL | 0,0° |
| Leaflet_1 ↔ Valve_Ring | 0,67 | NORMAL | 0,0° |
| Leaflet_1 ↔ Hall_Sensors_Reference | 1,50 | NORMAL | 40,0° |
| Magnet_1 ↔ Hall_Sensors_Reference | 1,66 | CIERRE_INCOMPLETO | 40,0° |
| Cable_Routes_Reference ↔ Actuator_Plate | 2,58 | NORMAL | -40,0° |
| Pushrod ↔ Servo_MG90S_Reference | 2,82 | NORMAL | 30,0° |
| Actuator_Plate ↔ Ring_Fasteners_Reference | 2,92 | ASIMETRICO | 40,0° |
| Plate_Magnet ↔ Hall0_Reference | 3,23 | ASIMETRICO | 40,0° |
| Link_1 ↔ Stop_1 | 3,89 | CIERRE_INCOMPLETO | -40,0° |
| Cable_Routes_Reference ↔ Column_1 | 4,50 | ASIMETRICO | -40,0° |
| Leaflet_1 ↔ MEMS_Mount | 5,00 | CIERRE_INCOMPLETO | -40,0° |

## 4. Radio del horn: consecuencias [CÁLCULO]
Medir el agujero elegido y escribirlo en `config.SERVO.horn_r`; luego regenerar todo (`build_all.py`, `verify.py`).

| r horn (mm) | barrido | comando | columna (mm) | inclinación máx. del empujador | par necesario (kg·cm) |
|---|---|---|---|---|---|
| 6 | ±59,0° | 31,0–149,0° | 56,05 | 2,8° | 0,107 |
| 7 | ±47,3° | 42,7–137,3° | 56,06 | 2,1° | 0,125 |
| 8 | ±40,0° | 50,0–130,0° | 56,07 | 1,8° | 0,143 |
| 9 | ±34,8° | 55,2–124,8° | 56,07 | 1,5° | 0,161 |
| 10 | ±30,9° | 59,1–120,9° | 56,07 | 1,4° | 0,178 |
| 11 | ±27,9° | 62,1–117,9° | 56,08 | 1,2° | 0,196 |
| 12 | ±25,4° | 64,6–115,4° | 56,08 | 1,1° | 0,214 |
| 14 | ±21,5° | 68,5–111,5° | 56,08 | 0,9° | 0,250 |

## 5. Par del servo [CÁLCULO, con supuestos]
Fuerza en el empujador 1,75 N (peso del plato y bielas 16,5 g, momento de gravedad de las valvas, fricción supuesta μ = 0,35 con
carga lateral de 0,3 N por buje, 2 elásticos de 0,6 N). Par = 0,143 kg·cm frente a 1,8 kg·cm de bloqueo (dato de distribuidores, NO verificado)
→ margen ×12,6. El margen real se mide con el INA219 (corriente) en los ensayos 6 y 7.

## 6. Efecto cajón del plato [CÁLCULO]
Con cargas simétricas (3 valvas iguales) la resultante pasa por el centro: sin riesgo. Si UNA valva se traba, la resultante se desplaza hasta ≈ 27.1 mm: supera 17.1 mm en seco (puede trabarse el plato) y queda por debajo de 40.0 mm lubricado. Lubricar y dejar activa la detección de atasco (H0) del firmware.

## 7. Uniones y tornillería

| Unión | Elemento | Tipo de rosca / retención | Nota |
|---|---|---|---|
| Eje de bisagra (×3) | Varilla de LATÓN Ø2 × 56 | Ajuste en el anillo (Ø2,1) + gota de cianoacrilato SOLO en los extremos; libre en la valva (Ø2,4) | No magnético |
| Cola–biela (×3) | Pasador de LATÓN Ø2 × 9 | A presión en la cola (Ø1,95), libre en la biela (Ø2,2); las paredes de la ranura impiden que salga | Reemplaza el autorroscante de acero de v1 |
| Biela–orejeta del plato (×3) | M2×10 inox A2 o latón + tuerca M2 | Métrico con tuerca (no rosca en plástico) | Llave de tubo 4 mm por el lado de la tuerca |
| Horquilla–empujador | M2×14 + tuerca M2 | Métrico con tuerca |  |
| Empujador–horn | Tornillo del horn (o M2×6) | Rosca en el horn | Agujero del empujador Ø2,4 libre |
| Topes (×3) | M2×20 de LATÓN + tuerca M2 atrapada | Métrico; tuerca en la trampa hexagonal de la brida | Cerca del Hall: no usar acero |
| Almohadillas (P1, M1 alt.) | M2×10 inox | Insertos termofijados M2 (Ø3,2 × 4) | Desmontaje frecuente |
| Almohadilla P2 | M2×10 inox | Insertos M2 en el soporte del servo |  |
| Columnas → base (×3) | M3×10 | Inserto M3 en la base de la columna | Cabeza en el rebaje inferior de la base |
| Anillo → columnas (×3) | M3×30 | Inserto M3 en la columna; atraviesa la arandela o el soporte H0 |  |
| Orejas del servo (×2) | Tornillos que trae el servo | Autorroscante en piloto Ø1,8 (pocas vueltas de montaje) |  |
| Soporte del servo → base (×4) | M3×12 + 2 arandelas de goma + casquillo Ø4×Ø3,2×5,5 | Inserto M3 en la base; el casquillo limita la compresión de la goma | No apretar la goma a fondo |
| Bandeja → base (×4) | M3×6 | Insertos en la base | Antes de colocar la placa |
| Barras de sujeción (×4) | M3×8 | Insertos en los postes de la bandeja |  |
| Soporte M1 → base (×2) | M3×10 + arandela | Insertos en la base, por las ranuras | Ajuste radial ±8 mm |
| Pivote de M1 | M3×16 + tuerca autoblocante | Fricción regulable |  |
| Pinzas de cable (×3) | — | A presión sobre la columna | Bajo el recorrido del plato |

**Métrico + tuerca:** rosca de acero en acero, se puede desarmar muchas veces. **Inserto termofijado:** rosca métrica de latón dentro del plástico, para uniones que se
desarman a menudo. **Autorroscante:** corta su rosca en el plástico; pocas vueltas de montaje (solo orejas del servo, con los tornillos originales).

## 8. Orden de montaje y acceso a herramientas [SIM]
Ver `Guia_de_Ensamblaje_v2.md`. Comprobaciones automáticas de acceso: 46 de 46 correctas
(trayectorias de ejes, destornilladores, llave de tubo, inserción de los Hall, USB).

## 9. Gomas antivibración [CÁLCULO aproximado / FÍSICO]
Arandelas de goma Shore ≈ 60A bajo el soporte del servo: rigidez estimada de 4 apoyos ≈ 1–3·10⁵ N/m con ≈ 40 g → fn ≈ 250 Hz (orden de magnitud). Aíslan solo por encima de
≈ 1,4·fn; cerca de fn **amplifican**. El casquillo limita la compresión para que la rigidez sea repetible. Ensayo 6: comparar P1/P2 con y sin gomas.

## 10. Cables durante el ciclo [SIM]
Todos los recorridos (H0–H3, P1, P2, M1, servo) están modelados como haces Ø2–3 mm y se verificaron contra las piezas móviles en las 125 poses:
sin interferencias; holgura mínima cable–plato 2,6 mm.
Señales por el sur de la base hacia el extremo −y de la bandeja; servo y 5 V por el norte hacia el extremo +y (separación ≥ 20 mm).

## 11. Observación directa de la posición
- Hall H1–H3 (medición principal, calibrada).
- Cámara superior: dos hoyuelos Ø1,5 en la línea central de cada valva (a 6 y 16 mm del eje) y marca fiduciaria en el anillo.
- Cámara lateral alineada con el eje de la valva 1 frente al `Angle_Scale` (transportador 0–90°).
- LED de sincronización (GPIO19) dentro del cuadro: une el video con los datos.

## 12. Animación
La animación se calcula cuadro a cuadro con la misma cinemática del CAD. **No es una prueba de funcionamiento ni una medición**.
