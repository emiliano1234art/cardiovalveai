# 03 · Sensores: evaluación, ubicación, señales esperadas y pruebas de selección

> CardioVal AI · revisión **v2** · prototipo académico de banco **sin fluido**. No es un dispositivo médico ni de diagnóstico.
> **[CÁLCULO]** verificado por cálculo · **[SIM]** inspección o simulación geométrica · **[SW]** compilado o probado en software · **[FÍSICO]** pendiente de ensayo físico

## 1. Evaluación de la configuración propuesta (P1, P2, M1)

**Conclusión:** P1, P2 y M1 **no alcanzan** para determinar de forma confiable cuándo empieza y termina la apertura y el cierre. Motivos [CÁLCULO]:
- En modo normal no hay contacto mecánico al abrir ni al cerrar (holgura de coaptación 1,0 mm; tope a 84° no alcanzado). Sin choque no hay un
  transitorio característico; lo que vibra y suena durante el movimiento es sobre todo el **servo** (engranajes y motor), que se mueve durante todo el recorrido.
- P2 no mide «solo el motor»: recibe vibración de toda la estructura (base, columnas, plato). Restar P1 − P2 directamente no es válido: los caminos de transmisión
  tienen distinta ganancia y fase según la frecuencia (gomas, PETG, uniones atornilladas). Solo se justificaría restar con una función de transferencia medida
  (ensayo 6) y en las bandas donde la coherencia P1–P2 sea alta (> 0,8).
- Un micrófono omnidireccional orientado hacia la válvula **no** rechaza el sonido del motor.
- Un piezo por sector **no** identifica la valva de ese sector: la estructura transmite a todo el anillo.

**Cambio adoptado:** se agrega **medición directa de posición** con sensores Hall (H1–H3 por valva + H0 en el plato). Piezo y micrófono se conservan como señales
**complementarias** y se evalúa experimentalmente si aportan (ensayos 5, 6, 10 y 11). Las 3 almohadillas del anillo permiten comparar posiciones de P1.

## 2. Origen común y coordenadas

Origen: esquina inferior de la base (x a lo largo de 200 mm, y a lo largo de 180 mm, z hacia arriba). Centro de la válvula: (78,0; 92,0) mm; cara inferior
del anillo a z = 64,07 mm. Valvas en 90°, 210° y 330° (valva 1, 2, 3). Coordenadas con la válvula **cerrada** (servo 130°).

| Sensor | Pieza | Centro (x; y; z) mm | Orientación | Ajuste |
|---|---|---|---|---|
| H1 | Valve_Ring (bolsillo TO-92) | (86,0; 118,8; 77,6) | radial hacia afuera (x local) | fijo (piso del bolsillo); la variación se absorbe con la calibración |
| H2 | Valve_Ring (bolsillo TO-92) | (50,8; 85,5; 77,6) | radial hacia afuera (x local) | fijo (piso del bolsillo); la variación se absorbe con la calibración |
| H3 | Valve_Ring (bolsillo TO-92) | (97,2; 71,7; 77,6) | radial hacia afuera (x local) | fijo (piso del bolsillo); la variación se absorbe con la calibración |
| H0 | H0_Holder (arandela de la columna 1) | (60,7; 102,0; 50,2) | vertical (cara plana hacia abajo) | fijo; separación 4 mm con el plato arriba (verificar con galga) |
| P1 | Piezo_Mount en la almohadilla de la valva 2 | (57,8; 57,0; 71,3) | normal del disco: radial | 3 almohadillas iguales (valvas 1, 2 y 3) para comparar posiciones |
| P2 | Piezo_Mount en la almohadilla P2 del Servo_Mount | (76,4; 138,5; 20,8) | normal del disco: +y global | fijo |
| M1 | MEMS_Stand + MEMS_Stand_Holder | (100,9; 52,3; 93,8) | normal de la placa hacia el eje de la válvula, inclinada hacia abajo | radial ±8 mm (ranuras), inclinación libre en el pivote (nominal 22,9°) |
| M1_alt | MEMS_Mount (escuadra sobre la almohadilla de la valva 1) | (62,8; 118,4; 85,8) | inclinado 40° hacia el centro | altura ±3 mm (ranuras) |

## 3. Sensores Hall de posición (medición principal)

**Principio:** el imán (N42, Ø4×2 mm, magnetizado axialmente) gira con la cola de la valva; el DRV5055 mide la componente radial del
campo. La salida es una tensión proporcional al campo (60 mV/mT en A1 con VCC = 3,3 V, dato de la hoja de datos TI). La curva tensión–ángulo **no es lineal**: se calibra
punto por punto (`cvai_calibrate.py`).

**Respuesta calculada** con un modelo de dipolos (aproximado; sirve para elegir geometría y comprobar monotonía, no para predecir mV exactos) [CÁLCULO]:

| θ (°) | B (mT) | Vout A1 (V) | pendiente (mV/°) |
|---|---|---|---|
| -2 | 14,40 | 0,786 | 1,8 |
| 0 | 14,31 | 0,791 | 3,6 |
| 5 | 13,82 | 0,820 | 7,9 |
| 10 | 13,01 | 0,869 | 11,5 |
| 20 | 10,73 | 1,006 | 15,1 |
| 30 | 8,22 | 1,157 | 14,4 |
| 40 | 6,06 | 1,286 | 11,3 |
| 50 | 4,45 | 1,383 | 8,1 |
| 60 | 3,33 | 1,450 | 5,5 |
| 70 | 2,58 | 1,495 | 3,7 |
| 80 | 2,07 | 1,526 | 2,5 |
| 84 | 1,91 | 1,535 | 2,2 |

Monótona en 0–84°: **sí** · pendiente mínima 2,19 mV/° · campo máximo 14,4 mT
(DRV5055A1 satura a ≈ ±21 mT con 3,3 V → margen).

**Tolerancia de montaje ±0,5 mm** (¿sigue siendo monótona?) [CÁLCULO]:

| desplazamiento | monótona | pendiente mín. (mV/°) | campo máx. (mT) |
|---|---|---|---|
| x+0.5 | sí | 0,86 | 12,9 |
| x-0.5 | sí | 1,91 | 15,9 |
| y-0.5 | sí | 1,93 | 11,9 |
| z+0.5 | sí | 1,69 | 12,9 |
| z-0.5 | sí | 0,81 | 15,9 |

**Resolución estimada:** con ruido efectivo de ≈ 1 mV tras promediar 8 muestras (estimación; se mide en el ensayo 4), ≈ 0,3–0,5° cerca de 0° y de 84°, y < 0,1° a mitad de
recorrido. **Rango:** −2° a 84°. **Frecuencia:** 1 kS/s por canal (el movimiento dura cientos de ms).

**H0 (plato):** imán Ø3×2 en el lóbulo de la columna 1; DRV5055A2 (30 mV/mT) a 4,0 mm con el plato arriba.
Campo vs. carrera: 0,0 mm → 21,98 mT · 1,1 mm → 12,70 mT · 2,1 mm → 7,96 mT · 3,1 mm → 5,31 mT · 4,2 mm → 3,71 mT · 5,2 mm → 2,69 mT · 6,3 mm → 2,02 mT · 7,3 mm → 1,55 mT · 8,4 mm → 1,21 mT · 9,4 mm → 0,97 mT. Monótona: **sí**; muy **no lineal** (∝ 1/d³): se linealiza con la calibración. Diafonía del imán del plato
sobre H1–H3: ≤ 1,9 mV (despreciable y constante en la calibración) [CÁLCULO].

**Fijación:** imán con una gota de cianoacrilato, **polaridad marcada** (orientar para que la salida baje desde 1,65 V al acercarse; si sube, dar vuelta el imán).
Sensor TO-92 empujado hasta el piso del bolsillo, cara plana hacia el centro de la válvula, fijado con una gota de silicona neutra (removible). Patas hacia arriba,
soldadas a 3 hilos que bajan por el canal exterior del anillo.

**Interferencias:** tornillos/ejes de acero cerca (por eso latón), imán del motor del servo (≈ 65 mm; se mide en el ensayo 5/6), campo terrestre (constante: lo absorbe la
calibración), temperatura (≈ −0,12 %/°C del imán: calibrar a la temperatura de trabajo), ruido de la alimentación (sensor ratiométrico → regulador analógico propio 3V3_A).

**Señal esperada:** H1–H3 bajan de ≈ 0,79 V (cerrada) a ≈ 1,53 V (80°) durante la apertura y vuelven
al cerrar; H0 sigue la carrera del plato. **Apertura incompleta:** meseta más baja; **cierre incompleto:** el residual no vuelve a la base; **asimetría:** mesetas distintas
entre valvas; **atasco:** H0 se detiene mientras el comando sigue.

**Prueba de selección:** no hay posiciones alternativas que elegir (el bolsillo es fijo); se verifica que la calibración sea monótona con error de validación cruzada ≤ 1° y que
el ruido estático sea ≤ 0,5° (ensayo 4). Si no se cumple: revisar polaridad/pegado del imán y la posición del sensor.

## 4. Piezoeléctricos P1 y P2 (complementarios)

- **P1:** en `Piezo_Mount` atornillado a la almohadilla de la **valva 2** (las 3 almohadillas son iguales: se puede mover a la valva 1 o 3 para comparar).
  **P2:** el mismo soporte en la almohadilla `P2` del `Servo_Mount` (lado aislado por las gomas: ve fuerte al servo, pero también a la estructura).
- **Fijación repetible:** disco apoyado en un asiento de 0,8 mm de profundidad y adherido con **cinta doble faz fina (≈ 0,1 mm) recortada a la medida** o un punto de
  cianoacrilato en el borde metálico (más rígido, más difícil de sacar). La tapa **no toca** el disco. Dos tornillos M2 con insertos y el mismo torque «firme con la mano».
- **Efecto de la fijación:** el adhesivo y la masa del soporte forman un sistema masa–resorte; una capa blanda (cinta gruesa) atenúa las frecuencias altas y desplaza la
  resonancia; un adhesivo rígido transmite mejor pero cambia con cada pegado. Por eso: misma cinta, mismo recorte, mismo torque, y el ensayo 9 (desmontar/montar) mide la
  repetibilidad del montaje.
- **Cable:** sale por el canal inferior del soporte, brida en las ranuras (alivio de tensión), baja por fuera del recorrido del plato (ver vistas de cables).
- **Señal esperada:** ruido del servo mientras se mueve (P2 ≫ P1 esperable), casi nada en reposo. Un rebote o contacto (tope, atasco, roce) puede producir un transitorio
  breve; solo cuenta si su tiempo coincide con el evento medido por los Hall en ciclos repetidos.
- **Interferencias:** servo, mesa, ambiente (golpes, voces), cable movido (triboeléctrico), red eléctrica.
- **Prueba de selección:** con el ensayo 10, comparar las 3 almohadillas: contraste (dB) en ±30 ms del fin de apertura/cierre MEDIDO respecto de la mitad del recorrido y
  respecto de la espera quieta (`cvai_analyze.py` lo calcula). Se elige la que tenga mayor contraste **y** menor dispersión del tiempo del pico (IQR).
- **Distinguir ciclos normales de inconsistentes:** comparar energía por banda y tiempo del pico por ciclo con la mediana de la sesión (z robusto); solo es útil si en los
  ciclos con fallas conocidas (ensayo 8) aparece un cambio reproducible que los Hall confirmen.

## 5. Micrófono M1 (complementario)

- **Placa:** confirmar con fotos (ítem 4 de 02). El INMP441 es de **puerto inferior**: el agujero está en la cápsula y, en muchas placas de módulo, atraviesa el circuito
  impreso. El portaplaca tiene ventanas en ambas caras para que el puerto quede libre cualquiera sea la placa.
- **Configuración inicial recomendada: soporte independiente `MEMS_Stand`** a 52 mm del eje, 15 mm sobre la cara superior del anillo, apuntando
  al plano de las bisagras (inclinación nominal 22,9°). Razón: separa el micrófono de la vibración estructural del anillo y permite variar la distancia
  (±8 mm) y el ángulo. No es «la óptima»: es el punto de partida.
- **Alternativa a comparar:** `MEMS_Mount` (escuadra en la almohadilla de la valva 1): posición fija y repetible, pero acoplada a la estructura.
- **Resonancia del soporte:** poste de PETG 12×12 de ≈ 73 mm: primer modo estimado ≈ 150–250 Hz con el portaplaca (cálculo de viga empotrada,
  orden de magnitud). Se verifica en el ensayo 5 (espectro en reposo y con golpecito identificado SOLO para caracterizar).
- **Pantalla acústica:** no se usa al comienzo. Si se prueba, una placa entre servo y micrófono crea reflexiones y su propia resonancia; se compararía con y sin pantalla
  en el ensayo 10, sin cambiar nada más.
- **Señal esperada:** ruido del servo durante el movimiento; los eventos de la válvula, si existen, quedarían enmascarados. Se evalúa igual que los piezo.

## 6. Procedimiento experimental para ajustar la ubicación (resumen)

1. Calibrar los Hall (ensayo 4) → los tiempos de evento se toman de los Hall.
2. Registrar 30 ciclos normales por cada configuración: P1 en almohadilla 1, 2 y 3; M1 a 44, 52 y 60 mm (ranura) y en la escuadra.
3. Para cada configuración: contraste evento/mitad del recorrido, IQR del tiempo del pico, coherencia con P2.
4. Elegir la configuración con mejor contraste y menor dispersión; repetir en otra sesión (ensayo 12) antes de fijarla.
