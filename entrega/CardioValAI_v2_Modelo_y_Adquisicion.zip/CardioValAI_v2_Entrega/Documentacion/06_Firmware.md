# 06 · Firmware de adquisición y control (ESP-IDF)

> CardioVal AI · revisión **v2** · prototipo académico de banco **sin fluido**. No es un dispositivo médico ni de diagnóstico.
> **[CÁLCULO]** verificado por cálculo · **[SIM]** inspección o simulación geométrica · **[SW]** compilado o probado en software · **[FÍSICO]** pendiente de ensayo físico

**Estado:** compila con **ESP-IDF v5.4.1** (GCC xtensa esp-14.2.0_20241119; Python 3.11; esp-idf-kconfig 2.5.4; esptool 4.12.0) para `esp32`. Imagen ≈ 279 kB.
**No se probó en hardware** (no hay placa en este entorno). El archivo de restricciones de Python de Espressif (dl.espressif.com) estaba bloqueado por la red; se instalaron
versiones compatibles desde PyPI con la opción oficial `--no-constraints`.
El firmware v1 (`CardioValAI_ServoTest.ino`) se conserva sin cambios.

## Compilar y grabar (Mac)
```
. $HOME/esp/esp-idf/export.sh          # ESP-IDF v5.4.x instalado según la guía oficial de Espressif
cd hardware/firmware/CardioValAI_v2_Adquisicion
idf.py set-target esp32 && idf.py build
idf.py -p /dev/cu.usbserial-XXXX flash   # NO usar 'monitor': el puerto transporta datos binarios
```

## Tareas y prioridades (FreeRTOS)
| Núcleo | Tarea | Prio | Período / disparo | Función |
|---|---|---|---|---|
| 1 | adc | 10 | fin de búfer DMA (4 ms) | demultiplexa, FIR P1/P2, suma Hall, saturación, marcas de tiempo |
| 1 | i2s | 9 | fin de búfer DMA (16 ms) | elige ranura, FIR y diezmado del audio, saturación |
| 0 | servo | 8 | 5 ms (vTaskDelayUntil) | perfil coseno, eventos, seguridad, atasco |
| 0 | ina | 6 | 2 ms | corriente del servo (opcional) |
| 0 | tx | 5 | cola | envía tramas por UART0 |
| 0 | cmd | 4 | líneas de texto | comandos |
| 0 | main | 1 | 500 ms | trama de estado |

## Frecuencias, filtros, búferes y sincronización
- ADC1 continuo a 64 kS/s, 12 bits, atenuación 12 dB; patrón de 8 → P1 y P2 a 16 kS/s (FIR 31 coef. y diezmado → **8 kS/s**), H0–H3 a 8 kS/s (suma de 8 → **1 kS/s**).
- Búfer DMA del ADC 512 B (32 juegos = 4 ms); reserva interna del driver 16 kB (128 ms).
- I2S1: 16 kHz, 8 descriptores × 256 tramas (128 ms); audio enviado a **8 kHz** (FIR 47 coef.) o 16 kHz si el enlace lo permite.
- Búfer de transmisión de 48 kB (≈ 0,5 s). Si se llena, la trama se descarta, se cuenta y la secuencia salta (la computadora lo detecta).
- **Marcas de tiempo:** reloj único `esp_timer` (µs) para ADC, I2S, comandos y eventos → una sola base de tiempo. Retardos de grupo de los FIR descontados.
  Desfase fijo P1–P2 31,25 µs. Comando PWM: se aplica en el próximo período de 20 ms (retardo 0–20 ms) → la posición REAL se toma de los Hall.
- **Video:** LED de sincronización encendido 30 ms al comienzo de cada ciclo (evento con marca de tiempo).

## Seguridad
- Arranca **sin pulsos** al servo. Límites de comando por software (50,0–130,0° más 5° de margen).
- Parada de emergencia (GPIO23): corta los pulsos en la interrupción; bloquea nuevos movimientos hasta soltarla.
- Sin latido `HB` de la computadora durante 2 s → parada controlada (vuelve a cerrado en 800 ms y corta pulsos).
- Atasco: si H0 no varía lo esperado durante un movimiento completo → parada (`SET stall 0` lo desactiva, p. ej. en el ensayo 6 con el empujador desconectado).
- Sobrecorriente sostenida (INA219) → corte inmediato. Falla de adquisición (200 ms sin datos del ADC) → parada controlada.

## Protocolo
Trama `A5 5A | tipo | largo u16 | secuencia u16 | carga | CRC16-CCITT`. Tipos: INFO (JSON con configuración y tabla de calibración del ADC), FAST, HALL, AUDIO, CMD, EVENT,
STATUS, TEXT, INA. Detalle de cada carga en `main/proto.h` y su espejo `host/cvai_proto.py` (los tamaños se comprueban al compilar con `_Static_assert`).
Comandos de texto: `PING, HB, INFO, STREAM ON|OFF, START n, STOP, DETACH, MOVE grados ms, SET clave valor`.
