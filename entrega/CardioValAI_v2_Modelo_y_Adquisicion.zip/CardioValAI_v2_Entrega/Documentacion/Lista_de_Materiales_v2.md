# Lista de materiales v2

> CardioVal AI · revisión **v2** · prototipo académico de banco **sin fluido**. No es un dispositivo médico ni de diagnóstico.
> **[CÁLCULO]** verificado por cálculo · **[SIM]** inspección o simulación geométrica · **[SW]** compilado o probado en software · **[FÍSICO]** pendiente de ensayo físico

| Elemento | Cant. | Tipo | Medidas | Función / nota |
|---|---|---|---|---|
| Valve_Ring | 1 | impresa (PETG) | 72,0 × 78,1 × 24,0 mm · 35,2 g | Anillo valvular con comisuras, bisagras, ranuras de mando, almohadillas con insertos M2 y 3 bolsillos para Hall TO-92  |
| Leaflet_1 | 1 | impresa (PETG) | 28,3 × 33,9 × 10,6 mm · 1,7 g | Valva 1 (semilunar simplificada, barril de bisagra y cola de mando)  |
| Leaflet_2 | 1 | impresa (PETG) | 28,3 × 33,9 × 10,6 mm · 1,7 g | Valva 2 (semilunar simplificada, barril de bisagra y cola de mando)  |
| Leaflet_3 | 1 | impresa (PETG) | 28,3 × 33,9 × 10,6 mm · 1,7 g | Valva 3 (semilunar simplificada, barril de bisagra y cola de mando)  |
| Link_Normal | 4 | impresa (PETG) | 6,0 × 32,0 × 3,0 mm · 0,7 g | Biela rígida (modo normal). 3 + 1 de repuesto  |
| Link_LostMotion | 2 | impresa (PETG) | 6,0 × 37,5 × 3,0 mm · 0,7 g | Biela con recorrido perdido (apertura restringida / asimétrica). 1 marca  |
| Link_LostMotion_IC | 1 | impresa (PETG) | 6,0 × 36,1 × 3,0 mm · 0,7 g | Biela corta con recorrido perdido (cierre incompleto 12°). 2 marcas  |
| Opening_Stop_84 | 3 | impresa (PETG) | 11,0 × 12,0 × 4,4 mm · 0,4 g | Tope de seguridad (84°) — se usa en modo normal y cierre incompleto  |
| Opening_Stop_60 | 1 | impresa (PETG) | 11,0 × 12,0 × 7,2 mm · 0,5 g | Tope intercambiable 60°  |
| Opening_Stop_45 | 1 | impresa (PETG) | 11,0 × 12,0 × 8,3 mm · 0,5 g | Tope intercambiable 45°  |
| Actuator_Plate | 1 | impresa (PETG) | 66,6 × 69,5 × 13,0 mm · 13,7 g | Plato actuador (corredera) con bujes, orejetas y horquilla  |
| Pushrod | 1 | impresa (PETG) | 5,6 × 35,6 × 3,0 mm · 0,7 g | Empujador servo → plato  |
| Column | 3 | impresa (PETG) | 8,0 × 8,0 × 56,1 mm · 3,3 g | Columna guía y soporte del anillo (insertos M3 en ambos extremos)  |
| Column_Spacer | 2 | impresa (PETG) | 12,0 × 12,0 × 2,0 mm · 0,3 g | Arandela de 2 mm entre columna y anillo (columnas 2 y 3)  |
| H0_Holder | 1 | impresa (PETG) | 19,5 × 12,0 × 15,3 mm · 0,9 g | Soporte del sensor H0 (DRV5055A2) sobre el imán del plato; reemplaza la arandela de la columna 1  |
| Cable_Clip | 3 | impresa (PETG) | 16,8 × 11,8 × 6,0 mm · 0,7 g | Pinza de cables a presión en cada columna (bajo el recorrido del plato)  |
| Piezo_Mount | 2 | impresa (PETG) | 22,0 × 30,0 × 4,0 mm · 3,0 g | Soporte del disco piezoeléctrico (Ø15; adaptador para Ø12). P1 en el anillo, P2 en el soporte del servo NO DEFINITIVA |
| Piezo_Cover | 2 | impresa (PETG) | 22,0 × 30,0 × 3,4 mm · 2,2 g | Tapa protectora del piezo (no lo presiona) NO DEFINITIVA |
| Piezo_Adapter_12mm | 1 | impresa (PETG) | 15,2 × 15,2 × 0,6 mm · 0,0 g | Anillo adaptador para disco Ø12 NO DEFINITIVA |
| MEMS_Mount | 1 | impresa (PETG) | 36,0 × 30,0 × 17,7 mm · 4,6 g | ALTERNATIVA: escuadra y portaplaca del INMP441 sobre el anillo (comparar con MEMS_Stand) NO DEFINITIVA |
| MEMS_Stand | 1 | impresa (PETG) | 44,0 × 32,0 × 76,6 mm · 20,4 g | Soporte independiente del micrófono M1 (configuración inicial recomendada): ranura radial ±8 mm y pivote de inclinación  |
| MEMS_Stand_Holder | 1 | impresa (PETG) | 28,9 × 18,9 × 7,0 mm · 1,1 g | Portaplaca del INMP441 con lengüeta de pivote NO DEFINITIVA |
| Servo_Mount | 1 | impresa (PETG) | 40,2 × 35,0 × 22,0 mm · 12,0 g | Soporte del MG90S con escuadras y almohadilla P2 NO DEFINITIVA |
| Electronics_Tray | 1 | impresa (PETG) | 79,4 × 103,8 × 9,6 mm · 35,6 g | Bandeja de la placa perforada 70×90 (ESP32 en zócalos hembra, antena libre, USB accesible) NO DEFINITIVA |
| Tray_Clamp | 2 | impresa (PETG) | 8,0 × 103,8 × 3,0 mm · 2,9 g | Barra de sujeción de la placa perforada (sin perforar ni flexionar) NO DEFINITIVA |
| Angle_Scale | 1 | impresa (PETG) | 92,7 × 70,0 × 2,0 mm · 16,4 g | Transportador 0–90° para medir la valva 1 con cámara lateral  |
| Base | 1 | impresa (PETG) | 200,0 × 180,0 × 6,0 mm · 270,4 g | Base modular 200 × 180 mm con insertos M3 y ranuras para bridas NO DEFINITIVA |
| Tolerance_Coupon | 1 | impresa (PETG) | 66,0 × 46,0 × 6,5 mm · 23,9 g | Probeta v2: ejes libres y a presión, pilotos, insertos e imanes  |
| ESP32 DevKit V1 (ESP32-WROOM-32) | 1 | comprada | | Medidas por confirmar (doc 02) |
| Servo MG90S + horns | 1 | comprada | | Medidas por confirmar |
| Fuente 5 V 3 A con conector de tornillo o jack | 1 | comprada | |  |
| Imán neodimio N42 Ø4×2 mm axial | 5 | comprada | | +2 de repuesto |
| Imán neodimio N42 Ø3×2 mm axial | 2 | comprada | | +1 de repuesto |
| TI DRV5055A1QLPG (TO-92) | 4 | comprada | | H1–H3 (+1) |
| TI DRV5055A2QLPG (TO-92) | 2 | comprada | | H0 (+1) |
| INMP441 (placa de módulo) | 1 | comprada | | Fotos por confirmar |
| Disco piezoeléctrico Ø15 (o Ø12 con adaptador) | 3 | comprada | | P1, P2 (+1) |
| Microchip MCP6004 (DIP-14 o SOIC + adaptador) | 1 | comprada | | 4 amplificadores |
| Microchip MCP1700-3302 (TO-92) | 1 | comprada | | 3V3_A |
| INA219 (módulo, shunt 0,1 Ω) | 1 | comprada | | opcional, recomendado |
| BAT54S | 2 | comprada | | protección piezo |
| AO3401A (SOT-23) + 10 kΩ | 1 | comprada | | polaridad invertida |
| PTC 2,5 A retención | 1 | comprada | |  |
| TVS SMBJ5.0A | 1 | comprada | |  |
| Capacitor 1000 µF 10 V bajo ESR | 1 | comprada | |  |
| Capacitores 100 nF cerámicos | 12 | comprada | | desacoplo y RC Hall |
| Capacitores 15 nF, 7,5 nF (o 6,8 + 0,68), 2,2 nF C0G | 2 | comprada | | por canal piezo |
| Capacitor 10 µF | 2 | comprada | | VBIAS, regulador |
| Resistencias 1 MΩ, 10 kΩ, 12 kΩ, 36 kΩ, 150 kΩ, 100 kΩ, 1 kΩ, 220 Ω, 330 Ω, 100 Ω, 33 Ω (1 %) | 1 | comprada | | surtido según esquema |
| Placa perforada 7×9 cm | 1 | comprada | |  |
| Tiras de zócalo hembra 2,54 mm | 2 | comprada | | según cantidad de pines del ESP32 |
| Bornera de tornillo 2 vías | 2 | comprada | | 5 V servo |
| Parada de emergencia de 2 contactos (NC + NA) o pulsador | 1 | comprada | |  |
| LED + 330 Ω | 1 | comprada | | sincronización |
| Cable blindado 2 hilos (piezo) | 2 | comprada | | ≈ 40 cm c/u |
| Cable de 3 hilos fino (Hall) | 4 | comprada | | ≈ 30 cm |
| Cable plano 6 hilos (micrófono) | 1 | comprada | | ≤ 20 cm |
| Varilla de LATÓN Ø2 mm | 1 | comprada | | 3 × 56 mm (ejes) + 3 × 9 mm (pasadores) |
| Tornillo M2×20 de LATÓN + tuerca M2 | 3 | comprada | | topes |
| Tornillo M2×10 inox A2 + tuerca | 3 | comprada | | biela–plato |
| Tornillo M2×14 + tuerca | 1 | comprada | | horquilla |
| Tornillo M2×10 inox | 6 | comprada | | almohadillas |
| Tornillo M3×10 | 5 | comprada | | columnas, soporte M1 |
| Tornillo M3×30 | 3 | comprada | | anillo |
| Tornillo M3×12 + casquillo Ø4×Ø3,2×5,5 + 2 arandelas de goma | 4 | comprada | | soporte del servo |
| Tornillo M3×6 | 4 | comprada | | bandeja |
| Tornillo M3×8 | 4 | comprada | | barras de sujeción |
| Tornillo M3×16 + tuerca autoblocante | 1 | comprada | | pivote M1 |
| Inserto termofijado M3 (L 5,7) | 20 | comprada | | columnas, base, bandeja |
| Inserto termofijado M2 (L 3–4) | 8 | comprada | | almohadillas |
| Patas de goma adhesivas Ø10 | 4 | comprada | |  |
| Grasa PTFE, cianoacrilato, silicona neutra, cinta doble faz fina, bridas | 1 | comprada | |  |
