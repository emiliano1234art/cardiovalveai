# 10 · Pendientes de medición o ensayo físico

> CardioVal AI · revisión **v2** · prototipo académico de banco **sin fluido**. No es un dispositivo médico ni de diagnóstico.
> **[CÁLCULO]** verificado por cálculo · **[SIM]** inspección o simulación geométrica · **[SW]** compilado o probado en software · **[FÍSICO]** pendiente de ensayo físico

- Medidas del ESP32, servo, horn, INMP441, piezo y placa perforada (doc 02) → regenerar piezas afectadas.
- Diámetros reales de agujeros, ajustes a presión e insertos (probeta).
- Respuesta real de los Hall (campo de los imanes comprados, posición real) → calibración; monotonía confirmada.
- Ruido real del ADC y de los Hall; ganancia adecuada de los canales piezo; saturación.
- Funcionamiento del firmware en la placa (no probado en hardware): tasas reales, pérdidas, eventos, paradas, PWM aceptado por el servo a 3,3 V.
- Corriente pico y de bloqueo del servo; margen de par real; fricción del plato; efecto cajón.
- Efecto de las gomas antivibración; resonancias de soportes (micrófono, P1, P2).
- Si P1, P2 o M1 permiten identificar eventos (doc 08 §5).
- Repetibilidad del montaje de sensores y de la calibración.
- Todos los criterios de aceptación del doc 09.
