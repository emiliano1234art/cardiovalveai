# Informe de validación digital v2

> CardioVal AI · revisión **v2** · prototipo académico de banco **sin fluido**. No es un dispositivo médico ni de diagnóstico.
> **[CÁLCULO]** verificado por cálculo · **[SIM]** inspección o simulación geométrica · **[SW]** compilado o probado en software · **[FÍSICO]** pendiente de ensayo físico

Generado: 2026-10-22 23:35. Todo lo de este informe es **[SIM] o [SW]**: se ejecutó sobre los archivos entregados. No reemplaza ningún ensayo físico.

## Mallas de impresión [SW]
28 piezas imprimibles; con problemas: ninguna (cerradas, orientación coherente, un cuerpo, z mín. = 0, caben en 220 × 220 × 250).

## Interferencias [SIM]
125 poses (25 posiciones del servo × 5 modos), todas las piezas, imanes, pasadores, tornillería y cables: **0 interferencias**.
Contactos de diseño: Actuator_Plate × Plate_Fasteners_Reference, Link_1 × Plate_Fasteners_Reference, Link_2 × Plate_Fasteners_Reference, Link_3 × Plate_Fasteners_Reference.

## Holguras mínimas [SIM]
| Par | mm | modo |
|---|---|---|
| Leaflet_1 ↔ Stop_1 | 0,00 | RESTRINGIDA_60 |
| Link_1 ↔ Leaflet_1 | 0,30 | NORMAL |
| Actuator_Plate ↔ Column_1 | 0,30 | ASIMETRICO |
| Pushrod ↔ Servo_Horn_Reference | 0,30 | ASIMETRICO |
| Leaflet_1 ↔ Leaflet_2 | 0,49 | ASIMETRICO |
| Leaflet_2 ↔ Leaflet_3 | 0,49 | ASIMETRICO |
| Pushrod ↔ Actuator_Plate | 0,50 | NORMAL |
| Actuator_Plate ↔ H0_Holder | 0,60 | NORMAL |
| Link_1 ↔ Valve_Ring | 0,60 | NORMAL |
| Leaflet_1 ↔ Valve_Ring | 0,67 | NORMAL |
| Leaflet_1 ↔ Hall_Sensors_Reference | 1,50 | NORMAL |
| Magnet_1 ↔ Hall_Sensors_Reference | 1,66 | CIERRE_INCOMPLETO |
| Cable_Routes_Reference ↔ Actuator_Plate | 2,58 | NORMAL |
| Pushrod ↔ Servo_MG90S_Reference | 2,82 | NORMAL |
| Actuator_Plate ↔ Ring_Fasteners_Reference | 2,92 | ASIMETRICO |
| Plate_Magnet ↔ Hall0_Reference | 3,23 | ASIMETRICO |
| Link_1 ↔ Stop_1 | 3,89 | CIERRE_INCOMPLETO |
| Cable_Routes_Reference ↔ Column_1 | 4,50 | ASIMETRICO |
| Leaflet_1 ↔ MEMS_Mount | 5,00 | CIERRE_INCOMPLETO |

## Montaje y acceso [SIM]
| Comprobación | Resultado |
|---|---|
| Eje Ø2 de la valva 1: inserción desde el exterior (camino libre) | ✔ |
| Tornillo M3 de la columna 1: acceso vertical desde arriba | ✔ |
| Tornillo M2 de latón del tope 1: acceso vertical desde arriba | ✔ |
| Sensor Hall H1: inserción vertical desde arriba | ✔ |
| Tornillo M2 de la almohadilla 1a: acceso radial | ✔ |
| Tornillo M2 de la almohadilla 1b: acceso radial | ✔ |
| Pasador Ø2 cola–biela de la valva 1: agujeros alineados | ✔ |
| Tornillo M2 biela–plato de la valva 1: agujeros alineados | ✔ |
| Eje Ø2 de la valva 2: inserción desde el exterior (camino libre) | ✔ |
| Tornillo M3 de la columna 2: acceso vertical desde arriba | ✔ |
| Tornillo M2 de latón del tope 2: acceso vertical desde arriba | ✔ |
| Sensor Hall H2: inserción vertical desde arriba | ✔ |
| Tornillo M2 de la almohadilla 2a: acceso radial | ✔ |
| Tornillo M2 de la almohadilla 2b: acceso radial | ✔ |
| Pasador Ø2 cola–biela de la valva 2: agujeros alineados | ✔ |
| Tornillo M2 biela–plato de la valva 2: agujeros alineados | ✔ |
| Eje Ø2 de la valva 3: inserción desde el exterior (camino libre) | ✔ |
| Tornillo M3 de la columna 3: acceso vertical desde arriba | ✔ |
| Tornillo M2 de latón del tope 3: acceso vertical desde arriba | ✔ |
| Sensor Hall H3: inserción vertical desde arriba | ✔ |
| Tornillo M2 de la almohadilla 3a: acceso radial | ✔ |
| Tornillo M2 de la almohadilla 3b: acceso radial | ✔ |
| Pasador Ø2 cola–biela de la valva 3: agujeros alineados | ✔ |
| Tornillo M2 biela–plato de la valva 3: agujeros alineados | ✔ |
| Tornillo M2 biela–plato de la valva 1: destornillador por la cabeza (−y), plato abajo, transportador retirado | ✔ |
| Tornillo M2 biela–plato de la valva 1: llave de tubo 4 mm por la tuerca (+y), plato abajo, transportador retirado | ✔ |
| Tornillo M2 biela–plato de la valva 2: destornillador por la cabeza (−y), plato abajo, transportador retirado | ✔ |
| Tornillo M2 biela–plato de la valva 2: llave de tubo 4 mm por la tuerca (+y), plato abajo, transportador retirado | ✔ |
| Tornillo M2 biela–plato de la valva 3: destornillador por la cabeza (−y), plato abajo, transportador retirado | ✔ |
| Tornillo M2 biela–plato de la valva 3: llave de tubo 4 mm por la tuerca (+y), plato abajo, transportador retirado | ✔ |
| Tornillo M2 horquilla–empujador: agujeros alineados | ✔ |
| Tornillo M2 oreja izq del servo: acceso con destornillador | ✔ |
| Tornillo M2 oreja der del servo: acceso con destornillador | ✔ |
| Tornillo M2 de la almohadilla P2a: acceso | ✔ |
| Tornillo M2 de la almohadilla P2b: acceso | ✔ |
| Tornillo M3 1 del soporte M1: acceso vertical | ✔ |
| Tornillo M3 2 del soporte M1: acceso vertical | ✔ |
| Tornillo M3 bandeja→base (18,22): acceso vertical sin la placa | ✔ |
| Tornillo M3 bandeja→base (61,22): acceso vertical sin la placa | ✔ |
| Tornillo M3 bandeja→base (18,82): acceso vertical sin la placa | ✔ |
| Tornillo M3 bandeja→base (61,82): acceso vertical sin la placa | ✔ |
| Tornillo M3 barra de sujeción (4,3): acceso vertical | ✔ |
| Tornillo M3 barra de sujeción (75,3): acceso vertical | ✔ |
| Tornillo M3 barra de sujeción (4,100): acceso vertical | ✔ |
| Tornillo M3 barra de sujeción (75,100): acceso vertical | ✔ |
| Conector USB del ESP32: enchufable desde +y sin obstáculos (referencia) | ✔ |

## Cálculos [CÁLCULO]
Servo: {"plate_and_links_g": 16.5, "force_N": 1.75, "torque_Nmm": 14.0, "torque_kgcm": 0.143, "mg90s_stall_kgcm_unverified": 1.8, "margin_x": 12.6}. Efecto cajón: Con cargas simétricas (3 valvas iguales) la resultante pasa por el centro: sin riesgo. Si UNA valva se traba, la resultante se desplaza hasta ≈ 27.1 mm: supera 17.1 mm en seco (puede trabarse el plato) y queda por debajo de 40.0 mm lubricado. Lubricar y dejar activa la detección de atasco (H0) del firmware.
