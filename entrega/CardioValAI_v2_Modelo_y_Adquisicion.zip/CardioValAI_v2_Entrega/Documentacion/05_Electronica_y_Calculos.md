# 05 · Electrónica, tabla de conexiones y cálculos

> CardioVal AI · revisión **v2** · prototipo académico de banco **sin fluido**. No es un dispositivo médico ni de diagnóstico.
> **[CÁLCULO]** verificado por cálculo · **[SIM]** inspección o simulación geométrica · **[SW]** compilado o probado en software · **[FÍSICO]** pendiente de ensayo físico

Esquemas: `Electronica/Hoja1_Alimentacion_Servo`, `Hoja2_Canal_Piezo`, `Hoja3_Hall_MEMS` (SVG y PNG), generados con `hardware/electronica/esquema.py`.
Fuentes de datos: hojas de datos de Espressif (ESP32 Datasheet / Technical Reference Manual / ESP-IDF v5.4 Programming Guide: ADC continuo, I2S, LEDC),
TI DRV5055 (SBAS640), TDK InvenSense INMP441 (DS-INMP441), Microchip MCP6004 (DS20001733) y MCP1700 (DS20001826), TI INA219 (SBOS448), Nexperia BAT54S.
**Los valores marcados VERIFICAR dependen de lo comprado.** Ningún circuito fue armado ni medido todavía [FÍSICO].

## 1. Tabla pin a pin (ESP32 DevKit V1, 30 pines — VERIFICAR con la serigrafía de su placa)

| Pin | Señal | Dirección | Periférico | Nota |
|---|---|---|---|---|
| GPIO36 (VP) | H1 Hall valva 1 | entrada analógica | ADC1_CH0 | Solo entrada; sin pull |
| GPIO39 (VN) | H2 Hall valva 2 | entrada analógica | ADC1_CH3 | Solo entrada |
| GPIO32 | H3 Hall valva 3 | entrada analógica | ADC1_CH4 |  |
| GPIO33 | H0 Hall del plato | entrada analógica | ADC1_CH5 |  |
| GPIO34 | P1 piezo anillo (acondicionado) | entrada analógica | ADC1_CH6 | Solo entrada |
| GPIO35 | P2 piezo soporte servo (acondicionado) | entrada analógica | ADC1_CH7 | Solo entrada |
| GPIO26 | INMP441 SCK | salida | I2S1 BCLK | 33 Ω en serie |
| GPIO25 | INMP441 WS | salida | I2S1 WS |  |
| GPIO27 | INMP441 SD | entrada | I2S1 DIN |  |
| GPIO18 | PWM servo | salida | LEDC canal 0, 50 Hz, 16 bits | 220 Ω serie + 10 kΩ a GND |
| GPIO19 | LED de sincronización | salida |  | 330 Ω + LED a GND |
| GPIO23 | Parada por software | entrada | pull-up interno | contacto NA a GND |
| GPIO21 / GPIO22 | INA219 SDA / SCL | I2C | I2C0 400 kHz | pull-up del módulo |
| GPIO2 | LED azul de la placa | salida |  | pin de arranque: sin carga externa |
| GPIO1 / GPIO3 | UART0 (USB) | — | protocolo binario | reservado |
| 3V3 | INMP441, pull-ups | alimentación |  | regulador de la placa |
| VIN / 5V | MCP1700 → 3V3_A (Hall + MCP6004) | alimentación |  | NUNCA conectar +5V_SERVO |
| GND | masa | — |  | unión a la estrella ★ |
| No usar | GPIO6–11 (flash), GPIO12 (arranque), GPIO0/5/15 (arranque), ADC2 (no admite DMA) |  |  |  |

## 2. Alimentación y masas
- **Servo:** fuente externa de 5 V **≥ 2 A (3 A recomendado)**. El MG90S puede pedir picos de varios cientos de mA al arrancar y más al bloquearse (dato no verificado:
  se mide con el INA219). PTC de 2,5 A, P-MOS AO3401A contra polaridad invertida (caída ≈ 0,1 V a 2 A), TVS SMBJ5.0A, 1000 µF de bajo ESR + 100 nF en el conector.
- **ESP32:** solo por USB de la computadora. **+5V_SERVO nunca se conecta a VIN/5V**: así no hay realimentación entre la fuente y el USB; solo se comparte GND en un punto.
- **Regulador analógico** MCP1700-3302 (desde el 5 V del USB): 3V3_A para los 4 Hall (≈ 6 mA c/u) y el MCP6004 — separa el ruido digital del ESP32 de los sensores
  ratiométricos.
- **Masa en estrella** ★ en la placa perforada: retorno del servo con su propio cable; masas analógicas (Hall, piezo) juntas cerca del MCP6004 y unidas a ★ por un solo punto.
- **Parada de emergencia:** contacto NC en la línea del servo (corte físico) + contacto NA a GPIO23 (aviso al firmware).
- **Señal PWM:** 3,3 V; el MG90S suele aceptarla (VERIFICAR). Si no responde bien, 74AHCT125 alimentado a 5 V. 10 kΩ a GND para que no haya pulsos al arrancar.

## 3. Canal piezoeléctrico (×2) [CÁLCULO]
- **Impedancia de entrada:** Rb = 1 MΩ a VBIAS en paralelo con la entrada CMOS del MCP6004 (pA). Con Cp ≈ 10 nF (VERIFICAR) → paso alto 1/(2π·1 MΩ·10 nF) ≈ 16 Hz.
- **Descarga:** la misma Rb descarga el disco (τ = Rb·Cp ≈ 10 ms); no quedan cargas tras desconectar.
- **Limitación de corriente + protección ±:** Rs = 10 kΩ en serie y BAT54S (dos Schottky) recortando el nodo B a −0,3 V … 3,6 V. Un disco golpeado puede dar decenas de voltios:
  con 50 V la corriente queda en (50 − 3,6)/10 k ≈ 4,6 mA (BAT54S: 200 mA máx.), y la entrada del amplificador nunca sale de los rieles. Un zener solo no limita la corriente
  ni protege el lado negativo.
- **Polarización:** VBIAS = 3,3·100k/250k = 1,32 V (10 µF de desacoplo), centrado en el rango lineal del ADC con 12 dB (≈ 0,15–2,45 V).
- **Ganancia seleccionable** (puente J1): 1, 2,2 o 4,6 alrededor de VBIAS. Se elige la mayor que no sature en el ensayo 6.
- **Antialias:** Sallen-Key Butterworth de 2.º orden, R = 10 kΩ, C1 = 15 nF, C2 = 7,5 nF → fc = 1/(2π·10k·√(15n·7,5n)) ≈ 1,5 kHz, Q = 0,707. El ADC muestrea cada
  canal piezo a 16 kS/s; lo que cae arriba de 13 kHz (y se replegaría en la banda útil 0–3 kHz) queda atenuado ≥ 37 dB; después un FIR digital (31 coef.) lleva a 8 kS/s.
- **Salida al ADC:** 100 Ω + 2,2 nF (reserva de carga para el muestreo del SAR).
- **Prueba previa SIN ESP32:** (1) con multímetro, VBIAS = 1,32 ± 0,05 V y salida de U1B igual a VBIAS; (2) con osciloscopio o el ADC de otro equipo, golpecito con el dedo en
  el soporte: la salida debe quedar dentro de 0,15–2,45 V; (3) aplicar ±10 V a la entrada a través del disco desconectado y una fuente limitada a 10 mA: la salida no debe
  pasar de 0–3,3 V. Recién entonces se conecta a GPIO34/35.

## 4. Sensores Hall [CÁLCULO]
DRV5055A1 (H1–H3, 60 mV/mT) y A2 (H0, 30 mV/mT) a 3,3 V; 100 nF junto a cada sensor; salida con RC 1 kΩ/100 nF (fc ≈ 1,6 kHz) antes del ADC. La salida es ratiométrica
(VCC/2 sin campo): por eso 3V3_A propio. Los imanes se orientan para que la salida **baje** (≈ 0,8–1,65 V), dentro del rango lineal del ADC.

## 5. Micrófono INMP441
3,3 V con 100 nF; L/R a GND; I2S1 maestro a 16 kHz, palabra de 32 bits (dato de 24 bits), BCLK = 64·fs = 1,024 MHz. Cable ≤ 20 cm con GND entre SCK y SD, lejos del servo.

## 6. Recursos del ESP32 clásico y conflictos [CÁLCULO + SW]
- El **ADC continuo (DMA) usa el periférico I2S0** en el ESP32 clásico → el micrófono va en **I2S1**. Verificado en el código de ESP-IDF v5.4.1 (`adc_dma.c` reserva I2S0).
- **ADC2 no admite DMA** (y choca con Wi-Fi) → los 6 canales analógicos están en ADC1.
- **Muestreo secuencial, no simultáneo:** un solo ADC recorre el patrón P1 H1 P2 H2 P1 H3 P2 H0 a 64 kS/s → 15,625 µs entre conversiones; P1 y P2 quedan desfasados
  31,25 µs (constante, informado en la trama INFO). Hall: 8 kS/s por canal → suma de 8 → 1 kS/s.
- **LEDC** (PWM del servo) y **esp_timer** (marcas de tiempo en µs) son independientes del ADC/I2S. Las marcas se toman en la interrupción de fin de cada búfer DMA.
- **¿Alcanza el ADC interno?** Sí para el objetivo principal: los Hall son lentos y se calibran (la no linealidad del ADC queda dentro de la calibración); para piezo
  alcanza como señal complementaria (≈ 9–10 bits efectivos, dato de la documentación de Espressif; se mide el ruido en el ensayo 4). Para audio se usa el micrófono digital.
  Si más adelante se necesitara mejor calidad de vibración: ADC externo SPI (p. ej. MCP3208, 12 bits, 100 kS/s) o un códec de audio estéreo — no se incluye por ahora.

## 7. Ancho de banda del enlace USB-serie [CÁLCULO]

| Flujo | kB/s |
|---|---|
| P1+P2 (8 kS/s, 16 bits) | 33,56 |
| H0–H3 (1 kS/s, 16 bits) | 8,78 |
| Audio 8 kHz 16 bits | 16,78 |
| Comando del servo (200 Hz) | 5,20 |
| INA219 (500 Hz) | 1,25 |
| Estado (2 Hz) + eventos (≈ 20/s) | 0,64 |
| **Total (audio 8 kHz)** | **66,2** |

A 921 600 baudios (8N1) caben 92,2 kB/s → uso 72 %. Con audio a 16 kHz serían 83,0 kB/s (90 %): el firmware
solo lo permite con ≥ 1,5 Mbaudios (posible con CH340/CP2102N; VERIFICAR el chip de su placa). Datos en binario con CRC, no en texto.
