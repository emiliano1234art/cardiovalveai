# 02 · Medidas y fotos que bloquean decisiones (lista única)

> CardioVal AI · revisión **v2** · prototipo académico de banco **sin fluido**. No es un dispositivo médico ni de diagnóstico.
> **[CÁLCULO]** verificado por cálculo · **[SIM]** inspección o simulación geométrica · **[SW]** compilado o probado en software · **[FÍSICO]** pendiente de ensayo físico

Mientras falten, las piezas afectadas quedan **paramétricas y NO definitivas** (marcadas en la lista de materiales).

| # | Qué enviar | Para qué se usa | Pieza / archivo afectado |
|---|---|---|---|
| 1 | **ESP32 DevKit V1:** foto superior e inferior junto a una regla; largo y ancho de la placa; cantidad total de pines (30 o 38); separación entre las dos hileras (centro a centro); posición del USB y de los botones EN/BOOT; texto del chip USB (CP2102 o CH340) | Zócalos y bandeja; acceso USB/EN/BOOT; zona de antena; velocidad del puerto serie (921 600 vs. ≥ 1,5 M baudios) | `Electronics_Tray`, `Perfboard_ESP32_Reference`, `config.ESP32_*`, firmware `CVAI_BAUD` |
| 2 | **Servo:** marca/modelo exacto; largo, ancho y alto del cuerpo; distancia entre agujeros de las orejas; altura de la cara inferior de las orejas; posición del eje respecto del extremo | Soporte del servo y altura de todo el conjunto | `ServoDims` en `config.py` |
| 3 | **Horn que se usará:** distancia del centro del eje al agujero elegido (mm) y diámetro de ese agujero | Barrido y comandos (tabla en 04) | `SERVO.horn_r` |
| 4 | **Placa INMP441:** foto de ambas caras; diámetro o lados; espesor; dónde está el agujero del puerto acústico (cara con el micrófono o cara opuesta); orden de los pines | Portaplaca y orientación del puerto | `MEMS_BOARD`, `MEMS_Stand_Holder` |
| 5 | **Discos piezoeléctricos:** diámetro del disco metálico, diámetro de la cerámica, espesor total; si es posible, capacidad medida con multímetro (nF) | Asiento del disco y frecuencia del paso alto (Rb·Cp) | `PIEZO_D`, `PIEZO_T`, Hoja 2 |
| 6 | **Placa perforada** (si ya la tienen): medidas | Bandeja | `PERFBOARD` |

Con 1–3 se cierran las piezas que bloquean el armado; 4–6 afinan soportes y filtros.
