# 09 · Plan de validación física (progresivo)

> CardioVal AI · revisión **v2** · prototipo académico de banco **sin fluido**. No es un dispositivo médico ni de diagnóstico.
> **[CÁLCULO]** verificado por cálculo · **[SIM]** inspección o simulación geométrica · **[SW]** compilado o probado en software · **[FÍSICO]** pendiente de ensayo físico

Los criterios son **objetivos propuestos**, no resultados. Cada ensayo se registra con `cvai_record.py` (sesiones reales: `fuente` = ESP32) y video.

| Ensayo | Procedimiento | Criterio de aceptación propuesto |
|---|---|---|
| 1. Probeta de tolerancias | Imprimir `Tolerance_Coupon`; probar ejes de latón (libre y a presión), insertos M2/M3, imanes Ø4 y Ø3, pilotos. | Eje libre gira sin juego visible; a presión no sale tirando con la mano; insertos a ras y sin girar; imanes entran con presión leve. Anotar diámetros elegidos y actualizar `config.py`. |
| 2. Movimiento manual sin servo | Mecanismo armado, empujador desconectado; mover el plato a mano en toda la carrera, en cada modo. | Sin trabas ni roces audibles; las 3 valvas van de 0° a 80° (normal); fuerza para mover el plato medida con dinamómetro/balanza (anotar; objetivo propuesto < 1 N). |
| 3. Límites de apertura y cierre | Video lateral con `Angle_Scale` + foto superior, plato en los extremos. | Cerrada: 0 ± 2°, separación entre bordes visible ≈ 1 mm; abierta: 80 ± 3°; topes alternativos 60/45 ± 3°; valva sobre su tope en los modos alterados. |
| 4. Electrónica y adquisición (sin mecanismo) | Prueba previa del acondicionamiento (doc 05); luego ESP32 + sensores en banco; 10 min con `STREAM ON`. | VBIAS 1,32 ± 0,05 V; Hall estáticos dentro de ±15 % de lo calculado; 0 errores CRC, 0 saltos, 0 desbordes; ruido Hall ≤ 0,5° equivalente; calibración Hall con error ≤ 1°. |
| 5. Ruido ambiente, mecanismo detenido | Servo sin pulsos, 2 min de registro en el laboratorio real. | Niveles de referencia de P1, P2 y M1 (se registran, no hay umbral); sin saturación. |
| 6. Servo con el empujador desconectado | `SET stall 0`; ciclos con el horn libre. Repetir con y sin gomas. | Firma del servo en P1/P2/M1; coherencia y función de transferencia P2→P1; pico de corriente (INA219) < 70 % de la capacidad de la fuente. |
| 7. Mecanismo completo, modo normal | 30 ciclos, 3 sesiones, video sincronizado con el LED. | Meseta 80 ± 3° en las 3 valvas, residual ≤ 2°, diferencia entre valvas ≤ 3°, CV de duraciones < 5 %, ≥ 95 % de ciclos «equivalentes». |
| 8. Una alteración conocida a la vez | R60, R45, cierre incompleto, asimétrico; 30 ciclos cada uno, con 10 ciclos normales antes y después. | El 100 % de los ciclos alterados se marcan con el motivo correcto; ≥ 95 % de los normales quedan «equivalentes». |
| 9. Desmontar y volver a montar sensores | Retirar y volver a colocar piezo, micrófono y (si corresponde) Hall; repetir 7. | Mesetas dentro de ±2° de antes; diferencias de nivel de P1/P2/M1 documentadas (repetibilidad del montaje). |
| 10. Posiciones y velocidades | t_open/t_close = 200, 400, 800 ms; P1 en las 3 almohadillas; M1 a 44/52/60 mm y en la escuadra. | Métricas coherentes con la velocidad; selección de ubicación según doc 03. |
| 11. Video vs. señales | Comparar ángulos y tiempos del video (≥ 60 cuadros/s) con Hall, piezo y audio. | Ángulo Hall vs. video: error máx. ≤ 3°, RMS ≤ 1,5°; tiempos de evento: diferencia ≤ 1 cuadro + 10 ms. Evaluar si piezo/audio marcan eventos (doc 08 §5). |
| 12. Variabilidad normal | ≥ 3 sesiones × 30 ciclos en días distintos, mismo modo normal. | Mediana y MAD por métrica entre sesiones → fijar los umbrales definitivos. Base para cualquier análisis posterior. |

**Video:** cámara lateral (valva 1 + `Angle_Scale`) y superior; ≥ 60 cuadros/s; el LED de sincronización debe verse. El tiempo de cada encendido del LED está en los
eventos `SYNC_LED_ON`: el desfase y la deriva cámara–ESP32 se estiman con varios encendidos.

**Golpes artificiales:** no se usan para «mostrar» detección. Solo se admite un impulso identificado y justificado (p. ej. péndulo de altura conocida) para caracterizar la
transmisión P1/P2 en el ensayo 6, rotulado como tal en `session.json` (`--nota`).

**¿Hay eventos acústicos/vibratorios distinguibles?** Se responde con los ensayos 6, 7 y 11 (doc 08 §5). Si no los hay, la medición de apertura/cierre queda a cargo de los Hall
(ya incluidos) y del video; no se necesita otra medición adicional para el objetivo principal.
