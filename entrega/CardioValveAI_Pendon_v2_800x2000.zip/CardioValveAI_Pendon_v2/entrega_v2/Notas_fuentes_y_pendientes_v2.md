# CardioValveAI · Pendón v2: fuentes, estado y datos por confirmar

Rediseño con la dirección de arte del póster de referencia (fondo crema, un tono dominante, título gigante, franja condensada,
modelo protagonista monocromo con lupas circulares, ciclo con línea punteada, miniaturas redondas y caja comparativa).
El contenido, el rigor y las fuentes son los mismos de la versión 1 (`pendon/entrega/Notas_fuentes_y_pendientes.md`).

## Archivos
- `CardioValveAI_Pendon_v2_800x2000_sin_sangrado.pdf` — 800 × 2000 mm exactos.
- `CardioValveAI_Pendon_v2_800x2000_sangrado10mm.pdf` — 820 × 2020 mm, TrimBox 800 × 2000 mm.
- `../CardioValveAI_Pendon_v2_800x2000.svg` — editable (1 unidad = 1 mm), capas por sección, imágenes en `imagenes/p2_*.png`.
- `Texto_final_pendon_v2.md` — texto separado del diseño.

## Imágenes
Renders del CAD v4 (sin texto grabado), pasados a un solo tono verde azulado. El imán conserva el coral (acento) para que se distinga.
No hay fotografías del prototipo. Lupas: vistas cercanas renderizadas aparte (no ampliaciones de la imagen grande).
Las cifras (90 mm, 3 × 3, 0°–80°) son medidas de diseño del CAD v4, no mediciones.

| Imagen | Píxeles | Tamaño visible | Resolución efectiva |
|---|---|---|---|
| img_protagonista | 3303 × 3465 px | 500 mm | **168 ppp** |
| img_lupa_valva | 1152 × 1152 px | 128 mm | **229 ppp** |
| img_lupa_hall | 1152 × 1152 px | 128 mm | **229 ppp** |
| img_lupa_iman | 1152 × 1152 px | 128 mm | **229 ppp** |
| img_lupa_servo | 1152 × 1152 px | 128 mm | **229 ppp** |
| img_superior_cerrada | 893 × 878 px | 80 mm | **284 ppp** |
| img_superior_30 | 893 × 878 px | 80 mm | **284 ppp** |
| img_superior_60 | 893 × 878 px | 80 mm | **284 ppp** |
| img_superior_abierta | 893 × 878 px | 80 mm | **284 ppp** |
| img_paso1 | 960 × 960 px | 88 mm | **277 ppp** |
| img_paso2 | 960 × 960 px | 88 mm | **277 ppp** |

## Tipografías
Inter / Inter Display (título y texto) y Barlow Condensed (franja, títulos de sección, cifras y rótulos). Dos familias, ambas SIL OFL (`fuentes/`).

## Datos por confirmar antes de imprimir
1. Estado del prototipo el día de la feria («Hoy · prototipo»: mueve tres valvas y registra una señal por valva). Si aún no funciona, cambiar a «diseñado para…».
2. Redacción de la pregunta de investigación y del enfoque funcional, con el profesor guía.
3. Imprenta: sangrado (se entregan 10 mm), zona oculta del soporte (el contenido termina a 1846 mm; banda de invitación 1880–1946 mm), perfil de color (PDF en RGB; pedir conversión CMYK y prueba del verde azulado y del coral) y si exigen PDF/X.
4. Si se consigue una fotografía real del prototipo (≥ 3000 px de ancho), puede reemplazar la imagen principal.
