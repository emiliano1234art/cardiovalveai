# CardioValveAI · Texto final del pendón v2 (800 × 2000 mm)

Texto en orden de lectura. Se corrige en `pendon2.py` (cada `T('clave', 'texto')`) y se regenera con `python pendon2.py`.

Palabras de texto (sin título, franja ni rótulos decorativos): 345

## Encabezado
- Nombre: CardioValveAI
- Franja: MODELO DE VÁLVULA AÓRTICA DE TRES VALVAS
- Texto vertical: PROTOTIPO DE BANCO
- Frase principal: Convertimos el movimiento de una válvula en datos medibles.
- Pregunta: ¿Qué puede contarnos el movimiento de una válvula?

## Modelo y lupas
- Rótulo: El prototipo
- Lupa: VALVA — 3 móviles
- Lupa: SENSOR HALL — fijo · uno por valva
- Lupa: IMÁN — gira con la valva
- Lupa: SERVOMOTOR — mueve las tres valvas
- Pie: Imágenes generadas a partir del modelo 3D del prototipo actual. En la lupa del imán, el portasensor se muestra separado; en la del servomotor, la estructura está oculta.

## Cifras de diseño
- **90 mm** — diámetro del anillo impreso en 3D
- **3** — valvas, cada una con su imán y su sensor Hall
- **0°–80°** — apertura de diseño, con un solo servomotor

## ¿Por qué mirar una válvula?
En cada latido, las válvulas del corazón abren y cierran. Cuánto se abren, cuándo y con qué coordinación es parte de cómo funciona el corazón.

Queremos saber si ese movimiento puede medirse de forma simple y, más adelante, relacionarse con la respuesta funcional de una persona.

**PREGUNTA DE INVESTIGACIÓN:** ¿Puede un sistema simple de sensores describir el movimiento valvular con datos comparables?

## Un ciclo: abrir y cerrar
Vistas superiores del modelo en 0°, 30°, 60° y 80° (ángulos de diseño).

## Del movimiento a los datos
1. **La valva se mueve** — El imán gira con ella.
2. **El campo cambia** — El sensor Hall, fijo, lo detecta.
3. **El ESP32 registra** — Lee los 3 sensores y controla el servo.
4. **Vemos y analizamos** — Una señal por valva en el computador.

Nota: La señal del sensor no es un ángulo: para expresarla en grados, cada valva se calibra con posiciones conocidas.

## Qué observamos (esquemas ilustrativos, no son resultados)
1. Apertura y cierre
2. Coordinación de las 3 valvas
3. Tiempos del movimiento
4. Cambios frente a un patrón de referencia

## Hoy y a futuro
- **Hoy · prototipo:** Modelo de banco que mueve tres valvas y registra una señal por valva. Sin fluido ni pacientes.
- **Lo que estudiamos:** Qué variables del movimiento son medibles, repetibles y comparables.
- **A futuro:** Tras una validación adecuada: apoyo al seguimiento funcional y a la rehabilitación cardiorrespiratoria personalizada, con inteligencia artificial.

Nota: La inteligencia artificial es una línea de desarrollo futuro; hoy, el software compara cada ciclo con un patrón de referencia. Prototipo académico: no es un dispositivo médico ni entrega diagnósticos.

## Invitación
Acércate: mira el mecanismo en movimiento y conversemos.
